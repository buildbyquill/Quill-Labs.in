import { CMSConfig, MediaAsset, RevalidationLog } from '../types/cms';

export interface PageContent {
  values: Record<string, any>;
  seo?: {
    metaTitle?: string;
    metaDescription?: string;
    ogImage?: string;
    canonicalUrl?: string;
    noIndex?: boolean;
  };
  updatedAt: string;
}

export interface CollectionItem {
  id: string;
  status: 'published' | 'draft';
  createdAt: string;
  updatedAt: string;
  values: Record<string, any>;
}

const STORAGE_PREFIX = 'cms_dynamic_';

// Initial curated media catalog
const DEFAULT_MEDIA: MediaAsset[] = [
  {
    id: 'asset-1',
    name: 'analytics-dashboard-hero.png',
    url: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
    size: 2458000,
    mimeType: 'image/png',
    width: 1920,
    height: 1080,
    altText: 'Real-time telemetry and metric visualization dashboard',
    uploadedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    bucket: 'cms-media',
  },
  {
    id: 'asset-2',
    name: 'team-collaboration-workshop.jpg',
    url: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1000&q=80',
    size: 1820000,
    mimeType: 'image/jpeg',
    width: 1600,
    height: 1200,
    altText: 'Engineering team whiteboarding system architecture',
    uploadedAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    bucket: 'cms-media',
  },
  {
    id: 'asset-3',
    name: 'microchip-distributed-systems.jpg',
    url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1000&q=80',
    size: 1420000,
    mimeType: 'image/jpeg',
    width: 1200,
    height: 675,
    altText: 'Silicon wafer depicting high-throughput distributed pipelines',
    uploadedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    bucket: 'cms-media',
  },
  {
    id: 'asset-4',
    name: 'executive-portrait-alex.jpg',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=500&q=80',
    size: 680000,
    mimeType: 'image/jpeg',
    width: 500,
    height: 500,
    altText: 'Portrait of engineering leadership',
    uploadedAt: new Date(Date.now() - 86400000 * 8).toISOString(),
    bucket: 'cms-media',
  },
  {
    id: 'asset-5',
    name: 'artisan-ceramics-stone.jpg',
    url: 'https://images.unsplash.com/photo-1616046229478-9901c5536a45?auto=format&fit=crop&w=1200&q=80',
    size: 2150000,
    mimeType: 'image/jpeg',
    width: 1400,
    height: 600,
    altText: 'Neutral architectural stoneware on limestone pedestal',
    uploadedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    bucket: 'cms-media',
  },
];

export class CMSStorageService {
  private tenantId: string;

  constructor(tenantId: string) {
    this.tenantId = tenantId;
  }

  setTenant(tenantId: string) {
    this.tenantId = tenantId;
  }

  private getKey(subKey: string): string {
    return `${STORAGE_PREFIX}${this.tenantId}_${subKey}`;
  }

  // Page Content
  getPageContent(pageId: string, fallbackConfig?: CMSConfig): PageContent {
    try {
      const stored = localStorage.getItem(this.getKey(`page_${pageId}`));
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // ignore
    }

    // Default initialization from schema config
    const pageDef = fallbackConfig?.pages.find((p) => p.id === pageId);
    const initialValues: Record<string, any> = {};
    pageDef?.fields.forEach((field) => {
      initialValues[field.name] = field.defaultValue ?? (field.type === 'boolean' ? false : '');
    });

    const defaultContent: PageContent = {
      values: initialValues,
      seo: {
        metaTitle: `${pageDef?.title || 'Page'} | ${fallbackConfig?.siteName || 'Site'}`,
        metaDescription: pageDef?.description || 'Customizable page copy and metadata.',
        ogImage: initialValues.heroImage || initialValues.heroReelCover || DEFAULT_MEDIA[0].url,
        canonicalUrl: `${fallbackConfig?.siteUrl || ''}${pageDef?.slug || ''}`,
        noIndex: false,
      },
      updatedAt: new Date().toISOString(),
    };

    return defaultContent;
  }

  savePageContent(pageId: string, content: PageContent): void {
    try {
      localStorage.setItem(this.getKey(`page_${pageId}`), JSON.stringify(content));
    } catch (e) {
      console.error('Failed to save page content to localStorage', e);
    }
  }

  // Collections CRUD
  getCollectionItems(collectionId: string, fallbackConfig?: CMSConfig): CollectionItem[] {
    try {
      const stored = localStorage.getItem(this.getKey(`col_${collectionId}`));
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // ignore
    }

    // Generate seed items for default experience
    const colDef = fallbackConfig?.collections.find((c) => c.id === collectionId);
    if (!colDef) return [];

    const seedItems: CollectionItem[] = [];
    const defaultVals: Record<string, any> = {};
    colDef.fields.forEach((f) => {
      defaultVals[f.name] = f.defaultValue ?? '';
    });

    seedItems.push({
      id: `${collectionId}-item-1`,
      status: 'published',
      createdAt: new Date(Date.now() - 86400000 * 4).toISOString(),
      updatedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
      values: defaultVals,
    });

    // Add a second draft item if applicable
    if (colDef.supportsDrafts) {
      const draftVals = { ...defaultVals };
      if (colDef.fields.some((f) => f.name === 'title')) {
        draftVals.title = `[DRAFT] Upcoming Release & System Notes`;
      } else if (colDef.fields.some((f) => f.name === 'name')) {
        draftVals.name = `Taylor Morgan`;
        draftVals.role = `Principal Architect`;
      } else if (colDef.fields.some((f) => f.name === 'clientName')) {
        draftVals.clientName = `Aether Studio Rebrand`;
      }
      seedItems.push({
        id: `${collectionId}-item-2`,
        status: 'draft',
        createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
        updatedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
        values: draftVals,
      });
    }

    this.saveCollectionItems(collectionId, seedItems);
    return seedItems;
  }

  saveCollectionItems(collectionId: string, items: CollectionItem[]): void {
    try {
      localStorage.setItem(this.getKey(`col_${collectionId}`), JSON.stringify(items));
    } catch (e) {
      console.error('Failed to save collection items', e);
    }
  }

  // Media Library
  getMediaAssets(): MediaAsset[] {
    try {
      const stored = localStorage.getItem(this.getKey('media_assets'));
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // ignore
    }
    this.saveMediaAssets(DEFAULT_MEDIA);
    return DEFAULT_MEDIA;
  }

  saveMediaAssets(assets: MediaAsset[]): void {
    try {
      localStorage.setItem(this.getKey('media_assets'), JSON.stringify(assets));
    } catch (e) {
      console.error('Failed to save media assets', e);
    }
  }

  addMediaAsset(asset: MediaAsset): void {
    const assets = this.getMediaAssets();
    assets.unshift(asset);
    this.saveMediaAssets(assets);
  }

  deleteMediaAsset(id: string): void {
    const assets = this.getMediaAssets().filter((a) => a.id !== id);
    this.saveMediaAssets(assets);
  }

  // Revalidation Logs
  getRevalidationLogs(): RevalidationLog[] {
    try {
      const stored = localStorage.getItem(this.getKey('reval_logs'));
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // ignore
    }
    return [
      {
        id: 'log-seed-1',
        timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
        path: '/',
        status: 'success',
        statusCode: 200,
        latencyMs: 142,
        triggerSource: 'page_save',
        details: 'Revalidated root "/" and Edge ISR cache tagged [cms-pages].',
      },
    ];
  }

  saveRevalidationLogs(logs: RevalidationLog[]): void {
    try {
      localStorage.setItem(this.getKey('reval_logs'), JSON.stringify(logs.slice(0, 50)));
    } catch (e) {
      console.error('Failed to save revalidation logs', e);
    }
  }

  addRevalidationLog(log: RevalidationLog): void {
    const logs = this.getRevalidationLogs();
    logs.unshift(log);
    this.saveRevalidationLogs(logs);
  }
}
