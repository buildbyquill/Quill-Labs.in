import { z } from 'zod';
import { FieldDefinition } from '../types/cms';

export function buildDynamicZodSchema(fields: FieldDefinition[]) {
  const shape: Record<string, z.ZodTypeAny> = {};

  fields.forEach((field) => {
    let schema: z.ZodTypeAny;

    switch (field.type) {
      case 'number':
        let numSchema = z.coerce.number();
        if (field.min !== undefined) numSchema = numSchema.min(field.min, `${field.label} must be at least ${field.min}`);
        if (field.max !== undefined) numSchema = numSchema.max(field.max, `${field.label} cannot exceed ${field.max}`);
        schema = field.required ? numSchema : numSchema.optional();
        break;

      case 'boolean':
        schema = z.boolean().default(field.defaultValue ?? false);
        break;

      case 'url':
        schema = field.required
          ? z.string().url(`Please enter a valid URL (e.g. https://...)`)
          : z.string().url(`Please enter a valid URL`).or(z.literal('')).optional();
        break;

      case 'text':
        if (field.name === 'slug') {
          schema = z
            .string()
            .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, 'Slug must only contain lowercase alphanumeric characters and hyphens');
          if (field.required) {
            schema = (schema as z.ZodString).min(1, 'Slug is required');
          }
        } else {
          schema = field.required
            ? z.string().trim().min(1, `${field.label} is required`)
            : z.string().optional();
        }
        break;

      case 'textarea':
      case 'richText':
      case 'select':
      case 'image':
      default:
        schema = field.required
          ? z.string().trim().min(1, `${field.label} is required`)
          : z.string().optional();
        break;
    }

    shape[field.name] = schema;
  });

  return z.object(shape);
}

export function validateFieldValues(
  fields: FieldDefinition[],
  values: Record<string, any>
): { isValid: boolean; errors: Record<string, string>; sanitizedData: Record<string, any> } {
  const schema = buildDynamicZodSchema(fields);
  const result = schema.safeParse(values);

  if (result.success) {
    return {
      isValid: true,
      errors: {},
      sanitizedData: result.data,
    };
  }

  const errors: Record<string, string> = {};
  result.error.issues.forEach((issue) => {
    const fieldName = issue.path[0] as string;
    if (fieldName && !errors[fieldName]) {
      errors[fieldName] = issue.message;
    }
  });

  return {
    isValid: false,
    errors,
    sanitizedData: values,
  };
}
