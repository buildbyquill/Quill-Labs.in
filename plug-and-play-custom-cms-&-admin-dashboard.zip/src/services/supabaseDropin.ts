import { createClient, SupabaseClient } from '@supabase/supabase-js';

export interface SiteContentItem {
  id: string;
  value: string;
  updated_at: string;
}

export interface SiteLeadItem {
  id: string;
  name: string;
  email: string;
  message: string;
  created_at: string;
  status?: 'new' | 'contacted' | 'archived';
}

export interface SupabaseConfig {
  supabaseUrl: string;
  supabaseAnonKey: string;
  useLiveSupabase: boolean;
}

const STORAGE_KEYS = {
  CONTENT: 'simple_dropin_site_content',
  LEADS: 'simple_dropin_site_leads',
  CONFIG: 'simple_dropin_supabase_config',
};

const DEFAULT_CONTENT: SiteContentItem[] = [
  {
    id: 'brand_name',
    value: 'Apex Creative Studio',
    updated_at: new Date().toISOString(),
  },
  {
    id: 'brand_logo',
    value: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=120&q=80',
    updated_at: new Date().toISOString(),
  },
  {
    id: 'brand_color',
    value: '#2563EB',
    updated_at: new Date().toISOString(),
  },
  {
    id: 'hero_title',
    value: 'Welcome to Apex Creative',
    updated_at: new Date().toISOString(),
  },
  {
    id: 'hero_desc',
    value: 'We craft high-performance websites and digital experiences tailored to your business goals.',
    updated_at: new Date().toISOString(),
  },
  {
    id: 'hero_image',
    value: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
    updated_at: new Date().toISOString(),
  },
  {
    id: 'about_text',
    value: 'We help modern businesses design, build, and deploy high-performance web applications.',
    updated_at: new Date().toISOString(),
  },
  {
    id: 'contact_email',
    value: 'hello@apexstudio.com',
    updated_at: new Date().toISOString(),
  },
];

const DEFAULT_LEADS: SiteLeadItem[] = [
  {
    id: 'lead-1',
    name: 'Sarah Jenkins',
    email: 'sarah.jenkins@acmeworks.com',
    message: 'Hello! We love your portfolio and would like to request a custom proposal for our Q4 website redesign.',
    created_at: new Date(Date.now() - 3600000 * 4).toISOString(),
    status: 'new',
  },
  {
    id: 'lead-2',
    name: 'David Miller',
    email: 'david@summitmedia.io',
    message: 'Inquiring about your monthly retainer availability. Are you open for a quick discovery call this week?',
    created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
    status: 'contacted',
  },
];

class SupabaseDropinService {
  private client: SupabaseClient | null = null;
  private config: SupabaseConfig;
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.config = this.loadConfig();
    this.initializeClient();
  }

  private loadConfig(): SupabaseConfig {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CONFIG);
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return {
      supabaseUrl: '',
      supabaseAnonKey: '',
      useLiveSupabase: false,
    };
  }

  public saveConfig(newConfig: SupabaseConfig) {
    this.config = newConfig;
    try {
      localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(newConfig));
    } catch (e) {
      console.error(e);
    }
    this.initializeClient();
    this.notify();
  }

  public getConfig(): SupabaseConfig {
    return { ...this.config };
  }

  private initializeClient() {
    if (this.config.useLiveSupabase && this.config.supabaseUrl && this.config.supabaseAnonKey) {
      try {
        this.client = createClient(this.config.supabaseUrl, this.config.supabaseAnonKey);
      } catch (err) {
        console.error('Failed to init Supabase client:', err);
        this.client = null;
      }
    } else {
      this.client = null;
    }
  }

  public subscribe(cb: () => void) {
    this.listeners.add(cb);
    return () => {
      this.listeners.delete(cb);
    };
  }

  private notify() {
    this.listeners.forEach((cb) => {
      try {
        cb();
      } catch (e) {
        console.error(e);
      }
    });
  }

  // --- CONTENT API ---

  public async fetchSiteContent(): Promise<SiteContentItem[]> {
    if (this.client) {
      try {
        const { data, error } = await this.client.from('site_content').select('*');
        if (!error && data && data.length > 0) {
          return data as SiteContentItem[];
        }
      } catch (err) {
        console.warn('Live Supabase query error, falling back to local store:', err);
      }
    }

    // Local fallback
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CONTENT);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // Fallback
    }
    // Seed default
    this.persistLocalContent(DEFAULT_CONTENT);
    return DEFAULT_CONTENT;
  }

  public async saveSiteContent(items: { id: string; value: string }[]): Promise<boolean> {
    const now = new Date().toISOString();
    let success = true;

    if (this.client) {
      try {
        for (const item of items) {
          const { error } = await this.client.from('site_content').upsert([
            { id: item.id, value: item.value, updated_at: now },
          ]);
          if (error) throw error;
        }
      } catch (err) {
        console.error('Error saving to live Supabase:', err);
        success = false;
      }
    }

    // Always update local cache for instant UI responsiveness & offline support
    const current = await this.fetchSiteContent();
    const map = new Map<string, SiteContentItem>();
    current.forEach((c) => map.set(c.id, c));

    items.forEach((item) => {
      map.set(item.id, {
        id: item.id,
        value: item.value,
        updated_at: now,
      });
    });

    const updatedList = Array.from(map.values());
    this.persistLocalContent(updatedList);
    this.notify();
    return success;
  }

  public async deleteContentKey(id: string): Promise<boolean> {
    if (this.client) {
      try {
        await this.client.from('site_content').delete().eq('id', id);
      } catch (err) {
        console.error(err);
      }
    }

    const current = await this.fetchSiteContent();
    const filtered = current.filter((c) => c.id !== id);
    this.persistLocalContent(filtered);
    this.notify();
    return true;
  }

  private persistLocalContent(items: SiteContentItem[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.CONTENT, JSON.stringify(items));
    } catch (e) {
      console.error(e);
    }
  }

  // --- LEADS API ---

  public async fetchSiteLeads(): Promise<SiteLeadItem[]> {
    if (this.client) {
      try {
        const { data, error } = await this.client
          .from('site_leads')
          .select('*')
          .order('created_at', { ascending: false });
        if (!error && data) {
          return data as SiteLeadItem[];
        }
      } catch (err) {
        console.warn('Live Supabase leads query error, falling back to local store:', err);
      }
    }

    // Local fallback
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.LEADS);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // Fallback
    }
    this.persistLocalLeads(DEFAULT_LEADS);
    return DEFAULT_LEADS;
  }

  public async insertLead(lead: { name: string; email: string; message: string }): Promise<SiteLeadItem> {
    const newLead: SiteLeadItem = {
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `lead-${Date.now()}`,
      name: lead.name.trim() || 'Anonymous Visitor',
      email: lead.email.trim() || 'no-email@example.com',
      message: lead.message.trim(),
      created_at: new Date().toISOString(),
      status: 'new',
    };

    if (this.client) {
      try {
        await this.client.from('site_leads').insert([
          {
            name: newLead.name,
            email: newLead.email,
            message: newLead.message,
          },
        ]);
      } catch (err) {
        console.error('Error inserting lead to live Supabase:', err);
      }
    }

    const current = await this.fetchSiteLeads();
    const updated = [newLead, ...current];
    this.persistLocalLeads(updated);
    this.notify();
    return newLead;
  }

  public async deleteLead(id: string): Promise<boolean> {
    if (this.client) {
      try {
        await this.client.from('site_leads').delete().eq('id', id);
      } catch (err) {
        console.error(err);
      }
    }

    const current = await this.fetchSiteLeads();
    const filtered = current.filter((l) => l.id !== id);
    this.persistLocalLeads(filtered);
    this.notify();
    return true;
  }

  public async updateLeadStatus(id: string, status: 'new' | 'contacted' | 'archived'): Promise<boolean> {
    const current = await this.fetchSiteLeads();
    const updated = current.map((l) => (l.id === id ? { ...l, status } : l));
    this.persistLocalLeads(updated);
    this.notify();
    return true;
  }

  public async clearAllLeads(): Promise<void> {
    this.persistLocalLeads([]);
    this.notify();
  }

  public async resetToDummyData(): Promise<void> {
    this.persistLocalContent(DEFAULT_CONTENT);
    this.persistLocalLeads(DEFAULT_LEADS);
    this.notify();
  }

  private persistLocalLeads(leads: SiteLeadItem[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.LEADS, JSON.stringify(leads));
    } catch (e) {
      console.error(e);
    }
  }

  // --- EXPORT SNIPPETS ---

  public getSupabaseSqlCode(): string {
    return `-- 1. Create a table for simple page text/images
create table public.site_content (
    id text primary key, -- e.g., 'hero_title', 'hero_desc', 'about_text'
    value text not null, -- The actual text or image URL
    updated_at timestamp with time zone default now()
);

-- 2. Create a table to collect contact form leads
create table public.site_leads (
    id uuid primary key default gen_random_uuid(),
    name text,
    email text,
    message text,
    created_at timestamp with time zone default now()
);

-- 3. Enable Row Level Security & Allow Public Read for Content / Public Insert for Leads
alter table public.site_content enable row level security;
alter table public.site_leads enable row level security;

-- Anyone can read public site content
create policy "Allow public read-access on site_content"
on public.site_content for select using (true);

-- Admin dashboard can update site content (with anon key or service key)
create policy "Allow anon update on site_content"
on public.site_content for all using (true);

-- Anyone can submit contact form leads
create policy "Allow public insert on site_leads"
on public.site_leads for insert with check (true);

-- Admin dashboard can view & delete leads
create policy "Allow select on site_leads"
on public.site_leads for select using (true);

create policy "Allow delete on site_leads"
on public.site_leads for delete using (true);

-- 4. Insert starter dummy data so the website isn't blank
insert into public.site_content (id, value) values 
('brand_name', 'Apex Creative Studio'),
('brand_logo', 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=120&q=80'),
('brand_color', '#2563EB'),
('hero_title', 'Welcome to Apex Creative'),
('hero_desc', 'We craft high-performance websites and digital experiences tailored to your business goals.'),
('hero_image', 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80'),
('about_text', 'We craft clean, high-performance web applications tailored to your business goals.'),
('contact_email', 'hello@apexstudio.com')
on conflict (id) do nothing;`;
  }

  public getAdminDashboardCode(): string {
    return `'use client';
import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';

// Initialize simple Supabase client
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

const COLOR_PRESETS = [
  { name: 'Royal Blue', hex: '#2563EB' },
  { name: 'Emerald', hex: '#059669' },
  { name: 'Violet', hex: '#7C3AED' },
  { name: 'Rose Red', hex: '#E11D48' },
  { name: 'Amber Gold', hex: '#D97706' },
  { name: 'Slate Dark', hex: '#0F172A' },
];

export default function AdminDashboard() {
  // Brand identity
  const [brandName, setBrandName] = useState('');
  const [brandLogo, setBrandLogo] = useState('');
  const [brandColor, setBrandColor] = useState('#2563EB');

  // Content
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [image, setImage] = useState('');

  // Leads & UI
  const [leads, setLeads] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [savedAlert, setSavedAlert] = useState(false);

  // 1. Fetch current content and website leads when page opens
  useEffect(() => {
    async function fetchData() {
      const { data: content } = await supabase.from('site_content').select('*');
      content?.forEach((item: any) => {
        if (item.id === 'brand_name') setBrandName(item.value);
        if (item.id === 'brand_logo') setBrandLogo(item.value);
        if (item.id === 'brand_color') setBrandColor(item.value);
        if (item.id === 'hero_title') setTitle(item.value);
        if (item.id === 'hero_desc') setDesc(item.value);
        if (item.id === 'hero_image') setImage(item.value);
      });

      const { data: leadsData } = await supabase
        .from('site_leads')
        .select('*')
        .order('created_at', { ascending: false });
      if (leadsData) setLeads(leadsData);
    }
    fetchData();
  }, []);

  // 2. Save updated branding and content
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const updates = [
      { id: 'brand_name', value: brandName },
      { id: 'brand_logo', value: brandLogo },
      { id: 'brand_color', value: brandColor },
      { id: 'hero_title', value: title },
      { id: 'hero_desc', value: desc },
      { id: 'hero_image', value: image },
    ];

    for (const item of updates) {
      if (item.value !== undefined) {
        await supabase.from('site_content').upsert([item]);
      }
    }

    setLoading(false);
    setSavedAlert(true);
    setTimeout(() => setSavedAlert(false), 3000);
  };

  // 3. Delete lead handler
  const handleDeleteLead = async (id: string) => {
    if (!confirm('Delete this submission?')) return;
    await supabase.from('site_leads').delete().eq('id', id);
    setLeads((prev) => prev.filter((l) => l.id !== id));
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 p-6 sm:p-10 font-sans">
      <div className="max-w-4xl mx-auto space-y-8">
        
        <header className="border-b border-gray-800 pb-4 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3">
              {brandLogo ? (
                <img src={brandLogo} alt="Logo" className="w-8 h-8 rounded object-cover border border-gray-700" />
              ) : (
                <div className="w-8 h-8 rounded flex items-center justify-center font-bold text-white text-xs" style={{ backgroundColor: brandColor }}>
                  {brandName ? brandName.slice(0, 2).toUpperCase() : 'CO'}
                </div>
              )}
              <h1 className="text-2xl font-bold tracking-tight text-white">
                {brandName || 'Client'} Admin Dashboard
              </h1>
            </div>
            <p className="text-gray-400 text-sm mt-1">Change business branding, website copy, hero media, and incoming leads.</p>
          </div>
          {savedAlert && (
            <div className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold rounded-lg animate-pulse">
              ✓ Saved &amp; Synced
            </div>
          )}
        </header>

        {/* --- SECTION 1: CLIENT BRANDING (LOGO, COLOR, NAME) --- */}
        <section className="bg-gray-800 p-6 rounded-xl border border-gray-700 shadow-md space-y-4">
          <div className="flex items-center justify-between border-b border-gray-700 pb-3">
            <h2 className="text-lg font-semibold text-white flex items-center gap-2">
              🎨 Business Branding &amp; Styling
            </h2>
            <span className="text-xs text-gray-400 font-mono">Plug &amp; Play Customization</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1">
                Business Name
              </label>
              <input 
                type="text" 
                value={brandName} 
                onChange={(e) => setBrandName(e.target.value)}
                className="w-full bg-gray-900 border border-gray-700 rounded-lg p-2.5 text-white text-sm focus:outline-none focus:border-blue-500"
                placeholder="e.g. Acme Corp, Lumina Dental"
              />
            </div>

            <div>
              <label className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1">
                Logo Image URL
              </label>
              <input 
                type="url" 
                value={brandLogo} 
                onChange={(e) => setBrandLogo(e.target.value)}
                className="w-full bg-gray-900 border border-gray-700 rounded-lg p-2.5 text-white text-sm font-mono focus:outline-none focus:border-blue-500"
                placeholder="https://your-domain.com/logo.png"
              />
            </div>
          </div>

          {/* Color theme selection */}
          <div>
            <label className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-2">
              Primary Brand Accent Color: <span className="font-mono text-white">{brandColor}</span>
            </label>
            <div className="flex items-center gap-3 flex-wrap">
              {COLOR_PRESETS.map((p) => (
                <button
                  key={p.hex}
                  type="button"
                  onClick={() => setBrandColor(p.hex)}
                  className={"px-3 py-1.5 rounded-lg text-xs font-medium border transition flex items-center gap-2 cursor-pointer " +
                    (brandColor.toLowerCase() === p.hex.toLowerCase()
                      ? 'border-white text-white shadow-xs'
                      : 'border-gray-700 text-gray-300 hover:border-gray-500')
                  }
                >
                  <span className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: p.hex }}></span>
                  {p.name}
                </button>
              ))}

              {/* Custom Hex Picker */}
              <div className="flex items-center gap-2 bg-gray-900 px-3 py-1 rounded-lg border border-gray-700">
                <input
                  type="color"
                  value={brandColor}
                  onChange={(e) => setBrandColor(e.target.value)}
                  className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                />
                <span className="text-xs text-gray-400 font-mono">Custom</span>
              </div>
            </div>
          </div>
        </section>

        {/* --- SECTION 2: EDIT TEXT & MEDIA --- */}
        <section className="bg-gray-800 p-6 rounded-xl border border-gray-700 shadow-md">
          <h2 className="text-lg font-semibold mb-4 text-blue-400">Edit Website Content</h2>
          <form onSubmit={handleSave} className="space-y-4">
            <div>
              <label className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1">
                Hero Title
              </label>
              <input 
                type="text" 
                value={title} 
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-gray-900 border border-gray-700 rounded-lg p-2.5 text-white focus:outline-none focus:border-blue-500 text-sm font-medium"
                placeholder="Welcome to Our Website"
              />
            </div>

            <div>
              <label className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1">
                Hero Description
              </label>
              <textarea 
                rows={3}
                value={desc} 
                onChange={(e) => setDesc(e.target.value)}
                className="w-full bg-gray-900 border border-gray-700 rounded-lg p-2.5 text-white focus:outline-none focus:border-blue-500 text-sm"
                placeholder="Enter subtitle or introduction..."
              />
            </div>

            <div>
              <label className="block text-xs font-medium uppercase tracking-wider text-gray-400 mb-1">
                Hero Image URL
              </label>
              <input 
                type="url" 
                value={image} 
                onChange={(e) => setImage(e.target.value)}
                className="w-full bg-gray-900 border border-gray-700 rounded-lg p-2.5 text-white focus:outline-none focus:border-blue-500 text-sm font-mono"
                placeholder="https://images.unsplash.com/..."
              />
              {image && (
                <div className="mt-2.5 max-w-xs rounded-lg overflow-hidden border border-gray-700">
                  <img src={image} alt="Preview" className="w-full h-32 object-cover" />
                </div>
              )}
            </div>

            <button 
              type="submit" 
              disabled={loading}
              style={{ backgroundColor: brandColor }}
              className="text-white font-medium text-sm py-2.5 px-6 rounded-lg transition-opacity hover:opacity-90 disabled:opacity-50 flex items-center gap-2 cursor-pointer shadow-sm"
            >
              {loading ? 'Saving...' : 'Save All Changes'}
            </button>
          </form>
        </section>

        {/* --- SECTION 3: VIEW CLIENT LEADS --- */}
        <section className="bg-gray-800 p-6 rounded-xl border border-gray-700 shadow-md">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-green-400">
              Received Leads ({leads.length})
            </h2>
            <span className="text-xs text-gray-500">Real-time submissions</span>
          </div>

          {leads.length === 0 ? (
            <div className="p-8 text-center text-gray-500 text-sm border border-dashed border-gray-700 rounded-lg">
              No form submissions yet. Incoming contact inquiries will appear here automatically.
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
              {leads.map((lead) => (
                <div key={lead.id} className="bg-gray-900 p-4 rounded-lg border border-gray-700 text-sm space-y-1.5">
                  <div className="flex justify-between items-center text-xs text-gray-400">
                    <span className="font-bold text-gray-200">{lead.name} ({lead.email})</span>
                    <div className="flex items-center gap-3">
                      <span>{new Date(lead.created_at).toLocaleDateString()}</span>
                      <button
                        onClick={() => handleDeleteLead(lead.id)}
                        className="text-gray-500 hover:text-red-400 transition-colors cursor-pointer"
                        title="Delete Lead"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                  <p className="text-gray-300 leading-relaxed">{lead.message}</p>
                </div>
              ))}
            </div>
          )}
        </section>

      </div>
    </div>
  );
}`;
  }

  public getClientFrontendCode(): string {
    return `// app/page.tsx - Public Client Website
import { createClient } from '@supabase/supabase-js';
import ContactForm from './ContactForm';

// Server-side Supabase client for reading content
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export const revalidate = 0; // Or ISR: export const revalidate = 60;

export default async function HomePage() {
  // 1. Fetch live site content & branding from Supabase
  const { data: content } = await supabase.from('site_content').select('*');
  const contentMap = Object.fromEntries((content || []).map((item) => [item.id, item.value]));

  // Brand identity
  const brandName = contentMap['brand_name'] || 'Apex Creative Studio';
  const brandLogo = contentMap['brand_logo'] || '';
  const brandColor = contentMap['brand_color'] || '#2563EB';

  // Hero content
  const heroTitle = contentMap['hero_title'] || 'Welcome to Apex Creative';
  const heroDesc = contentMap['hero_desc'] || 'We craft high-performance websites and digital experiences tailored to your business goals.';
  const heroImage = contentMap['hero_image'] || 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80';

  return (
    <main className="min-h-screen bg-white text-gray-900 font-sans">
      {/* Navigation */}
      <nav className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between border-b border-gray-100">
        <div className="flex items-center gap-3">
          {brandLogo ? (
            <img src={brandLogo} alt={brandName} className="h-8 w-auto max-w-[140px] object-contain rounded" />
          ) : (
            <div 
              className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-white text-xs"
              style={{ backgroundColor: brandColor }}
            >
              {brandName.slice(0, 2).toUpperCase()}
            </div>
          )}
          <span className="font-bold text-lg tracking-tight text-gray-900">{brandName}</span>
        </div>

        <div className="flex items-center gap-6 text-sm text-gray-600">
          <a href="#about" className="hover:text-black">About</a>
          <a 
            href="#contact" 
            className="px-4 py-2 rounded-lg text-white font-medium text-xs transition-opacity hover:opacity-90 shadow-xs"
            style={{ backgroundColor: brandColor }}
          >
            Contact Us
          </a>
          <a href="/admin" className="text-xs px-2.5 py-1 rounded bg-gray-100 text-gray-700 hover:bg-gray-200">
            Admin
          </a>
        </div>
      </nav>

      {/* Hero Section dynamically styled with brandColor */}
      <section className="max-w-6xl mx-auto px-6 py-20 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        <div className="space-y-5">
          <div 
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold"
            style={{ backgroundColor: brandColor + '18', color: brandColor }}
          >
            <span>●</span> Live Client Template
          </div>

          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight leading-tight text-gray-950">
            {heroTitle}
          </h1>
          <p className="text-lg text-gray-600 leading-relaxed">
            {heroDesc}
          </p>

          <div className="pt-2 flex items-center gap-4">
            <a 
              href="#contact" 
              className="inline-block px-6 py-3 text-white font-medium rounded-lg transition-opacity hover:opacity-90 shadow-sm"
              style={{ backgroundColor: brandColor }}
            >
              Get In Touch
            </a>
            <a 
              href="#about"
              className="inline-block px-6 py-3 bg-gray-100 text-gray-800 font-medium rounded-lg hover:bg-gray-200 transition"
            >
              Learn More
            </a>
          </div>
        </div>

        <div className="rounded-2xl overflow-hidden shadow-xl border border-gray-200">
          <img src={heroImage} alt={heroTitle} className="w-full h-80 object-cover" />
        </div>
      </section>

      {/* Contact Section: Writes directly to site_leads */}
      <section id="contact" className="bg-gray-50 border-t border-gray-200 py-16">
        <div className="max-w-xl mx-auto px-6">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-gray-900">Send Us a Message</h2>
            <p className="text-sm text-gray-600 mt-1">Submissions appear in {brandName}&apos;s /admin leads inbox instantly.</p>
          </div>
          <ContactForm brandColor={brandColor} />
        </div>
      </section>
    </main>
  );
}`;
  }

  public getContactFormComponentCode(): string {
    return `'use client';
// app/ContactForm.tsx
import { useState } from 'react';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default function ContactForm({ brandColor = '#2563EB' }: { brandColor?: string }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');

    const { error } = await supabase.from('site_leads').insert([
      { name, email, message }
    ]);

    if (error) {
      console.error(error);
      setStatus('error');
    } else {
      setStatus('success');
      setName('');
      setEmail('');
      setMessage('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl border border-gray-200 shadow-xs space-y-4">
      {status === 'success' && (
        <div className="p-3 bg-green-50 border border-green-200 text-green-800 text-xs rounded-lg font-medium">
          Thank you! Your message has been sent successfully.
        </div>
      )}
      {status === 'error' && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-xs rounded-lg font-medium">
          Failed to send message. Please try again.
        </div>
      )}
      <div>
        <label className="block text-xs font-semibold text-gray-700 mb-1">Your Name</label>
        <input
          type="text"
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Jane Doe"
          className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-black"
        />
      </div>
      <div>
        <label className="block text-xs font-semibold text-gray-700 mb-1">Email Address</label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="jane@company.com"
          className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-black"
        />
      </div>
      <div>
        <label className="block text-xs font-semibold text-gray-700 mb-1">Message</label>
        <textarea
          rows={4}
          required
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Tell us about your project..."
          className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-black"
        />
      </div>
      <button
        type="submit"
        disabled={status === 'submitting'}
        style={{ backgroundColor: brandColor }}
        className="w-full py-2.5 px-4 text-white text-sm font-medium rounded-lg transition-opacity hover:opacity-90 disabled:opacity-50 cursor-pointer shadow-xs"
      >
        {status === 'submitting' ? 'Sending...' : 'Send Message'}
      </button>
    </form>
  );
}`;
  }

  public getEnvSnippet(): string {
    return `# .env.local in the client Next.js repository:
NEXT_PUBLIC_SUPABASE_URL=https://xyzcompany.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
`;
  }

  public getAiPromptGuide(): string {
    return `You are an expert full-stack developer. I have provided the source code for a 
client website. I need you to integrate a lightweight, zero-maintenance, 
plug-and-play CMS and an /admin dashboard so the client can manage their own 
business branding, website copy, hero media, and view incoming contact form leads.

Here are the CLIENT DETAILS for this project:
- Business Name: [e.g., Apex Creative Studio / Lumina Dental Care]
- Brand Logo URL: [e.g., https://example.com/logo.png OR /logo.png]
- Primary Brand Accent Color: [e.g., #2563EB or #059669]
- Contact Email: [e.g., hello@clientbusiness.com]
- Target Framework: [e.g., Next.js 14 App Router / Next.js Pages / Vite React]

Please carry out the following implementation steps in the project:

STEP 1: Database Layer (Supabase)
1. Use or create the Supabase client connection using environment variables:
   NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.
2. Ensure two tables are used:
   a) site_content (id text primary key, value text, updated_at timestamp)
      - Seed with:
        * 'brand_name': "[Client Business Name]"
        * 'brand_logo': "[Client Brand Logo URL]"
        * 'brand_color': "[Client Brand Accent Color]"
        * 'hero_title': "[Client Business Hero Headline]"
        * 'hero_desc': "[Client Business Subtitle / Description]"
        * 'hero_image': "[High quality image URL for their industry]"
        * 'contact_email': "[Client Contact Email]"
   b) site_leads (id uuid primary key default gen_random_uuid(), name text, email text, message text, created_at timestamp)
3. Provide the clean SQL migration script ready to run in Supabase SQL Editor.

STEP 2: The Self-Service Drop-In Admin Page (/app/admin/page.tsx)
Create a clean, responsive, modern dark/light dashboard at /admin that includes:
1. Business Branding Panel:
   - Input for Business Name (updates id 'brand_name')
   - Input for Logo Image URL (updates id 'brand_logo') with live image preview
   - Brand Color Picker (presets like Royal Blue, Emerald, Violet, Rose, Slate + custom hex picker, updates id 'brand_color')
2. Content Management Panel:
   - Form fields for hero_title, hero_desc, hero_image, and any other custom keys.
   - Save All Changes button that upserts all values into site_content.
3. Leads Inbox Panel:
   - Query and display incoming submissions from site_leads.
   - Real-time display with name, email, message, and timestamp.
   - Delete action for spam inquiries.
   - One-click "Export to CSV" button to download all leads.
4. Security: Include instructions or a simple secret passphrase gate for /admin access.

STEP 3: Make the Public Website Dynamically Branded
1. In the main page (e.g., app/page.tsx or components):
   - Fetch all keys from site_content at request time (or revalidate: 0).
   - Dynamically render the business name in the navbar, hero, title, and footer.
   - Dynamically render the brand logo in the header with an initials avatar fallback.
   - Bind the primary accent color (brand_color) to CTA buttons, badges, links, and borders.
2. In the Contact Form:
   - Make the form insert submissions directly into the site_leads table.
   - Show instant success and error states.
   - Style the submit button using the dynamic brand_color.`;
  }
}

export const supabaseDropinService = new SupabaseDropinService();
