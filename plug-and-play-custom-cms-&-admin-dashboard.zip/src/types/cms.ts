export type FieldType = 
  | 'text' 
  | 'textarea' 
  | 'richText' 
  | 'boolean' 
  | 'number' 
  | 'select' 
  | 'image' 
  | 'url';

export interface SelectOption {
  label: string;
  value: string;
}

export interface FieldDefinition {
  name: string;
  label: string;
  type: FieldType;
  description?: string;
  placeholder?: string;
  defaultValue?: any;
  required?: boolean;
  min?: number;
  max?: number;
  options?: SelectOption[];
  aspectRatioHint?: string; // e.g., "16:9", "1:1", "Cover (1200x630)"
  group?: string; // for visually sectioning fields in the form
}

export interface SEOConfig {
  enabled: boolean;
  titleKey?: string;
  descriptionKey?: string;
  ogImageKey?: string;
}

export interface PageDefinition {
  id: string;
  title: string;
  slug: string;
  description?: string;
  icon?: string;
  fields: FieldDefinition[];
  seo?: SEOConfig;
}

export interface CollectionDefinition {
  id: string;
  title: string;
  slug: string;
  singularTitle: string;
  icon?: string;
  description?: string;
  primaryField: string; // which field is the display title in table
  supportsDrafts?: boolean;
  fields: FieldDefinition[];
  categoryField?: string;
}

export interface CMSConfig {
  tenantId: string;
  siteName: string;
  siteUrl: string;
  adminEmails: string[];
  revalidationEndpoint: string;
  revalidationSecret: string;
  supabaseConfig?: {
    url: string;
    anonKey: string;
    bucket: string;
  };
  pages: PageDefinition[];
  collections: CollectionDefinition[];
}

export interface MediaAsset {
  id: string;
  name: string;
  url: string;
  size: number; // bytes
  mimeType: string;
  width?: number;
  height?: number;
  altText?: string;
  uploadedAt: string;
  bucket: string;
}

export interface RevalidationLog {
  id: string;
  timestamp: string;
  path: string;
  status: 'success' | 'failed' | 'pending';
  statusCode: number;
  latencyMs: number;
  triggerSource: 'page_save' | 'collection_save' | 'bulk_action' | 'manual_ping';
  details?: string;
}

export interface ClerkUser {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  imageUrl: string;
  role: 'admin' | 'editor' | 'unauthorized';
  lastSignIn: string;
}
