/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useCallback } from 'react';
import { CMSConfig } from './types/cms';
import { saasStartupConfig, PRESET_CONFIGS } from './config/defaultSchema';
import { CMSStorageService } from './services/storage';
import { ToastProvider, useToast } from './components/ui/Toast';
import { ClerkAuthProvider, ClerkAuthGuard } from './components/auth/ClerkAuthGuard';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { PageEditor } from './components/pages/PageEditor';
import { CollectionManager } from './components/collections/CollectionManager';
import { MediaManager } from './components/media/MediaManager';
import { LiveSchemaEditor } from './components/schema/LiveSchemaEditor';
import { RevalidationLogsModal } from './components/revalidation/RevalidationLogsModal';
import { IntegrationGuideModal } from './components/developer/IntegrationGuideModal';
import { ClientSitePreview } from './components/preview/ClientSitePreview';
import { SimpleDropinDashboard } from './components/dropin/SimpleDropinDashboard';

function AdminDashboardContent({
  config,
  setConfig,
}: {
  config: CMSConfig;
  setConfig: (newConfig: CMSConfig) => void;
}) {
  const { success } = useToast();

  // Storage service instance for current tenant
  const storageService = useMemo(() => new CMSStorageService(config.tenantId), [config.tenantId]);

  // Active view state
  const [activeView, setActiveView] = useState<{
    type: 'page' | 'collection' | 'media' | 'schema_editor' | 'dropin_admin';
    id?: string;
  }>({
    type: 'dropin_admin',
    id: 'dropin_admin',
  });

  // Modal inspection states
  const [isRevalModalOpen, setIsRevalModalOpen] = useState(false);
  const [isIntegrationModalOpen, setIsIntegrationModalOpen] = useState(false);
  const [isLivePreviewOpen, setIsLivePreviewOpen] = useState(false);
  const [previewPath, setPreviewPath] = useState('/');
  const [revalCounter, setRevalCounter] = useState(0);

  // Handle Preset change
  const handleSelectPreset = useCallback((presetKey: string) => {
    const selected = PRESET_CONFIGS[presetKey];
    if (selected) {
      setConfig(selected.config);
      setActiveView({
        type: 'page',
        id: selected.config.pages[0]?.id || 'homepage',
      });
      success('Switched Schema Preset', `Active client tenant: ${selected.config.siteName}`);
    }
  }, [setConfig, success]);

  // Current selected page or collection
  const currentPage = config.pages.find((p) => p.id === activeView.id) || config.pages[0];
  const currentCollection = config.collections.find((c) => c.id === activeView.id) || config.collections[0];

  const handleOpenLivePreviewForPath = (path: string) => {
    setPreviewPath(path);
    setIsLivePreviewOpen(true);
  };

  const breadcrumb = {
    section:
      activeView.type === 'page'
        ? 'Pages'
        : activeView.type === 'collection'
        ? 'Collections'
        : activeView.type === 'dropin_admin'
        ? 'Deployment'
        : 'System',
    title:
      activeView.type === 'page'
        ? currentPage?.title || 'Page'
        : activeView.type === 'collection'
        ? currentCollection?.title || 'Collection'
        : activeView.type === 'media'
        ? 'Media Manager'
        : activeView.type === 'dropin_admin'
        ? 'Drop-in Dashboard (/admin)'
        : 'Schema Config',
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#F9FAFB] text-[#111827] font-sans antialiased">
      {/* Dynamic Navigation Sidebar */}
      <Sidebar
        config={config}
        activeView={activeView}
        onSelectView={setActiveView}
      />

      {/* Main App Content Viewport */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header
          config={config}
          breadcrumb={breadcrumb}
          onSelectPreset={handleSelectPreset}
          onOpenRevalidationLogs={() => setIsRevalModalOpen(true)}
          onOpenIntegrationGuide={() => setIsIntegrationModalOpen(true)}
          onOpenLivePreview={() => setIsLivePreviewOpen(true)}
          recentRevalCount={revalCounter}
        />

        {/* Scrollable Work Area */}
        <main className={`flex-1 overflow-y-auto ${activeView.type === 'dropin_admin' ? 'p-0' : 'p-6 sm:p-8'} bg-[#F9FAFB]`}>
          {activeView.type === 'dropin_admin' && (
            <SimpleDropinDashboard />
          )}

          {activeView.type === 'page' && currentPage && (
            <PageEditor
              key={currentPage.id}
              page={currentPage}
              config={config}
              storageService={storageService}
              onRevalidationTriggered={() => setRevalCounter((c) => c + 1)}
              onPreviewPage={handleOpenLivePreviewForPath}
            />
          )}

          {activeView.type === 'collection' && currentCollection && (
            <CollectionManager
              key={currentCollection.id}
              collection={currentCollection}
              config={config}
              storageService={storageService}
              onRevalidationTriggered={() => setRevalCounter((c) => c + 1)}
              onPreviewCollection={handleOpenLivePreviewForPath}
            />
          )}

          {activeView.type === 'media' && (
            <MediaManager storageService={storageService} />
          )}

          {activeView.type === 'schema_editor' && (
            <LiveSchemaEditor
              currentConfig={config}
              onApplyConfig={(newConfig) => {
                setConfig(newConfig);
                setActiveView({
                  type: 'page',
                  id: newConfig.pages[0]?.id || 'homepage',
                });
              }}
            />
          )}
        </main>

        {/* Clean Minimalism Status Footer */}
        <footer className="h-10 bg-white border-t border-gray-200 px-6 sm:px-8 flex items-center justify-between shrink-0 text-[10px] text-gray-400 uppercase tracking-widest">
          <div>
            Next.js Internal Webhook: <span className="text-green-600 font-medium">Connected</span>
          </div>
          <div>Powered by Clerk Auth &amp; Supabase DB</div>
        </footer>
      </div>

      {/* Modals */}
      {isRevalModalOpen && (
        <RevalidationLogsModal
          config={config}
          storageService={storageService}
          onClose={() => setIsRevalModalOpen(false)}
        />
      )}

      {isIntegrationModalOpen && (
        <IntegrationGuideModal
          config={config}
          onClose={() => setIsIntegrationModalOpen(false)}
        />
      )}

      {isLivePreviewOpen && (
        <ClientSitePreview
          config={config}
          storageService={storageService}
          initialPath={previewPath}
          onClose={() => setIsLivePreviewOpen(false)}
        />
      )}
    </div>
  );
}

export default function App() {
  const [config, setConfig] = useState<CMSConfig>(saasStartupConfig);

  return (
    <ToastProvider>
      <ClerkAuthProvider allowedAdminEmails={config.adminEmails}>
        <ClerkAuthGuard tenantSiteName={config.siteName}>
          <AdminDashboardContent config={config} setConfig={setConfig} />
        </ClerkAuthGuard>
      </ClerkAuthProvider>
    </ToastProvider>
  );
}
