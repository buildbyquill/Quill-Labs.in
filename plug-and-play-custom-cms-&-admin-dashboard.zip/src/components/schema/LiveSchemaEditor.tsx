import React, { useState } from 'react';
import { Sliders, Check, AlertCircle, RefreshCw, FileCode, RotateCcw, Copy } from 'lucide-react';
import { CMSConfig } from '../../types/cms';
import { PRESET_CONFIGS } from '../../config/defaultSchema';
import { useToast } from '../ui/Toast';

interface LiveSchemaEditorProps {
  currentConfig: CMSConfig;
  onApplyConfig: (newConfig: CMSConfig) => void;
}

export function LiveSchemaEditor({ currentConfig, onApplyConfig }: LiveSchemaEditorProps) {
  const { success, error } = useToast();
  const [jsonText, setJsonText] = useState(() => JSON.stringify(currentConfig, null, 2));
  const [parseError, setParseError] = useState<string | null>(null);

  const handleApply = () => {
    try {
      const parsed = JSON.parse(jsonText);
      if (!parsed.tenantId || !parsed.siteName || !Array.isArray(parsed.pages)) {
        throw new Error('Invalid schema format: Must include tenantId, siteName, and pages array.');
      }
      setParseError(null);
      onApplyConfig(parsed as CMSConfig);
      success('Dynamic Schema Updated', 'The entire UI has re-generated forms based on your new schema.');
    } catch (e: any) {
      setParseError(e.message);
      error('Schema JSON Error', e.message);
    }
  };

  const handleLoadPreset = (presetKey: string) => {
    const preset = PRESET_CONFIGS[presetKey]?.config;
    if (preset) {
      setJsonText(JSON.stringify(preset, null, 2));
      setParseError(null);
      onApplyConfig(preset);
      success('Preset Loaded', `Applied schema: ${preset.siteName}`);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl pb-16">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 flex items-center gap-2">
            <Sliders className="w-6 h-6 text-gray-900" />
            Dynamic Schema Engine
          </h1>
          <p className="text-xs text-gray-500 mt-1">
            Zero hardcoding. Edit or paste any client configuration schema below to auto-generate the forms, collections, and fields.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleApply}
            className="px-4 py-2 text-xs font-medium text-white bg-black rounded-lg hover:bg-gray-900 flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Check className="w-3.5 h-3.5" />
            Apply Schema &amp; Rebuild Forms
          </button>
        </div>
      </div>

      {/* Preset Fast-Loader */}
      <div className="p-4 rounded-lg border border-gray-200 bg-white space-y-3">
        <span className="text-xs font-semibold text-gray-800">
          Load Pre-built Multi-Tenant Blueprint:
        </span>
        <div className="flex flex-wrap gap-2">
          {Object.entries(PRESET_CONFIGS).map(([key, item]) => (
            <button
              key={key}
              type="button"
              onClick={() => handleLoadPreset(key)}
              className="px-3 py-1.5 text-xs rounded-lg border border-gray-200 bg-gray-50 text-gray-700 hover:border-black hover:text-black transition-colors"
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Error Banner */}
      {parseError && (
        <div className="p-3.5 rounded-lg bg-red-50 border border-red-200 text-xs text-red-600 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{parseError}</span>
        </div>
      )}

      {/* Live JSON Editor */}
      <div className="border border-gray-200 rounded-lg overflow-hidden bg-gray-900 shadow-xs">
        <div className="px-4 py-2.5 bg-gray-950 border-b border-gray-800 flex items-center justify-between text-xs text-gray-400">
          <span className="font-mono text-[11px]">cms.config.json (Live Schema)</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                navigator.clipboard.writeText(jsonText);
                success('Copied JSON Schema');
              }}
              className="hover:text-white flex items-center gap-1 transition-colors"
            >
              <Copy className="w-3.5 h-3.5" /> Copy
            </button>
          </div>
        </div>

        <textarea
          rows={26}
          value={jsonText}
          onChange={(e) => setJsonText(e.target.value)}
          className="w-full p-4 bg-transparent text-xs font-mono text-gray-200 focus:outline-hidden resize-y leading-relaxed"
          spellCheck={false}
        />
      </div>
    </div>
  );
}
