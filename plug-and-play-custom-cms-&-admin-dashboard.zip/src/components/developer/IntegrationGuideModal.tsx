import React, { useState } from 'react';
import { X, Code, Database, FileText, Check, Copy, Terminal, ExternalLink, Sparkles, Zap } from 'lucide-react';
import { CMSConfig } from '../../types/cms';
import { useToast } from '../ui/Toast';
import { supabaseDropinService } from '../../services/supabaseDropin';

interface IntegrationGuideModalProps {
  config: CMSConfig;
  onClose: () => void;
}

export function IntegrationGuideModal({ config, onClose }: IntegrationGuideModalProps) {
  const { success } = useToast();
  const [activeTab, setActiveTab] = useState<'dropin' | 'subapp' | 'revalidate' | 'supabase' | 'schema'>('dropin');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copySnippet = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    success('Copied Code Snippet', 'Ready to paste into your codebase.');
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const nextJsSubAppCode = `// /app/admin/[[...cms]]/page.tsx (Next.js 14/15 App Router)
import { CMSAdmin } from '@client-cms/core';
import { cmsConfig } from '@/cms.config';
import { currentUser } from '@clerk/nextjs/server';
import { notFound, redirect } from 'next/navigation';

export default async function AdminPage() {
  // Clerk Authentication Server-Side Guard
  const user = await currentUser();
  if (!user) {
    redirect('/sign-in?redirect_url=/admin');
  }

  const allowedEmails = process.env.ADMIN_EMAILS?.split(',') || [];
  const userEmail = user.emailAddresses[0]?.emailAddress;

  if (!allowedEmails.includes(userEmail)) {
    return (
      <div className="p-8 text-center">
        <h1 className="text-xl font-bold text-red-600">403 Forbidden</h1>
        <p>Email {userEmail} is not in authorized ADMIN_EMAILS list.</p>
      </div>
    );
  }

  // Render plug-and-play dynamic CMS dashboard
  return <CMSAdmin config={cmsConfig} />;
}`;

  const nextJsRevalidateCode = `// /app/api/revalidate/route.ts (Next.js App Router)
import { NextRequest, NextResponse } from 'next/server';
import { revalidatePath, revalidateTag } from 'next/cache';

export async function POST(req: NextRequest) {
  const secret = req.headers.get('x-revalidation-secret');

  // Verify secret from cms.config / environment
  if (secret !== process.env.REVALIDATION_SECRET) {
    return NextResponse.json({ message: 'Invalid revalidation secret' }, { status: 401 });
  }

  const { path, tag } = await req.json();

  if (tag) {
    revalidateTag(tag);
  }
  if (path) {
    revalidatePath(path);
  }

  return NextResponse.json({
    revalidated: true,
    path,
    tag,
    now: Date.now(),
  });
}`;

  const supabaseSqlCode = `-- Supabase Schema & Storage Migrations
-- 1. Create Pages Store Table
CREATE TABLE IF NOT EXISTS cms_pages (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  slug TEXT NOT NULL,
  title TEXT NOT NULL,
  content JSONB NOT NULL DEFAULT '{}'::jsonb,
  seo JSONB DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Create Collections Store Table
CREATE TABLE IF NOT EXISTS cms_collections (
  id TEXT PRIMARY KEY,
  collection_id TEXT NOT NULL,
  tenant_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('published', 'draft')),
  values JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Setup Supabase Storage Bucket for Universal Media Manager
INSERT INTO storage.buckets (id, name, public) 
VALUES ('cms-media', 'cms-media', true)
ON CONFLICT (id) DO NOTHING;

-- 4. Storage Security Policies
CREATE POLICY "Public Read Media" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'cms-media');

CREATE POLICY "Admin Upload Media" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'cms-media');`;

  const schemaJsonCode = JSON.stringify(config, null, 2);

  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-gray-200 shadow-xl p-6 relative">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1 text-gray-400 hover:text-black rounded transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-8 rounded-lg bg-gray-100 text-gray-900 flex items-center justify-center">
            <Terminal className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-gray-900">
              Plug-and-Play Integration &amp; Architecture
            </h2>
            <p className="text-xs text-gray-500">
              Easily connect this dashboard to any client Next.js repository or Supabase project.
            </p>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-2 border-b border-gray-200 pt-4 pb-2 mb-4 text-xs overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('dropin')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'dropin'
                ? 'bg-black text-white font-semibold'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            <Zap className="w-3.5 h-3.5" /> ⚡ Simple Drop-In Admin (app/admin)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('subapp')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'subapp'
                ? 'bg-black text-white font-semibold'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            <Code className="w-3.5 h-3.5" /> Next.js Drop-in Sub-App
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('revalidate')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'revalidate'
                ? 'bg-black text-white font-semibold'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" /> ISR Revalidation Route
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('supabase')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'supabase'
                ? 'bg-black text-white font-semibold'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            <Database className="w-3.5 h-3.5" /> Supabase SQL DDL
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('schema')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'schema'
                ? 'bg-black text-white font-semibold'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            <FileText className="w-3.5 h-3.5" /> Active Schema JSON
          </button>
        </div>

        {/* Tab Contents */}
        <div className="space-y-3">
          {activeTab === 'dropin' && (
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-gray-500 font-mono">
                    1. Drop into client repo: /app/admin/page.tsx
                  </span>
                  <button
                    type="button"
                    onClick={() => copySnippet('dropin_admin', supabaseDropinService.getAdminDashboardCode())}
                    className="text-xs text-blue-600 hover:text-blue-800 flex items-center gap-1 font-semibold transition-colors"
                  >
                    {copiedKey === 'dropin_admin' ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedKey === 'dropin_admin' ? 'Copied' : 'Copy Admin Page'}
                  </button>
                </div>
                <pre className="p-4 bg-gray-900 text-gray-200 font-mono text-xs rounded-lg overflow-x-auto border border-gray-800 leading-relaxed max-h-64">
                  {supabaseDropinService.getAdminDashboardCode()}
                </pre>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-gray-500 font-mono">
                    2. Supabase SQL Migration (site_content + site_leads)
                  </span>
                  <button
                    type="button"
                    onClick={() => copySnippet('dropin_sql', supabaseDropinService.getSupabaseSqlCode())}
                    className="text-xs text-green-600 hover:text-green-800 flex items-center gap-1 font-semibold transition-colors"
                  >
                    {copiedKey === 'dropin_sql' ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedKey === 'dropin_sql' ? 'Copied' : 'Copy Supabase SQL'}
                  </button>
                </div>
                <pre className="p-4 bg-gray-900 text-gray-200 font-mono text-xs rounded-lg overflow-x-auto border border-gray-800 leading-relaxed max-h-56">
                  {supabaseDropinService.getSupabaseSqlCode()}
                </pre>
              </div>
            </div>
          )}
          {activeTab === 'subapp' && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-500 font-mono">
                  Drop into /app/admin/[[...cms]]/page.tsx
                </span>
                <button
                  type="button"
                  onClick={() => copySnippet('subapp', nextJsSubAppCode)}
                  className="text-xs text-gray-700 hover:text-black flex items-center gap-1 font-medium transition-colors"
                >
                  {copiedKey === 'subapp' ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedKey === 'subapp' ? 'Copied' : 'Copy Sub-App Route'}
                </button>
              </div>
              <pre className="p-4 bg-gray-900 text-gray-200 font-mono text-xs rounded-lg overflow-x-auto border border-gray-800 leading-relaxed max-h-96">
                {nextJsSubAppCode}
              </pre>
            </div>
          )}

          {activeTab === 'revalidate' && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-500 font-mono">
                  Drop into /app/api/revalidate/route.ts
                </span>
                <button
                  type="button"
                  onClick={() => copySnippet('revalidate', nextJsRevalidateCode)}
                  className="text-xs text-gray-700 hover:text-black flex items-center gap-1 font-medium transition-colors"
                >
                  {copiedKey === 'revalidate' ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedKey === 'revalidate' ? 'Copied' : 'Copy Route Handler'}
                </button>
              </div>
              <pre className="p-4 bg-gray-900 text-gray-200 font-mono text-xs rounded-lg overflow-x-auto border border-gray-800 leading-relaxed max-h-96">
                {nextJsRevalidateCode}
              </pre>
            </div>
          )}

          {activeTab === 'supabase' && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-500 font-mono">
                  Paste into Supabase SQL Editor
                </span>
                <button
                  type="button"
                  onClick={() => copySnippet('supabase', supabaseSqlCode)}
                  className="text-xs text-gray-700 hover:text-black flex items-center gap-1 font-medium transition-colors"
                >
                  {copiedKey === 'supabase' ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedKey === 'supabase' ? 'Copied' : 'Copy SQL Migrations'}
                </button>
              </div>
              <pre className="p-4 bg-gray-900 text-gray-200 font-mono text-xs rounded-lg overflow-x-auto border border-gray-800 leading-relaxed max-h-96">
                {supabaseSqlCode}
              </pre>
            </div>
          )}

          {activeTab === 'schema' && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-500 font-mono">
                  cms.config.json (Active Dynamic Tenant Schema)
                </span>
                <button
                  type="button"
                  onClick={() => copySnippet('schema', schemaJsonCode)}
                  className="text-xs text-gray-700 hover:text-black flex items-center gap-1 font-medium transition-colors"
                >
                  {copiedKey === 'schema' ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                  {copiedKey === 'schema' ? 'Copied' : 'Copy Schema JSON'}
                </button>
              </div>
              <pre className="p-4 bg-gray-900 text-gray-200 font-mono text-xs rounded-lg overflow-x-auto border border-gray-800 leading-relaxed max-h-96">
                {schemaJsonCode}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
