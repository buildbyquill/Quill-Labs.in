import React, { useState } from 'react';
import {
  X,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Clock,
  Send,
  Code,
  Check,
  Copy,
  Zap,
} from 'lucide-react';
import { CMSConfig, RevalidationLog } from '../../types/cms';
import { CMSStorageService } from '../../services/storage';
import { triggerRevalidation } from '../../services/revalidation';
import { useToast } from '../ui/Toast';

interface RevalidationLogsModalProps {
  config: CMSConfig;
  storageService: CMSStorageService;
  onClose: () => void;
}

export function RevalidationLogsModal({
  config,
  storageService,
  onClose,
}: RevalidationLogsModalProps) {
  const { success, error } = useToast();
  const [logs, setLogs] = useState<RevalidationLog[]>(() => storageService.getRevalidationLogs());
  const [testingPath, setTestingPath] = useState('/');
  const [pinging, setPinging] = useState(false);
  const [copiedCurl, setCopiedCurl] = useState(false);

  const handleManualPing = async () => {
    setPinging(true);
    try {
      const res = await triggerRevalidation({
        path: testingPath || '/',
        triggerSource: 'manual_ping',
        config,
        storageService,
      });

      setLogs(storageService.getRevalidationLogs());
      success(
        'Manual Ping Completed',
        `Next.js ISR responded with ${res.statusCode} (${res.latencyMs}ms)`
      );
    } catch (e: any) {
      error('Ping Failed', e.message);
    } finally {
      setPinging(false);
    }
  };

  const curlCommand = `curl -X POST "${config.siteUrl}${config.revalidationEndpoint}" \\
  -H "Content-Type: application/json" \\
  -H "x-revalidation-secret: ${config.revalidationSecret}" \\
  -d '{"path": "${testingPath}", "tenantId": "${config.tenantId}"}'`;

  const handleCopyCurl = () => {
    navigator.clipboard.writeText(curlCommand);
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
    success('Copied cURL Command', 'Paste into terminal to test directly.');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-gray-200 shadow-xl p-6 relative">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1 text-gray-400 hover:text-black rounded transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-8 h-8 rounded-lg bg-gray-100 text-gray-900 flex items-center justify-center">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-gray-900">
              On-Demand Revalidation Telemetry
            </h2>
            <p className="text-xs text-gray-500">
              Real-time Next.js Incremental Static Regeneration (ISR) purge logs.
            </p>
          </div>
        </div>

        {/* Config Summary Banner */}
        <div className="mt-4 p-3.5 rounded-lg bg-gray-50 border border-gray-200 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div>
            <span className="text-gray-400 block text-[10px] uppercase font-semibold">
              Revalidation Webhook Target
            </span>
            <code className="font-mono text-gray-900 font-medium">
              {config.siteUrl}
              {config.revalidationEndpoint}
            </code>
          </div>
          <div>
            <span className="text-gray-400 block text-[10px] uppercase font-semibold">
              Secret Token (Header: x-revalidation-secret)
            </span>
            <code className="font-mono text-gray-600">
              {config.revalidationSecret.substring(0, 4)}••••••••
            </code>
          </div>
        </div>

        {/* Test Ping Bar */}
        <div className="mt-5 p-4 rounded-lg border border-gray-200 bg-white space-y-3">
          <h4 className="text-xs font-semibold text-gray-900 flex items-center gap-1.5">
            <Send className="w-3.5 h-3.5 text-gray-500" />
            Dispatch On-Demand Revalidation Test Ping
          </h4>
          <div className="flex gap-2">
            <input
              type="text"
              value={testingPath}
              onChange={(e) => setTestingPath(e.target.value)}
              placeholder="/ or /blog or /about"
              className="flex-1 px-3.5 py-2 text-xs font-mono bg-gray-50 border border-gray-200 rounded-lg focus:ring-1 focus:ring-black outline-hidden"
            />
            <button
              type="button"
              onClick={handleManualPing}
              disabled={pinging}
              className="px-4 py-2 text-xs font-medium text-white bg-black rounded-lg hover:bg-gray-900 flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              {pinging ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              Send Ping
            </button>
          </div>
        </div>

        {/* Logs Table */}
        <div className="mt-6 space-y-2">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-gray-500">
              Audit Event Stream ({logs.length})
            </h4>
            <button
              type="button"
              onClick={() => {
                storageService.saveRevalidationLogs([]);
                setLogs([]);
              }}
              className="text-[11px] text-gray-400 hover:text-red-600 transition-colors"
            >
              Clear history
            </button>
          </div>

          <div className="border border-gray-200 rounded-lg overflow-hidden divide-y divide-gray-100 bg-white max-h-60 overflow-y-auto">
            {logs.length === 0 ? (
              <div className="p-8 text-center text-xs text-gray-400">
                No revalidation calls recorded yet. Save any page or collection to trigger ISR.
              </div>
            ) : (
              logs.map((log) => (
                <div key={log.id} className="p-3 flex items-center justify-between text-xs gap-3 hover:bg-gray-50/60 transition-colors">
                  <div className="flex items-center gap-2.5 min-w-0">
                    {log.status === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                    )}
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-medium text-gray-900 truncate">
                          {log.path}
                        </span>
                        <span className="px-1.5 py-0.2 bg-green-50 text-green-700 border border-green-200 rounded text-[10px] font-mono">
                          {log.statusCode} OK
                        </span>
                      </div>
                      <p className="text-[11px] text-gray-400 truncate mt-0.5">{log.details}</p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="font-mono text-gray-500 block text-[11px]">{log.latencyMs}ms</span>
                    <span className="text-[10px] text-gray-400 block">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* cURL Inspection */}
        <div className="mt-5">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
              <Code className="w-3.5 h-3.5" /> Next.js Route Webhook cURL
            </span>
            <button
              type="button"
              onClick={handleCopyCurl}
              className="text-xs text-gray-600 hover:text-black font-medium flex items-center gap-1 transition-colors"
            >
              {copiedCurl ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedCurl ? 'Copied' : 'Copy cURL'}
            </button>
          </div>
          <pre className="p-3 bg-gray-900 text-gray-200 font-mono text-xs rounded-lg overflow-x-auto border border-gray-800 leading-relaxed">
            {curlCommand}
          </pre>
        </div>
      </div>
    </div>
  );
}
