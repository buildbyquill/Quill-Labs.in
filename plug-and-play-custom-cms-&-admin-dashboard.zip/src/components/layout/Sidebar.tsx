import React from 'react';
import {
  FileText,
  Database,
  Image as ImageIcon,
  Sliders,
  ChevronRight,
  Circle,
  Home,
  Info,
  CreditCard,
  BookOpen,
  Users,
  Layers,
  ShoppingBag,
  Briefcase,
  Mail,
  Tag,
} from 'lucide-react';
import { CMSConfig } from '../../types/cms';
import { useClerkAuth } from '../auth/ClerkAuthGuard';

interface SidebarProps {
  config: CMSConfig;
  activeView: { type: 'page' | 'collection' | 'media' | 'schema_editor' | 'dropin_admin'; id?: string };
  onSelectView: (view: { type: 'page' | 'collection' | 'media' | 'schema_editor' | 'dropin_admin'; id?: string }) => void;
}

const getPageIcon = (iconName?: string) => {
  switch (iconName) {
    case 'Home':
      return <Home className="w-4 h-4" />;
    case 'Info':
      return <Info className="w-4 h-4" />;
    case 'CreditCard':
      return <CreditCard className="w-4 h-4" />;
    case 'ShoppingBag':
      return <ShoppingBag className="w-4 h-4" />;
    default:
      return <FileText className="w-4 h-4" />;
  }
};

const getCollectionIcon = (iconName?: string) => {
  switch (iconName) {
    case 'BookOpen':
      return <BookOpen className="w-4 h-4" />;
    case 'Users':
      return <Users className="w-4 h-4" />;
    case 'Layers':
      return <Layers className="w-4 h-4" />;
    case 'Briefcase':
      return <Briefcase className="w-4 h-4" />;
    default:
      return <Database className="w-4 h-4" />;
  }
};

export function Sidebar({ config, activeView, onSelectView }: SidebarProps) {
  const { user } = useClerkAuth();

  const userInitials = user
    ? `${user.firstName?.charAt(0) || ''}${user.lastName?.charAt(0) || ''}`
    : 'AD';

  return (
    <aside className="w-64 bg-white border-r border-gray-200 flex flex-col shrink-0">
      {/* Brand Header */}
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-black rounded flex items-center justify-center shrink-0">
            <div className="w-4 h-4 border-2 border-white rounded-xs"></div>
          </div>
          <div className="overflow-hidden">
            <span className="font-bold text-lg tracking-tight text-gray-900 block truncate">
              {config.siteName || 'SchemaCMS'}
            </span>
          </div>
        </div>
        <div className="mt-2 text-[10px] uppercase tracking-widest text-gray-400 font-semibold">
          CMS Framework v1.4.2
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-4 overflow-y-auto">
        {/* Quick Drop-in Client Admin */}
        <div>
          <div className="text-xs font-semibold text-gray-400 px-3 py-1.5 uppercase tracking-wider flex items-center justify-between">
            <span>Client Deployment</span>
            <span className="text-[9px] px-1.5 py-0.2 bg-blue-50 text-blue-700 font-mono rounded font-bold border border-blue-200">
              DROP-IN
            </span>
          </div>
          <div className="space-y-1">
            <button
              type="button"
              onClick={() => onSelectView({ type: 'dropin_admin' })}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                activeView.type === 'dropin_admin'
                  ? 'bg-black text-white'
                  : 'text-gray-900 bg-gray-50/80 hover:bg-gray-100 hover:text-black font-semibold border border-gray-200/60'
              }`}
            >
              <div className="flex items-center gap-2.5 truncate">
                <span className={activeView.type === 'dropin_admin' ? 'text-white' : 'text-blue-600 font-bold'}>
                  ⚡
                </span>
                <span className="truncate">Drop-In Dashboard</span>
              </div>
              <span
                className={`text-[10px] font-mono ${
                  activeView.type === 'dropin_admin' ? 'text-gray-300' : 'text-gray-400'
                }`}
              >
                /admin
              </span>
            </button>
          </div>
        </div>

        {/* Pages */}
        <div>
          <div className="text-xs font-semibold text-gray-400 px-3 py-2 uppercase tracking-wider">
            Pages
          </div>
          <div className="space-y-1">
            {config.pages.map((page) => {
              const isActive = activeView.type === 'page' && activeView.id === page.id;
              return (
                <button
                  key={page.id}
                  type="button"
                  onClick={() => onSelectView({ type: 'page', id: page.id })}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-gray-100 text-black'
                      : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                >
                  <div className="flex items-center gap-3 truncate">
                    <span className={isActive ? 'text-black' : 'text-gray-400'}>
                      {getPageIcon(page.icon)}
                    </span>
                    <span className="truncate">{page.title}</span>
                  </div>
                  <span className="text-[10px] font-mono text-gray-400">{page.slug}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Collections */}
        {config.collections.length > 0 && (
          <div>
            <div className="text-xs font-semibold text-gray-400 px-3 py-2 uppercase tracking-wider">
              Collections
            </div>
            <div className="space-y-1">
              {config.collections.map((col) => {
                const isActive = activeView.type === 'collection' && activeView.id === col.id;
                return (
                  <button
                    key={col.id}
                    type="button"
                    onClick={() => onSelectView({ type: 'collection', id: col.id })}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      isActive
                        ? 'bg-gray-100 text-black'
                        : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                  >
                    <div className="flex items-center gap-3 truncate">
                      <span className={isActive ? 'text-black' : 'text-gray-400'}>
                        {getCollectionIcon(col.icon)}
                      </span>
                      <span className="truncate">{col.title}</span>
                    </div>
                    <span className="text-[10px] font-mono text-gray-400">{col.slug}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* System & Tools */}
        <div>
          <div className="text-xs font-semibold text-gray-400 px-3 py-2 uppercase tracking-wider">
            System
          </div>
          <div className="space-y-1">
            <button
              type="button"
              onClick={() => onSelectView({ type: 'media' })}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                activeView.type === 'media'
                  ? 'bg-gray-100 text-black'
                  : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <ImageIcon className={activeView.type === 'media' ? 'text-black w-4 h-4' : 'text-gray-400 w-4 h-4'} />
              <span>Media Manager</span>
            </button>

            <button
              type="button"
              onClick={() => onSelectView({ type: 'schema_editor' })}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                activeView.type === 'schema_editor'
                  ? 'bg-gray-100 text-black'
                  : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <Sliders className={activeView.type === 'schema_editor' ? 'text-black w-4 h-4' : 'text-gray-400 w-4 h-4'} />
              <span>Schema Config</span>
            </button>
          </div>
        </div>
      </nav>

      {/* User Footer Profile */}
      <div className="p-4 border-t border-gray-100">
        <div className="flex items-center gap-3 px-3 py-2">
          {user?.imageUrl ? (
            <img
              src={user.imageUrl}
              alt=""
              className="w-8 h-8 rounded-full object-cover border border-gray-200"
            />
          ) : (
            <div className="w-8 h-8 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center text-gray-800 text-xs font-bold">
              {userInitials}
            </div>
          )}
          <div className="flex-1 overflow-hidden">
            <div className="text-xs font-medium text-gray-900 truncate">
              {user?.firstName ? `${user.firstName} ${user.lastName || ''}` : 'Admin User'}
            </div>
            <div className="text-[10px] text-gray-400 truncate">
              {user?.email || 'admin@client-site.com'}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
