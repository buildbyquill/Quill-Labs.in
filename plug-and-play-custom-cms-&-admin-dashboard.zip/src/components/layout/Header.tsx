import React, { useState } from 'react';
import {
  ChevronDown,
  Globe,
  Zap,
  Code,
  LogOut,
  ShieldCheck,
  ShieldAlert,
} from 'lucide-react';
import { CMSConfig } from '../../types/cms';
import { PRESET_CONFIGS } from '../../config/defaultSchema';
import { useClerkAuth } from '../auth/ClerkAuthGuard';

interface HeaderProps {
  config: CMSConfig;
  breadcrumb?: { section: string; title: string };
  onSelectPreset: (presetKey: string) => void;
  onOpenRevalidationLogs: () => void;
  onOpenIntegrationGuide: () => void;
  onOpenLivePreview: () => void;
  recentRevalCount: number;
}

export function Header({
  config,
  breadcrumb = { section: 'Content', title: 'Home' },
  onSelectPreset,
  onOpenRevalidationLogs,
  onOpenIntegrationGuide,
  onOpenLivePreview,
  recentRevalCount,
}: HeaderProps) {
  const { user, signOut, signInAs } = useClerkAuth();
  const [isTenantMenuOpen, setIsTenantMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 sm:px-8 shrink-0 z-20">
      {/* Left: Breadcrumb Navigation & Tenant Selector */}
      <div className="flex items-center gap-3 text-sm">
        <div className="flex items-center gap-2 text-sm">
          <span className="text-gray-400">{breadcrumb.section}</span>
          <span className="text-gray-300">/</span>
          <span className="text-gray-400">{config.siteName}</span>
          <span className="text-gray-300">/</span>
          <span className="font-medium text-gray-900">{breadcrumb.title}</span>
        </div>

        {/* Multi-Tenant Preset Switcher */}
        <div className="relative ml-2">
          <button
            type="button"
            onClick={() => setIsTenantMenuOpen(!isTenantMenuOpen)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-gray-200 hover:bg-gray-50 text-xs font-medium text-gray-600 transition-colors"
          >
            <span>Preset</span>
            <ChevronDown className="w-3 h-3 text-gray-400" />
          </button>

          {isTenantMenuOpen && (
            <div className="absolute top-full left-0 mt-1.5 w-64 bg-white border border-gray-200 rounded-lg shadow-lg p-1.5 z-50">
              <div className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-gray-400 border-b border-gray-100 mb-1">
                Select Client Schema
              </div>
              {Object.entries(PRESET_CONFIGS).map(([key, preset]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => {
                    onSelectPreset(key);
                    setIsTenantMenuOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-md text-xs transition-colors flex flex-col gap-0.5 ${
                    config.tenantId === preset.config.tenantId
                      ? 'bg-gray-100 font-semibold text-black'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span>{preset.label}</span>
                    {config.tenantId === preset.config.tenantId && (
                      <span className="text-[10px] text-black font-bold">Active</span>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Right: Status & Actions */}
      <div className="flex items-center gap-3 sm:gap-4">
        {/* Live & Connected indicator */}
        <span className="hidden md:flex items-center gap-1.5 text-xs text-gray-400">
          <span className="w-2 h-2 bg-green-500 rounded-full"></span>
          <span>Live &amp; Connected</span>
        </span>

        {/* Preview Button */}
        <button
          type="button"
          onClick={onOpenLivePreview}
          className="px-3.5 py-1.5 sm:px-4 sm:py-2 text-sm font-medium border border-gray-200 rounded-md hover:bg-gray-50 bg-white text-gray-800 transition-colors flex items-center gap-1.5"
        >
          <Globe className="w-3.5 h-3.5 text-gray-500" />
          <span>Preview</span>
        </button>

        {/* Webhook Logs */}
        <button
          type="button"
          onClick={onOpenRevalidationLogs}
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 text-sm font-medium border border-gray-200 rounded-md hover:bg-gray-50 bg-white text-gray-800 transition-colors"
          title="Next.js ISR Webhook Logs"
        >
          <Zap className="w-3.5 h-3.5 text-gray-500" />
          <span>Webhook</span>
          {recentRevalCount > 0 && (
            <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
          )}
        </button>

        {/* Integration Code */}
        <button
          type="button"
          onClick={onOpenIntegrationGuide}
          className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 text-sm font-medium border border-gray-200 rounded-md hover:bg-gray-50 bg-white text-gray-800 transition-colors"
          title="Next.js Sub-App Integration Snippets"
        >
          <Code className="w-3.5 h-3.5 text-gray-500" />
          <span>Code</span>
        </button>

        {/* User Account / Auth Testing Menu */}
        {user && (
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
              className="flex items-center gap-2 p-1 rounded-md border border-gray-200 hover:bg-gray-50 transition-colors"
              title="Admin User Profile"
            >
              {user.imageUrl ? (
                <img
                  src={user.imageUrl}
                  alt=""
                  className="w-6 h-6 rounded-full object-cover"
                />
              ) : (
                <div className="w-6 h-6 rounded-full bg-gray-200 text-gray-800 text-[10px] font-bold flex items-center justify-center">
                  AD
                </div>
              )}
              <ChevronDown className="w-3 h-3 text-gray-400" />
            </button>

            {isUserMenuOpen && (
              <div className="absolute top-full right-0 mt-1.5 w-64 bg-white border border-gray-200 rounded-lg shadow-lg p-3 z-50 space-y-2 text-xs">
                <div className="border-b border-gray-100 pb-2">
                  <div className="font-semibold text-gray-900 truncate">
                    {user.firstName} {user.lastName}
                  </div>
                  <div className="text-gray-400 text-[11px] truncate font-mono">
                    {user.email}
                  </div>
                </div>

                <div className="flex items-center justify-between text-gray-600">
                  <span>Role</span>
                  <span className="font-semibold text-green-700 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Admin
                  </span>
                </div>

                <div className="border-t border-gray-100 pt-2 space-y-1">
                  <button
                    type="button"
                    onClick={() => {
                      signInAs('unauthorized_guest@test.org', 'Guest Visitor');
                      setIsUserMenuOpen(false);
                    }}
                    className="w-full text-left px-2 py-1.5 text-amber-700 hover:bg-amber-50 rounded transition-colors flex items-center gap-2"
                  >
                    <ShieldAlert className="w-3.5 h-3.5" />
                    Test Unauthorized Email (403)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      signOut();
                      setIsUserMenuOpen(false);
                    }}
                    className="w-full text-left px-2 py-1.5 text-red-600 hover:bg-red-50 rounded transition-colors flex items-center gap-2"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    Sign Out
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
}
