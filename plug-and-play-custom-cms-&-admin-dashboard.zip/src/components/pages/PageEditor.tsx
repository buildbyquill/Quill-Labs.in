import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Save,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Image as ImageIcon,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Globe,
  Sparkles,
  Layers,
} from 'lucide-react';
import { PageDefinition, FieldDefinition, CMSConfig, MediaAsset } from '../../types/cms';
import { CMSStorageService } from '../../services/storage';
import { triggerRevalidation } from '../../services/revalidation';
import { validateFieldValues } from '../../services/validation';
import { useToast } from '../ui/Toast';
import { RichTextEditor } from '../editor/RichTextEditor';
import { MediaPickerModal } from '../media/MediaManager';
import { FormSkeleton } from '../ui/Skeleton';

interface PageEditorProps {
  key?: string | number;
  page: PageDefinition;
  config: CMSConfig;
  storageService: CMSStorageService;
  onRevalidationTriggered?: () => void;
  onPreviewPage?: (pageSlug: string) => void;
}

export function PageEditor({
  page,
  config,
  storageService,
  onRevalidationTriggered,
  onPreviewPage,
}: PageEditorProps) {
  const { success, error, info } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [values, setValues] = useState<Record<string, any>>({});
  const [seoValues, setSeoValues] = useState<{
    metaTitle: string;
    metaDescription: string;
    ogImage: string;
    canonicalUrl: string;
    noIndex: boolean;
  }>({
    metaTitle: '',
    metaDescription: '',
    ogImage: '',
    canonicalUrl: '',
    noIndex: false,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isDirty, setIsDirty] = useState(false);
  const [lastSaved, setLastSaved] = useState<string | null>(null);
  const [isSeoOpen, setIsSeoOpen] = useState(false);

  // Media Picker Dialog State
  const [isMediaPickerOpen, setIsMediaPickerOpen] = useState(false);
  const [activeImageField, setActiveImageField] = useState<string | null>(null);

  // Load page values from storage service
  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      const content = storageService.getPageContent(page.id, config);
      setValues(content.values || {});
      setSeoValues({
        metaTitle: content.seo?.metaTitle || page.title,
        metaDescription: content.seo?.metaDescription || page.description || '',
        ogImage: content.seo?.ogImage || '',
        canonicalUrl: content.seo?.canonicalUrl || `${config.siteUrl}${page.slug}`,
        noIndex: content.seo?.noIndex || false,
      });
      setLastSaved(content.updatedAt || null);
      setIsDirty(false);
      setLoading(false);
    }, 100);

    return () => clearTimeout(timer);
  }, [page.id, config, storageService]);

  const handleFieldChange = (fieldName: string, value: any) => {
    setValues((prev) => ({ ...prev, [fieldName]: value }));
    setIsDirty(true);
    if (errors[fieldName]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[fieldName];
        return next;
      });
    }
  };

  const handleSeoChange = (key: string, value: any) => {
    setSeoValues((prev) => ({ ...prev, [key]: value }));
    setIsDirty(true);
  };

  // Group fields by section for clean layout hierarchy
  const fieldGroups = useMemo(() => {
    const groups: Record<string, FieldDefinition[]> = {};
    page.fields.forEach((field) => {
      const groupName = field.group || 'General Content';
      if (!groups[groupName]) groups[groupName] = [];
      groups[groupName].push(field);
    });
    return groups;
  }, [page.fields]);

  // Handle Save & On-Demand Revalidation
  const handleSave = useCallback(async () => {
    // 1. Zod schema validation
    const validation = validateFieldValues(page.fields, values);
    if (!validation.isValid) {
      setErrors(validation.errors);
      error('Validation Failed', 'Please fix the highlighted field errors before saving.');
      return;
    }

    setSaving(true);
    try {
      // 2. Persist to storage layer
      const now = new Date().toISOString();
      storageService.savePageContent(
        page.id,
        {
          values,
          seo: page.seo?.enabled ? seoValues : undefined,
          updatedAt: now,
        }
      );

      // 3. Trigger immediate On-Demand Next.js ISR Revalidation
      const revalResult = await triggerRevalidation({
        path: page.slug,
        triggerSource: 'page_save',
        config,
        storageService,
      });

      setLastSaved(now);
      setIsDirty(false);
      setErrors({});

      if (onRevalidationTriggered) {
        onRevalidationTriggered();
      }

      success(
        'Changes Published',
        `Revalidated Next.js route: ${page.slug} (${revalResult.latencyMs}ms)`
      );
    } catch (err: any) {
      error('Save Failed', err.message || 'An error occurred while saving.');
    } finally {
      setSaving(false);
    }
  }, [page, values, seoValues, config, storageService, onRevalidationTriggered, success, error]);

  // Keyboard shortcut Cmd/Ctrl + S to save
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 's') {
        e.preventDefault();
        handleSave();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleSave]);

  const handleOpenPickerForField = (fieldName: string) => {
    setActiveImageField(fieldName);
    setIsMediaPickerOpen(true);
  };

  const handleSelectMedia = (asset: MediaAsset) => {
    if (activeImageField === '__seo_ogImage') {
      handleSeoChange('ogImage', asset.url);
    } else if (activeImageField) {
      handleFieldChange(activeImageField, asset.url);
    }
    setIsMediaPickerOpen(false);
    setActiveImageField(null);
    success('Media Inserted', `${asset.name} applied to field.`);
  };

  if (loading) {
    return <FormSkeleton />;
  }

  return (
    <div className="space-y-6 max-w-5xl pb-16">
      {/* Top Header & Revalidation Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl font-bold tracking-tight text-gray-900">
              {page.title}
            </h1>
            <span className="font-mono text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-500">
              {page.slug}
            </span>
            {isDirty && (
              <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
                Unsaved changes
              </span>
            )}
          </div>
          <p className="text-xs text-gray-500 mt-1">
            {page.description || 'Dynamic schema fields rendered from cms.config.'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {onPreviewPage && (
            <button
              type="button"
              onClick={() => onPreviewPage(page.slug)}
              className="px-4 py-2 text-sm font-medium border border-gray-200 rounded-md hover:bg-gray-50 bg-white text-gray-800 transition-colors flex items-center gap-1.5"
            >
              <ExternalLink className="w-3.5 h-3.5 text-gray-500" />
              Preview
            </button>
          )}

          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="px-4 py-2 text-sm font-medium bg-black text-white rounded-md hover:bg-gray-900 shadow-xs flex items-center gap-2 transition-colors disabled:opacity-50"
          >
            {saving ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                Revalidating ISR...
              </>
            ) : (
              <>
                <Save className="w-3.5 h-3.5" />
                Publish Changes
              </>
            )}
          </button>
        </div>
      </div>

      {/* Dynamic Field Groups */}
      {Object.entries(fieldGroups).map(([groupName, fieldsList]) => {
        const fields = fieldsList as FieldDefinition[];
        return (
          <section
            key={groupName}
            className="bg-white border border-gray-200 rounded-xl overflow-hidden"
          >
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <h2 className="font-semibold text-gray-900">{groupName}</h2>
              <div className="text-[10px] bg-gray-100 px-2 py-0.5 rounded text-gray-500 font-mono">
                {page.id}_schema.json
              </div>
            </div>

            <div className="p-6 space-y-6">
              {fields.map((field) => {
                const value = values[field.name];
                const fieldError = errors[field.name];

                return (
                  <div key={field.name} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider flex items-center gap-1">
                        {field.label}
                        {field.required && <span className="text-red-500 font-bold">*</span>}
                      </label>
                      <span className="text-[11px] font-mono text-gray-400">
                        {field.name}
                      </span>
                    </div>

                    {/* 1. Single-line Text Input */}
                    {field.type === 'text' && (
                      <input
                        type="text"
                        value={value ?? ''}
                        placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}...`}
                        onChange={(e) => handleFieldChange(field.name, e.target.value)}
                        className={`w-full px-4 py-2.5 bg-gray-50 border rounded-lg text-sm focus:ring-1 focus:ring-black outline-hidden transition-all ${
                          fieldError ? 'border-red-400 bg-red-50/20' : 'border-gray-200'
                        }`}
                      />
                    )}

                    {/* 2. Textarea */}
                    {field.type === 'textarea' && (
                      <textarea
                        rows={3}
                        value={value ?? ''}
                        placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}...`}
                        onChange={(e) => handleFieldChange(field.name, e.target.value)}
                        className={`w-full px-4 py-2.5 bg-gray-50 border rounded-lg text-sm focus:ring-1 focus:ring-black outline-hidden resize-none leading-relaxed transition-all ${
                          fieldError ? 'border-red-400 bg-red-50/20' : 'border-gray-200'
                        }`}
                      />
                    )}

                    {/* 3. Rich Text Editor */}
                    {field.type === 'richText' && (
                      <RichTextEditor
                        value={value ?? ''}
                        onChange={(val) => handleFieldChange(field.name, val)}
                        placeholder={field.placeholder}
                        onOpenMediaPicker={() => {
                          setActiveImageField(field.name);
                          setIsMediaPickerOpen(true);
                        }}
                      />
                    )}

                    {/* 4. Boolean Toggle */}
                    {field.type === 'boolean' && (
                      <div className="flex items-center h-[42px]">
                        <button
                          type="button"
                          role="switch"
                          aria-checked={!!value}
                          onClick={() => handleFieldChange(field.name, !value)}
                          className={`w-10 h-5 rounded-full relative transition-colors ${
                            value ? 'bg-black' : 'bg-gray-200'
                          }`}
                        >
                          <span
                            className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-transform ${
                              value ? 'right-1' : 'left-1'
                            }`}
                          />
                        </button>
                        <span className="text-xs text-gray-500 ml-3">
                          {value ? 'Active / Enabled' : 'Disabled'}
                        </span>
                      </div>
                    )}

                    {/* 5. Number Input */}
                    {field.type === 'number' && (
                      <input
                        type="number"
                        min={field.min}
                        max={field.max}
                        value={value ?? 0}
                        onChange={(e) => handleFieldChange(field.name, parseFloat(e.target.value) || 0)}
                        className="w-full max-w-xs px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-1 focus:ring-black outline-hidden"
                      />
                    )}

                    {/* 6. Select Dropdown */}
                    {field.type === 'select' && (
                      <select
                        value={value ?? ''}
                        onChange={(e) => handleFieldChange(field.name, e.target.value)}
                        className="w-full max-w-sm px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-1 focus:ring-black outline-hidden"
                      >
                        {field.options?.map((opt) => (
                          <option key={opt.value} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    )}

                    {/* 7. Image Slot with Clean Minimalism Media Drop area */}
                    {field.type === 'image' && (
                      <div className="space-y-3">
                        {value ? (
                          <div className="relative aspect-video max-h-56 rounded-lg overflow-hidden border border-gray-200 bg-gray-100 group">
                            <img src={value} alt="Slot preview" className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                              <button
                                type="button"
                                onClick={() => handleOpenPickerForField(field.name)}
                                className="px-3 py-1.5 text-xs bg-white text-black font-medium rounded-md shadow-sm hover:bg-gray-100"
                              >
                                Replace
                              </button>
                              <button
                                type="button"
                                onClick={() => handleFieldChange(field.name, '')}
                                className="px-3 py-1.5 text-xs bg-black text-white font-medium rounded-md shadow-sm hover:bg-gray-800"
                              >
                                Remove
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div
                            onClick={() => handleOpenPickerForField(field.name)}
                            className="aspect-video max-h-48 bg-gray-50 border-2 border-dashed border-gray-200 rounded-lg flex flex-col items-center justify-center p-4 text-center cursor-pointer hover:bg-gray-100 transition-colors"
                          >
                            <ImageIcon className="w-8 h-8 text-gray-300 mb-2" />
                            <div className="text-sm text-gray-600 font-medium">
                              Drop {field.label.toLowerCase()} image
                            </div>
                            <div className="text-xs text-gray-400 mt-1">
                              Supabase Storage / {config.tenantId}
                            </div>
                          </div>
                        )}

                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span className="truncate max-w-sm font-mono text-[11px]">{value || 'No image chosen'}</span>
                          <button
                            type="button"
                            onClick={() => handleOpenPickerForField(field.name)}
                            className="text-black font-medium hover:underline text-xs"
                          >
                            Browse Media Manager
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Help Description & Validation Error */}
                    {field.description && (
                      <p className="text-[11px] text-gray-400 leading-normal">
                        {field.description}
                      </p>
                    )}
                    {fieldError && (
                      <p className="text-xs text-red-500 flex items-center gap-1 mt-1 font-medium">
                        <AlertCircle className="w-3.5 h-3.5" /> {fieldError}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        );
      })}

      {/* Dynamic SEO Fields Accordion */}
      {page.seo?.enabled && (
        <section className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <button
            type="button"
            onClick={() => setIsSeoOpen(!isSeoOpen)}
            className="w-full p-6 flex items-center justify-between text-left hover:bg-gray-50 transition-colors"
          >
            <div>
              <h2 className="font-semibold text-gray-900">SEO Metadata</h2>
              <p className="text-xs text-gray-400 mt-0.5">
                Search engine SERP snippet and OpenGraph preview tags.
              </p>
            </div>
            {isSeoOpen ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
          </button>

          {isSeoOpen && (
            <div className="p-6 space-y-6 border-t border-gray-100">
              {/* Google Snippet Search Preview matching Design HTML */}
              <div className="space-y-4">
                <div className="border-l-2 border-green-500 pl-4 py-1">
                  <div className="text-sm text-[#1a0dab] font-medium truncate">
                    {seoValues.metaTitle || `${page.title} | ${config.siteName}`}
                  </div>
                  <div className="text-xs text-[#006621] truncate">
                    {seoValues.canonicalUrl || `${config.siteUrl}${page.slug}`}
                  </div>
                  <div className="text-xs text-gray-500 mt-1 line-clamp-2">
                    {seoValues.metaDescription || 'Discover a collection of curated architectural spaces designed for the minimalist lifestyle. Built for those who value form and function.'}
                  </div>
                </div>

                <div className="pt-2 flex flex-wrap gap-2">
                  <span className="px-2 py-1 bg-gray-100 rounded text-[10px] font-medium text-gray-600">
                    Meta Title
                  </span>
                  <span className="px-2 py-1 bg-gray-100 rounded text-[10px] font-medium text-gray-600">
                    Description
                  </span>
                  <span className="px-2 py-1 bg-gray-100 rounded text-[10px] font-medium text-gray-600">
                    OpenGraph
                  </span>
                </div>
              </div>

              <div className="space-y-4 pt-2">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                    Meta Title Tag
                  </label>
                  <input
                    type="text"
                    value={seoValues.metaTitle}
                    onChange={(e) => handleSeoChange('metaTitle', e.target.value)}
                    placeholder="e.g. Modern Living Redefined | Architectural Spaces"
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-1 focus:ring-black outline-hidden"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                    Meta Description
                  </label>
                  <textarea
                    rows={2}
                    value={seoValues.metaDescription}
                    onChange={(e) => handleSeoChange('metaDescription', e.target.value)}
                    placeholder="Concise overview summarizing this page for search results..."
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-1 focus:ring-black outline-hidden resize-none leading-relaxed"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                      Social Card Image (og:image)
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={seoValues.ogImage}
                        onChange={(e) => handleSeoChange('ogImage', e.target.value)}
                        placeholder="https://..."
                        className="flex-1 px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-black outline-hidden"
                      />
                      <button
                        type="button"
                        onClick={() => handleOpenPickerForField('__seo_ogImage')}
                        className="px-3 py-2 text-xs font-medium bg-gray-100 rounded-lg hover:bg-gray-200 text-gray-700"
                      >
                        Browse
                      </button>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                      Search Indexing
                    </label>
                    <div className="flex items-center h-[42px]">
                      <button
                        type="button"
                        role="switch"
                        aria-checked={!seoValues.noIndex}
                        onClick={() => handleSeoChange('noIndex', !seoValues.noIndex)}
                        className={`w-10 h-5 rounded-full relative transition-colors ${
                          !seoValues.noIndex ? 'bg-black' : 'bg-gray-200'
                        }`}
                      >
                        <span
                          className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-transform ${
                            !seoValues.noIndex ? 'right-1' : 'left-1'
                          }`}
                        />
                      </button>
                      <span className="text-xs text-gray-500 ml-3">
                        {!seoValues.noIndex ? 'Indexable by search engines' : 'No-index requested'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>
      )}

      {/* Supabase Media Picker Modal */}
      {isMediaPickerOpen && (
        <MediaPickerModal
          storageService={storageService}
          onSelectAsset={handleSelectMedia}
          onClose={() => {
            setIsMediaPickerOpen(false);
            setActiveImageField(null);
          }}
        />
      )}
    </div>
  );
}
