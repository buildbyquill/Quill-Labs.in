import React, { useState, useRef } from 'react';
import {
  Bold,
  Italic,
  Heading2,
  Heading3,
  List,
  ListOrdered,
  Quote,
  Code,
  Link,
  Image as ImageIcon,
  Eye,
  Edit3,
} from 'lucide-react';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  minHeight?: string;
  onOpenMediaPicker?: (onSelect: (url: string, alt?: string) => void) => void;
}

export function RichTextEditor({
  value,
  onChange,
  placeholder = 'Write long-form copy using Markdown formatting...',
  minHeight = '220px',
  onOpenMediaPicker,
}: RichTextEditorProps) {
  const [activeTab, setActiveTab] = useState<'write' | 'preview'>('write');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const applyFormatting = (prefix: string, suffix: string = '', defaultText: string = 'text') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = value.substring(start, end) || defaultText;

    const replacement = `${prefix}${selectedText}${suffix}`;
    const newValue = value.substring(0, start) + replacement + value.substring(end);

    onChange(newValue);

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + prefix.length, start + prefix.length + selectedText.length);
    }, 10);
  };

  const handleInsertImage = () => {
    if (onOpenMediaPicker) {
      onOpenMediaPicker((url, alt = 'Uploaded Asset') => {
        applyFormatting(`![${alt}](`, `)`, url);
      });
    } else {
      const url = prompt('Enter image URL:');
      if (url) {
        applyFormatting('![Image Description](', ')', url);
      }
    }
  };

  const handleInsertLink = () => {
    const url = prompt('Enter URL (e.g. https://...):', 'https://');
    if (url) {
      applyFormatting('[', `](${url})`, 'Link Text');
    }
  };

  // Basic markdown preview renderer
  const renderMarkdownPreview = (text: string) => {
    if (!text.trim()) {
      return <p className="text-zinc-400 italic text-sm">Nothing to preview yet.</p>;
    }

    const lines = text.split('\n');
    const elements: React.ReactNode[] = [];
    let inCodeBlock = false;
    let codeBuffer: string[] = [];

    lines.forEach((line, idx) => {
      if (line.startsWith('```')) {
        if (inCodeBlock) {
          elements.push(
            <pre key={`code-${idx}`} className="bg-zinc-950 text-zinc-100 p-3 rounded-lg text-xs font-mono overflow-x-auto my-3 border border-zinc-800">
              <code>{codeBuffer.join('\n')}</code>
            </pre>
          );
          codeBuffer = [];
          inCodeBlock = false;
        } else {
          inCodeBlock = true;
        }
        return;
      }

      if (inCodeBlock) {
        codeBuffer.push(line);
        return;
      }

      if (line.startsWith('### ')) {
        elements.push(<h3 key={idx} className="text-lg font-semibold text-zinc-900 dark:text-zinc-100 mt-4 mb-2">{line.replace('### ', '')}</h3>);
      } else if (line.startsWith('## ')) {
        elements.push(<h2 key={idx} className="text-xl font-bold text-zinc-900 dark:text-zinc-100 mt-5 mb-2">{line.replace('## ', '')}</h2>);
      } else if (line.startsWith('# ')) {
        elements.push(<h1 key={idx} className="text-2xl font-bold text-zinc-900 dark:text-zinc-100 mt-6 mb-3">{line.replace('# ', '')}</h1>);
      } else if (line.startsWith('> ')) {
        elements.push(
          <blockquote key={idx} className="border-l-4 border-zinc-300 dark:border-zinc-700 pl-4 py-1 italic text-zinc-600 dark:text-zinc-400 my-2">
            {line.replace('> ', '')}
          </blockquote>
        );
      } else if (line.startsWith('- ') || line.startsWith('* ')) {
        elements.push(
          <li key={idx} className="list-disc ml-6 text-zinc-700 dark:text-zinc-300 text-sm my-0.5">
            {line.substring(2)}
          </li>
        );
      } else if (/^\d+\.\s/.test(line)) {
        elements.push(
          <li key={idx} className="list-decimal ml-6 text-zinc-700 dark:text-zinc-300 text-sm my-0.5">
            {line.replace(/^\d+\.\s/, '')}
          </li>
        );
      } else if (line.trim().startsWith('![')) {
        // Image markdown ![alt](url)
        const match = line.match(/!\[(.*?)\]\((.*?)\)/);
        if (match) {
          elements.push(
            <div key={idx} className="my-3">
              <img src={match[2]} alt={match[1]} className="rounded-lg max-h-72 object-cover border border-zinc-200 dark:border-zinc-800" />
              {match[1] && <span className="text-xs text-zinc-500 mt-1 block">{match[1]}</span>}
            </div>
          );
        }
      } else if (line.trim() === '') {
        elements.push(<div key={idx} className="h-2" />);
      } else {
        // Simple bold / italic inline replacement
        let parsed = line
          .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
          .replace(/\*(.*?)\*/g, '<em>$1</em>')
          .replace(/`([^`]+)`/g, '<code class="bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded text-xs font-mono text-pink-600 dark:text-pink-400">$1</code>');

        elements.push(
          <p
            key={idx}
            className="text-zinc-700 dark:text-zinc-300 text-sm leading-relaxed my-1.5"
            dangerouslySetInnerHTML={{ __html: parsed }}
          />
        );
      }
    });

    return <div className="prose prose-sm dark:prose-invert max-w-none">{elements}</div>;
  };

  return (
    <div className="border border-zinc-200 dark:border-zinc-800 rounded-xl overflow-hidden bg-white dark:bg-zinc-900 focus-within:ring-2 focus-within:ring-zinc-950 dark:focus-within:ring-zinc-400 transition-all">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between border-b border-zinc-200 dark:border-zinc-800 px-3 py-1.5 bg-zinc-50/80 dark:bg-zinc-900/80 gap-1 text-zinc-600 dark:text-zinc-400">
        <div className="flex items-center gap-0.5">
          <button
            type="button"
            title="Bold"
            onClick={() => applyFormatting('**', '**', 'bold text')}
            className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-md transition-colors"
          >
            <Bold className="w-4 h-4" />
          </button>
          <button
            type="button"
            title="Italic"
            onClick={() => applyFormatting('*', '*', 'italic text')}
            className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-md transition-colors"
          >
            <Italic className="w-4 h-4" />
          </button>
          <div className="h-4 w-px bg-zinc-200 dark:bg-zinc-700 mx-1" />
          <button
            type="button"
            title="Heading 2"
            onClick={() => applyFormatting('## ', '', 'Section Heading')}
            className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-md transition-colors"
          >
            <Heading2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            title="Heading 3"
            onClick={() => applyFormatting('### ', '', 'Subheading')}
            className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-md transition-colors"
          >
            <Heading3 className="w-4 h-4" />
          </button>
          <div className="h-4 w-px bg-zinc-200 dark:bg-zinc-700 mx-1" />
          <button
            type="button"
            title="Bullet List"
            onClick={() => applyFormatting('- ', '', 'List item')}
            className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-md transition-colors"
          >
            <List className="w-4 h-4" />
          </button>
          <button
            type="button"
            title="Numbered List"
            onClick={() => applyFormatting('1. ', '', 'Step item')}
            className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-md transition-colors"
          >
            <ListOrdered className="w-4 h-4" />
          </button>
          <button
            type="button"
            title="Blockquote"
            onClick={() => applyFormatting('> ', '', 'Important quote')}
            className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-md transition-colors"
          >
            <Quote className="w-4 h-4" />
          </button>
          <button
            type="button"
            title="Code"
            onClick={() => applyFormatting('`', '`', 'code')}
            className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-md transition-colors"
          >
            <Code className="w-4 h-4" />
          </button>
          <button
            type="button"
            title="Link"
            onClick={handleInsertLink}
            className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-md transition-colors"
          >
            <Link className="w-4 h-4" />
          </button>
          <button
            type="button"
            title="Insert Image"
            onClick={handleInsertImage}
            className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-800 rounded-md transition-colors text-indigo-600 dark:text-indigo-400"
          >
            <ImageIcon className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switcher: Write vs Preview */}
        <div className="flex items-center bg-zinc-200/60 dark:bg-zinc-800/60 p-0.5 rounded-lg text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('write')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md font-medium transition-all ${
              activeTab === 'write'
                ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white shadow-xs'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5" />
            Write
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('preview')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md font-medium transition-all ${
              activeTab === 'preview'
                ? 'bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white shadow-xs'
                : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            Preview
          </button>
        </div>
      </div>

      {/* Editor Body */}
      <div className="p-3">
        {activeTab === 'write' ? (
          <textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            style={{ minHeight }}
            className="w-full bg-transparent text-sm text-zinc-800 dark:text-zinc-200 focus:outline-hidden resize-y font-mono leading-relaxed placeholder:text-zinc-400"
          />
        ) : (
          <div style={{ minHeight }} className="p-2 overflow-y-auto">
            {renderMarkdownPreview(value)}
          </div>
        )}
      </div>
    </div>
  );
}
