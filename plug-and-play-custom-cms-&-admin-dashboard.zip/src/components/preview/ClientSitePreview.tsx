import React, { useState, useEffect } from 'react';
import {
  Monitor,
  Tablet,
  Smartphone,
  ExternalLink,
  RefreshCw,
  Sparkles,
  ArrowRight,
  CheckCircle,
  X,
  Globe,
} from 'lucide-react';
import { CMSConfig } from '../../types/cms';
import { CMSStorageService } from '../../services/storage';

interface ClientSitePreviewProps {
  config: CMSConfig;
  storageService: CMSStorageService;
  initialPath?: string;
  onClose?: () => void;
}

export function ClientSitePreview({
  config,
  storageService,
  initialPath = '/',
  onClose,
}: ClientSitePreviewProps) {
  const [viewport, setViewport] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [activePath, setActivePath] = useState(initialPath);
  const [pageContent, setPageContent] = useState<any>({});
  const [posts, setPosts] = useState<any[]>([]);
  const [team, setTeam] = useState<any[]>([]);
  const [lastRefreshed, setLastRefreshed] = useState<string>(new Date().toLocaleTimeString());

  const loadData = () => {
    // Load homepage content
    const home = storageService.getPageContent('homepage', config);
    const about = storageService.getPageContent('about', config);
    const pricing = storageService.getPageContent('pricing', config);
    const storefront = storageService.getPageContent('storefront', config);

    setPageContent({
      home: home.values || {},
      about: about.values || {},
      pricing: pricing.values || {},
      storefront: storefront.values || {},
    });

    // Load collections
    setPosts(storageService.getCollectionItems('posts', config));
    setTeam(storageService.getCollectionItems('team', config));
    setLastRefreshed(new Date().toLocaleTimeString());
  };

  useEffect(() => {
    loadData();
  }, [config, storageService]);

  const homeValues = pageContent.home || {};
  const publishedPosts = posts.filter((p) => p.status === 'published');
  const publishedTeam = team.filter((t) => t.status === 'published');

  return (
    <div className="fixed inset-0 z-50 bg-zinc-950/80 backdrop-blur-md flex flex-col">
      {/* Top Browser Bar */}
      <div className="h-14 bg-zinc-900 border-b border-zinc-800 px-4 flex items-center justify-between text-zinc-300">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-full bg-rose-500/80" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
          </div>

          <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-zinc-950 rounded-lg border border-zinc-800 text-xs font-mono text-zinc-400">
            <Globe className="w-3.5 h-3.5 text-zinc-400" />
            <span>{config.siteUrl}</span>
            <span className="text-white">{activePath}</span>
          </div>
        </div>

        {/* Viewport controls */}
        <div className="flex items-center bg-zinc-950 p-1 rounded-lg border border-zinc-800 text-xs">
          <button
            type="button"
            onClick={() => setViewport('desktop')}
            className={`p-1.5 rounded-md transition-colors ${
              viewport === 'desktop' ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'
            }`}
            title="Desktop (100%)"
          >
            <Monitor className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setViewport('tablet')}
            className={`p-1.5 rounded-md transition-colors ${
              viewport === 'tablet' ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'
            }`}
            title="Tablet (768px)"
          >
            <Tablet className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setViewport('mobile')}
            className={`p-1.5 rounded-md transition-colors ${
              viewport === 'mobile' ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'
            }`}
            title="Mobile (375px)"
          >
            <Smartphone className="w-4 h-4" />
          </button>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3">
          <span className="text-[11px] text-zinc-400 hidden md:inline">
            Refreshed via ISR: <span className="text-emerald-400 font-mono">{lastRefreshed}</span>
          </span>
          <button
            type="button"
            onClick={loadData}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors"
            title="Reload ISR Cache"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800 transition-colors"
              title="Close Preview"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Viewport Frame */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 flex justify-center items-start bg-zinc-950">
        <div
          className={`bg-white text-zinc-900 rounded-2xl shadow-2xl transition-all duration-300 overflow-hidden flex flex-col min-h-[85vh] border border-zinc-200 ${
            viewport === 'desktop'
              ? 'w-full max-w-6xl'
              : viewport === 'tablet'
              ? 'w-[768px]'
              : 'w-[375px]'
          }`}
        >
          {/* Announcement Bar */}
          {homeValues.announcementActive && (
            <div className="bg-zinc-950 text-white text-xs py-2 px-4 text-center font-medium flex items-center justify-center gap-2">
              <span>{homeValues.announcementText || '🚀 Special Announcement'}</span>
            </div>
          )}

          {/* Client Navigation Header */}
          <header className="px-6 py-4 border-b border-zinc-100 flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-base tracking-tight text-zinc-900">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 inline-block" />
              {config.siteName}
            </div>
            <nav className="flex items-center gap-4 text-xs font-medium text-zinc-600">
              <button
                type="button"
                onClick={() => setActivePath('/')}
                className={activePath === '/' ? 'text-zinc-950 font-bold' : 'hover:text-zinc-950'}
              >
                Home
              </button>
              <button
                type="button"
                onClick={() => setActivePath('/blog')}
                className={activePath === '/blog' ? 'text-zinc-950 font-bold' : 'hover:text-zinc-950'}
              >
                Blog ({publishedPosts.length})
              </button>
              <button
                type="button"
                onClick={() => setActivePath('/about')}
                className={activePath === '/about' ? 'text-zinc-950 font-bold' : 'hover:text-zinc-950'}
              >
                About
              </button>
              <button
                type="button"
                className="px-3 py-1.5 bg-zinc-900 text-white rounded-lg text-xs font-semibold hover:bg-zinc-800"
              >
                {homeValues.primaryCtaText || 'Get Started'}
              </button>
            </nav>
          </header>

          {/* Client Page Body */}
          <main className="flex-1 p-6 sm:p-10 space-y-12">
            {/* View: Homepage */}
            {activePath === '/' && (
              <div className="space-y-12">
                {/* Hero Section */}
                <div className="text-center max-w-3xl mx-auto space-y-4 pt-4">
                  {homeValues.heroBadge && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gray-100 text-gray-800 text-xs font-medium border border-gray-200">
                      <Sparkles className="w-3.5 h-3.5" />
                      {homeValues.heroBadge}
                    </span>
                  )}
                  <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-zinc-950 leading-[1.15]">
                    {homeValues.heroHeadline || 'Elevate your workflows effortlessly.'}
                  </h1>
                  <p className="text-sm sm:text-base text-zinc-600 leading-relaxed max-w-2xl mx-auto">
                    {homeValues.heroSubheading || 'Clean, composable digital infrastructure built for velocity.'}
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                    <button
                      type="button"
                      className="px-5 py-2.5 bg-zinc-900 text-white text-xs font-semibold rounded-xl hover:bg-zinc-800 shadow-xs flex items-center gap-2"
                    >
                      {homeValues.primaryCtaText || 'Start Free Trial'} <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    {homeValues.secondaryCtaText && (
                      <button
                        type="button"
                        className="px-5 py-2.5 border border-zinc-200 text-zinc-800 text-xs font-medium rounded-xl hover:bg-zinc-50"
                      >
                        {homeValues.secondaryCtaText}
                      </button>
                    )}
                  </div>
                </div>

                {/* Hero Image */}
                {homeValues.heroImage && (
                  <div className="rounded-2xl overflow-hidden border border-zinc-200 shadow-xl max-w-4xl mx-auto">
                    <img src={homeValues.heroImage} alt="Hero mockup" className="w-full h-auto object-cover max-h-[420px]" />
                  </div>
                )}

                {/* Social Proof Numbers */}
                {(homeValues.statsCustomers || homeValues.statsUptime) && (
                  <div className="grid grid-cols-3 gap-4 border-y border-zinc-100 py-8 text-center max-w-3xl mx-auto">
                    <div>
                      <div className="text-2xl sm:text-3xl font-bold text-zinc-950">{homeValues.statsCustomers || '10,000+'}</div>
                      <div className="text-xs text-zinc-500 mt-1">Active Workspaces</div>
                    </div>
                    <div>
                      <div className="text-2xl sm:text-3xl font-bold text-zinc-950">{homeValues.statsUptime || '99.99%'}</div>
                      <div className="text-xs text-zinc-500 mt-1">SLA Guarantee</div>
                    </div>
                    <div>
                      <div className="text-2xl sm:text-3xl font-bold text-zinc-950">{homeValues.statsEvents || '3.8 Billion'}</div>
                      <div className="text-xs text-zinc-500 mt-1">Monthly Events</div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* View: Blog Feed */}
            {activePath === '/blog' && (
              <div className="space-y-8 max-w-4xl mx-auto">
                <div className="border-b border-zinc-100 pb-4">
                  <h1 className="text-2xl font-bold text-zinc-900">Engineering &amp; Product Updates</h1>
                  <p className="text-xs text-zinc-500 mt-1">Articles published via the Generic CRUD Engine.</p>
                </div>

                {publishedPosts.length === 0 ? (
                  <p className="text-center py-12 text-sm text-zinc-400">No published articles yet. Set articles to Published in CMS.</p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {publishedPosts.map((post) => (
                      <article key={post.id} className="border border-zinc-100 rounded-xl overflow-hidden hover:shadow-md transition-shadow">
                        {post.values.coverImage && (
                          <img src={post.values.coverImage} alt="" className="aspect-16/9 w-full object-cover" />
                        )}
                        <div className="p-4 space-y-2">
                          <span className="text-[10px] uppercase font-semibold text-gray-700 bg-gray-100 px-2 py-0.5 rounded">
                            {post.values.category || 'Engineering'}
                          </span>
                          <h3 className="font-bold text-sm text-zinc-900 leading-snug">{post.values.title}</h3>
                          <p className="text-xs text-zinc-600 line-clamp-2 leading-relaxed">{post.values.excerpt}</p>
                          <div className="text-[11px] text-zinc-400 pt-2 border-t border-zinc-50 flex items-center justify-between">
                            <span>By {post.values.author || 'Editorial'}</span>
                            <span>{new Date(post.updatedAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </article>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* View: About Us */}
            {activePath === '/about' && (
              <div className="space-y-8 max-w-3xl mx-auto">
                <div className="text-center space-y-3">
                  <h1 className="text-3xl font-bold text-zinc-950">
                    {pageContent.about?.missionStatement || 'Empowering teams worldwide.'}
                  </h1>
                </div>
                {pageContent.about?.teamCultureImage && (
                  <img src={pageContent.about.teamCultureImage} alt="" className="rounded-2xl w-full max-h-80 object-cover" />
                )}
                <div className="prose prose-sm text-zinc-600 leading-relaxed whitespace-pre-line">
                  {pageContent.about?.storyBody}
                </div>
              </div>
            )}
          </main>

          {/* Footer */}
          <footer className="px-6 py-6 border-t border-zinc-100 text-center text-xs text-zinc-400 bg-zinc-50/50">
            © {new Date().getFullYear()} {config.siteName}. Powered by Plug-and-Play Dynamic CMS.
          </footer>
        </div>
      </div>
    </div>
  );
}
