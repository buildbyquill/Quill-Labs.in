import React, { useState, useRef, useCallback } from 'react';
import {
  UploadCloud,
  Image as ImageIcon,
  Trash2,
  Copy,
  Check,
  Search,
  ExternalLink,
  HardDrive,
  Filter,
  X,
  FileImage,
} from 'lucide-react';
import { MediaAsset } from '../../types/cms';
import { CMSStorageService } from '../../services/storage';
import { useToast } from '../ui/Toast';

interface MediaManagerProps {
  storageService: CMSStorageService;
  isPickerModal?: boolean;
  onSelectAsset?: (asset: MediaAsset) => void;
  onClose?: () => void;
}

export function MediaManager({
  storageService,
  isPickerModal = false,
  onSelectAsset,
  onClose,
}: MediaManagerProps) {
  const { success, error } = useToast();
  const [assets, setAssets] = useState<MediaAsset[]>(() => storageService.getMediaAssets());
  const [searchQuery, setSearchQuery] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const handleCopyUrl = (asset: MediaAsset) => {
    navigator.clipboard.writeText(asset.url);
    setCopiedId(asset.id);
    success('Copied to clipboard', asset.url);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const processFileUpload = useCallback(
    async (file: File) => {
      if (!file.type.startsWith('image/')) {
        error('Invalid file type', 'Please upload PNG, JPEG, WEBP, or SVG images.');
        return;
      }

      setUploading(true);

      // Read dimensions using an Image object
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        const img = new Image();
        img.onload = () => {
          const newAsset: MediaAsset = {
            id: `asset-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
            name: file.name.replace(/\s+/g, '-').toLowerCase(),
            url: dataUrl, // In real Supabase, would be `${supabaseUrl}/storage/v1/object/public/cms-media/${filename}`
            size: file.size,
            mimeType: file.type,
            width: img.width,
            height: img.height,
            altText: file.name.split('.')[0].replace(/[-_]/g, ' '),
            uploadedAt: new Date().toISOString(),
            bucket: 'cms-media',
          };

          storageService.addMediaAsset(newAsset);
          setAssets(storageService.getMediaAssets());
          setUploading(false);
          success('Asset uploaded to Supabase Storage', `${file.name} saved to bucket [cms-media]`);

          if (isPickerModal) {
            setSelectedAssetId(newAsset.id);
          }
        };
        img.src = dataUrl;
      };
      reader.readAsDataURL(file);
    },
    [error, isPickerModal, storageService, success]
  );

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      processFileUpload(file);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFileUpload(e.target.files[0]);
    }
  };

  const handleDelete = (id: string, name: string) => {
    if (confirm(`Remove "${name}" from media library?`)) {
      storageService.deleteMediaAsset(id);
      setAssets(storageService.getMediaAssets());
      if (selectedAssetId === id) setSelectedAssetId(null);
      success('Asset deleted', `${name} removed from storage.`);
    }
  };

  const filteredAssets = assets.filter(
    (a) =>
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (a.altText && a.altText.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const content = (
    <div className="space-y-6">
      {/* Header Info & Storage Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-zinc-900 dark:text-white flex items-center gap-2">
            <HardDrive className="w-5 h-5 text-indigo-500" />
            Universal Media Manager
          </h2>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">
            Supabase Storage bucket: <code className="bg-zinc-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded font-mono text-zinc-700 dark:text-zinc-300">cms-media</code>
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-medium border border-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            Supabase S3 Active
          </span>
          <span className="text-zinc-400">|</span>
          <span className="text-zinc-500">{assets.length} total assets</span>
        </div>
      </div>

      {/* Drag & Drop Upload Zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-200 ${
          isDragging
            ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/20 scale-[1.01]'
            : 'border-zinc-300 dark:border-zinc-700 bg-zinc-50/50 dark:bg-zinc-900/50 hover:border-zinc-400 dark:hover:border-zinc-600 hover:bg-zinc-50 dark:hover:bg-zinc-900'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/svg+xml"
          className="hidden"
          onChange={handleFileChange}
        />
        <div className="max-w-md mx-auto flex flex-col items-center">
          <div className="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-3 shadow-xs">
            {uploading ? (
              <div className="w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
            ) : (
              <UploadCloud className="w-6 h-6" />
            )}
          </div>
          <h3 className="text-sm font-semibold text-zinc-900 dark:text-white">
            {uploading ? 'Uploading to Supabase Storage...' : 'Drop image files here, or browse from computer'}
          </h3>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1">
            Supports PNG, JPEG, WebP, SVG up to 15MB. Automatically generates public CDN URLs.
          </p>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search media by filename or alt text..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-zinc-900 dark:focus:ring-white"
          />
        </div>

        {isPickerModal && (
          <div className="text-xs text-zinc-500 flex items-center gap-1.5">
            <FileImage className="w-4 h-4 text-indigo-500" />
            Select an image below to insert into your content
          </div>
        )}
      </div>

      {/* Media Grid */}
      {filteredAssets.length === 0 ? (
        <div className="text-center py-16 border border-zinc-200 dark:border-zinc-800 rounded-2xl bg-white dark:bg-zinc-900">
          <ImageIcon className="w-10 h-10 text-zinc-300 dark:text-zinc-600 mx-auto mb-2" />
          <p className="text-sm font-medium text-zinc-700 dark:text-zinc-300">No media assets found</p>
          <p className="text-xs text-zinc-400 mt-1">Upload an image or adjust your search filter.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredAssets.map((asset) => {
            const isSelected = selectedAssetId === asset.id;
            return (
              <div
                key={asset.id}
                onClick={() => {
                  if (isPickerModal) setSelectedAssetId(asset.id);
                }}
                className={`group relative rounded-xl border bg-white dark:bg-zinc-900 overflow-hidden flex flex-col transition-all duration-200 ${
                  isPickerModal ? 'cursor-pointer' : ''
                } ${
                  isSelected
                    ? 'ring-2 ring-indigo-500 border-indigo-500 shadow-md'
                    : 'border-zinc-200 dark:border-zinc-800 hover:border-zinc-300 dark:hover:border-zinc-700 hover:shadow-xs'
                }`}
              >
                {/* Thumbnail */}
                <div className="aspect-16/10 bg-zinc-100 dark:bg-zinc-950 overflow-hidden relative flex items-center justify-center">
                  <img
                    src={asset.url}
                    alt={asset.altText || asset.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    loading="lazy"
                  />
                  {isSelected && (
                    <div className="absolute top-2 right-2 bg-indigo-600 text-white rounded-full p-1 shadow-md">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  )}
                </div>

                {/* Info & Meta */}
                <div className="p-3.5 flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-semibold text-zinc-900 dark:text-zinc-100 truncate" title={asset.name}>
                      {asset.name}
                    </h4>
                    <div className="flex items-center gap-2 text-[11px] text-zinc-400 mt-1">
                      <span>{formatFileSize(asset.size)}</span>
                      {asset.width && asset.height && (
                        <>
                          <span>•</span>
                          <span>
                            {asset.width}×{asset.height}
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-3 pt-3 border-t border-zinc-100 dark:border-zinc-800/80 flex items-center justify-between text-xs">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCopyUrl(asset);
                      }}
                      className="inline-flex items-center gap-1 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-white transition-colors"
                      title="Copy Public CDN URL"
                    >
                      {copiedId === asset.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-500" />
                          <span className="text-emerald-600 dark:text-emerald-400 font-medium">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy URL</span>
                        </>
                      )}
                    </button>

                    <div className="flex items-center gap-1.5">
                      <a
                        href={asset.url}
                        target="_blank"
                        rel="noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="p-1 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-colors"
                        title="Open full size"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(asset.id, asset.name);
                        }}
                        className="p-1 text-zinc-400 hover:text-rose-600 transition-colors"
                        title="Delete asset"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Picker Modal Footer */}
      {isPickerModal && (
        <div className="sticky bottom-0 bg-white/95 dark:bg-zinc-900/95 backdrop-blur-md p-4 -mx-6 -mb-6 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
          <div className="text-xs text-zinc-500">
            {selectedAssetId ? 'Asset ready to insert' : 'Click an image card to select'}
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs font-medium text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={!selectedAssetId}
              onClick={() => {
                const asset = assets.find((a) => a.id === selectedAssetId);
                if (asset && onSelectAsset) {
                  onSelectAsset(asset);
                }
              }}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-zinc-900 dark:bg-white dark:text-zinc-900 rounded-lg disabled:opacity-40 hover:opacity-90 transition-opacity"
            >
              Confirm Selection
            </button>
          </div>
        </div>
      )}
    </div>
  );

  if (isPickerModal) {
    return (
      <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
        <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-gray-200 shadow-xl p-6 relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1 text-gray-400 hover:text-black rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          {content}
        </div>
      </div>
    );
  }

  return content;
}

export function MediaPickerModal({
  storageService,
  onSelectAsset,
  onClose,
}: {
  storageService: CMSStorageService;
  onSelectAsset?: (asset: MediaAsset) => void;
  onClose?: () => void;
}) {
  return (
    <MediaManager
      storageService={storageService}
      isPickerModal
      onSelectAsset={onSelectAsset}
      onClose={onClose}
    />
  );
}
