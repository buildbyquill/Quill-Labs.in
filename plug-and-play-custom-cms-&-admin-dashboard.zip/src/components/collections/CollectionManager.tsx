import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Edit2,
  Trash2,
  CheckCircle,
  Clock,
  ExternalLink,
  Save,
  X,
  AlertCircle,
  RefreshCw,
  Image as ImageIcon,
  Layers,
  ArrowUpDown,
  Download,
  Eye,
} from 'lucide-react';
import { CollectionDefinition, CMSConfig, MediaAsset, FieldDefinition } from '../../types/cms';
import { CMSStorageService, CollectionItem } from '../../services/storage';
import { triggerRevalidation } from '../../services/revalidation';
import { validateFieldValues } from '../../services/validation';
import { useToast } from '../ui/Toast';
import { RichTextEditor } from '../editor/RichTextEditor';
import { MediaManager } from '../media/MediaManager';
import { TableSkeleton } from '../ui/Skeleton';

interface CollectionManagerProps {
  key?: string | number;
  collection: CollectionDefinition;
  config: CMSConfig;
  storageService: CMSStorageService;
  onRevalidationTriggered?: () => void;
  onPreviewCollection?: (path: string) => void;
}

export function CollectionManager({
  collection,
  config,
  storageService,
  onRevalidationTriggered,
  onPreviewCollection,
}: CollectionManagerProps) {
  const { success, error, info } = useToast();
  const [items, setItems] = useState<CollectionItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'published' | 'draft'>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [selectedItemIds, setSelectedItemIds] = useState<string[]>([]);

  // Item Form Modal (Add / Edit)
  const [editingItem, setEditingItem] = useState<CollectionItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalValues, setModalValues] = useState<Record<string, any>>({});
  const [modalStatus, setModalStatus] = useState<'published' | 'draft'>('published');
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  // Media picker modal
  const [activeMediaField, setActiveMediaField] = useState<string | null>(null);
  const [isMediaPickerOpen, setIsMediaPickerOpen] = useState(false);

  // Load items
  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      const data = storageService.getCollectionItems(collection.id, config);
      setItems(data);
      setLoading(false);
    }, 100);
    return () => clearTimeout(timer);
  }, [collection.id, config, storageService]);

  // Unique categories for filtering
  const categories = useMemo(() => {
    if (!collection.categoryField) return [];
    const catFieldDef = collection.fields.find((f) => f.name === collection.categoryField);
    if (catFieldDef?.options) {
      return catFieldDef.options.map((o) => o.value);
    }
    const set = new Set<string>();
    items.forEach((item) => {
      const val = item.values[collection.categoryField!];
      if (val) set.add(String(val));
    });
    return Array.from(set);
  }, [collection, items]);

  // Filtered & searched items
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      const primaryVal = String(item.values[collection.primaryField] || '').toLowerCase();
      const matchesSearch = primaryVal.includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
      const matchesCategory =
        categoryFilter === 'all' ||
        !collection.categoryField ||
        item.values[collection.categoryField] === categoryFilter;

      return matchesSearch && matchesStatus && matchesCategory;
    });
  }, [items, searchQuery, statusFilter, categoryFilter, collection]);

  // Open Add Item Modal
  const handleOpenAdd = () => {
    const defaultVals: Record<string, any> = {};
    collection.fields.forEach((f) => {
      defaultVals[f.name] = f.defaultValue ?? (f.type === 'boolean' ? false : '');
    });
    setModalValues(defaultVals);
    setModalStatus('published');
    setEditingItem(null);
    setFormErrors({});
    setIsModalOpen(true);
  };

  // Open Edit Item Modal
  const handleOpenEdit = (item: CollectionItem) => {
    setModalValues({ ...item.values });
    setModalStatus(item.status);
    setEditingItem(item);
    setFormErrors({});
    setIsModalOpen(true);
  };

  // Delete Item
  const handleDeleteItem = (id: string) => {
    if (confirm(`Are you sure you want to delete this ${collection.singularTitle.toLowerCase()}?`)) {
      const updated = items.filter((i) => i.id !== id);
      storageService.saveCollectionItems(collection.id, updated);
      setItems(updated);
      setSelectedItemIds((prev) => prev.filter((i) => i !== id));
      success('Item deleted', `Removed from ${collection.title}`);
    }
  };

  // Toggle item status (Published <-> Draft)
  const handleToggleStatus = async (item: CollectionItem) => {
    const nextStatus = item.status === 'published' ? 'draft' : 'published';
    const updated = items.map((i) =>
      i.id === item.id ? { ...i, status: nextStatus, updatedAt: new Date().toISOString() } : i
    );
    storageService.saveCollectionItems(collection.id, updated);
    setItems(updated);

    // Trigger revalidation
    const slug = item.values.slug ? `${collection.slug}/${item.values.slug}` : collection.slug;
    await triggerRevalidation({
      path: slug,
      triggerSource: 'collection_save',
      config,
      storageService,
    });

    success(
      `Status changed to ${nextStatus.toUpperCase()}`,
      `Revalidated ISR path "${slug}" on Next.js`
    );

    if (onRevalidationTriggered) onRevalidationTriggered();
  };

  // Save Modal (Create or Update)
  const handleSaveModal = async () => {
    // 1. Zod validation
    const validation = validateFieldValues(collection.fields, modalValues);
    if (!validation.isValid) {
      setFormErrors(validation.errors);
      error('Validation Failed', 'Please review highlighted form inputs.');
      return;
    }

    setSubmitting(true);

    try {
      let updatedItems: CollectionItem[];
      const now = new Date().toISOString();

      if (editingItem) {
        // Update existing
        updatedItems = items.map((i) =>
          i.id === editingItem.id
            ? {
                ...i,
                status: modalStatus,
                updatedAt: now,
                values: validation.sanitizedData,
              }
            : i
        );
      } else {
        // Create new
        const newItem: CollectionItem = {
          id: `${collection.id}-${Date.now()}`,
          status: modalStatus,
          createdAt: now,
          updatedAt: now,
          values: validation.sanitizedData,
        };
        updatedItems = [newItem, ...items];
      }

      storageService.saveCollectionItems(collection.id, updatedItems);
      setItems(updatedItems);
      setIsModalOpen(false);

      // Revalidate Next.js cache
      const slug = validation.sanitizedData.slug
        ? `${collection.slug}/${validation.sanitizedData.slug}`
        : collection.slug;

      const revalResult = await triggerRevalidation({
        path: slug,
        triggerSource: 'collection_save',
        config,
        storageService,
      });

      success(
        editingItem ? 'Changes Published' : 'New Item Created',
        `Revalidated path "${slug}" in ${revalResult.latencyMs}ms (${revalResult.statusCode} OK)`
      );

      if (onRevalidationTriggered) onRevalidationTriggered();
    } catch (err: any) {
      error('Failed to save', err.message);
    } finally {
      setSubmitting(false);
    }
  };

  // Bulk actions
  const handleBulkStatus = (status: 'published' | 'draft') => {
    const updated = items.map((i) => (selectedItemIds.includes(i.id) ? { ...i, status } : i));
    storageService.saveCollectionItems(collection.id, updated);
    setItems(updated);
    setSelectedItemIds([]);
    success(`Updated ${selectedItemIds.length} items to ${status}`);
  };

  const handleBulkDelete = () => {
    if (confirm(`Delete ${selectedItemIds.length} selected items?`)) {
      const updated = items.filter((i) => !selectedItemIds.includes(i.id));
      storageService.saveCollectionItems(collection.id, updated);
      setItems(updated);
      setSelectedItemIds([]);
      success(`Deleted ${selectedItemIds.length} items.`);
    }
  };

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(items, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${collection.id}-export.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    success('Export generated', `Downloaded ${collection.id}-export.json`);
  };

  if (loading) {
    return <TableSkeleton rows={6} />;
  }

  return (
    <div className="space-y-6 max-w-6xl pb-16">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl font-bold tracking-tight text-gray-900">
              {collection.title}
            </h1>
            <span className="font-mono text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-500">
              {collection.slug}
            </span>
            <span className="text-xs text-gray-400">
              ({items.length} {items.length === 1 ? 'item' : 'items'})
            </span>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            {collection.description || `Manage dynamic structured records for ${collection.title}.`}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {onPreviewCollection && (
            <button
              type="button"
              onClick={() => onPreviewCollection(collection.slug)}
              className="px-4 py-2 text-sm font-medium border border-gray-200 rounded-md hover:bg-gray-50 bg-white text-gray-800 transition-colors flex items-center gap-1.5"
            >
              <ExternalLink className="w-3.5 h-3.5 text-gray-500" />
              Preview Feed
            </button>
          )}

          <button
            type="button"
            onClick={handleExportJSON}
            className="px-3.5 py-2 text-sm font-medium border border-gray-200 rounded-md hover:bg-gray-50 bg-white text-gray-800 transition-colors flex items-center gap-1.5"
            title="Export collection as JSON"
          >
            <Download className="w-3.5 h-3.5 text-gray-500" />
            Export
          </button>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="px-4 py-2 text-sm font-medium bg-black text-white rounded-md hover:bg-gray-900 shadow-xs flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" />
            New {collection.singularTitle}
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`Search ${collection.title.toLowerCase()}...`}
            className="w-full pl-10 pr-4 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg focus:ring-1 focus:ring-black outline-hidden"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Status Filter */}
          {collection.supportsDrafts && (
            <div className="flex items-center bg-gray-100 p-0.5 rounded-md text-xs">
              <button
                type="button"
                onClick={() => setStatusFilter('all')}
                className={`px-2.5 py-1 rounded font-medium transition-all ${
                  statusFilter === 'all'
                    ? 'bg-white text-black shadow-xs'
                    : 'text-gray-500 hover:text-black'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('published')}
                className={`px-2.5 py-1 rounded font-medium transition-all ${
                  statusFilter === 'published'
                    ? 'bg-white text-green-700 shadow-xs'
                    : 'text-gray-500 hover:text-black'
                }`}
              >
                Published
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('draft')}
                className={`px-2.5 py-1 rounded font-medium transition-all ${
                  statusFilter === 'draft'
                    ? 'bg-white text-amber-700 shadow-xs'
                    : 'text-gray-500 hover:text-black'
                }`}
              >
                Drafts
              </button>
            </div>
          )}

          {/* Category Dropdown */}
          {categories.length > 0 && (
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-gray-700 focus:ring-1 focus:ring-black outline-hidden"
            >
              <option value="all">All Categories</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* Bulk Action Banner */}
      {selectedItemIds.length > 0 && (
        <div className="p-3 bg-black text-white rounded-lg flex items-center justify-between text-xs animate-in fade-in">
          <span>{selectedItemIds.length} items selected</span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => handleBulkStatus('published')}
              className="px-2.5 py-1 bg-green-700 hover:bg-green-600 rounded font-medium"
            >
              Publish Selected
            </button>
            <button
              type="button"
              onClick={() => handleBulkStatus('draft')}
              className="px-2.5 py-1 bg-gray-800 hover:bg-gray-700 rounded font-medium"
            >
              Draft Selected
            </button>
            <button
              type="button"
              onClick={handleBulkDelete}
              className="px-2.5 py-1 bg-red-700 hover:bg-red-600 rounded font-medium"
            >
              Delete Selected
            </button>
          </div>
        </div>
      )}

      {/* Reusable Data Table */}
      <div className="border border-gray-200 rounded-xl overflow-hidden bg-white">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50 text-[10px] font-semibold text-gray-500 uppercase tracking-wider">
                <th className="py-3 px-4 w-10">
                  <input
                    type="checkbox"
                    checked={selectedItemIds.length === filteredItems.length && filteredItems.length > 0}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedItemIds(filteredItems.map((i) => i.id));
                      } else {
                        setSelectedItemIds([]);
                      }
                    }}
                    className="rounded border-gray-300 text-black focus:ring-black"
                  />
                </th>
                <th className="py-3 px-4">{collection.fields.find((f) => f.name === collection.primaryField)?.label || 'Title'}</th>
                {collection.categoryField && <th className="py-3 px-4">Category</th>}
                {collection.supportsDrafts && <th className="py-3 px-4">Status</th>}
                <th className="py-3 px-4">Updated</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 text-xs">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-gray-400">
                    No {collection.title.toLowerCase()} found matching your filter criteria.
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => {
                  const isSelected = selectedItemIds.includes(item.id);
                  const primaryVal = item.values[collection.primaryField] || 'Untitled';
                  const imageField = collection.fields.find((f) => f.type === 'image');
                  const imageUrl = imageField ? item.values[imageField.name] : null;
                  const categoryVal = collection.categoryField ? item.values[collection.categoryField] : null;

                  return (
                    <tr
                      key={item.id}
                      className={`hover:bg-gray-50/70 transition-colors ${
                        isSelected ? 'bg-gray-50' : ''
                      }`}
                    >
                      <td className="py-3.5 px-4">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedItemIds([...selectedItemIds, item.id]);
                            } else {
                              setSelectedItemIds(selectedItemIds.filter((id) => id !== item.id));
                            }
                          }}
                          className="rounded border-gray-300 text-black focus:ring-black"
                        />
                      </td>

                      <td className="py-3.5 px-4 font-medium text-gray-900">
                        <div className="flex items-center gap-3">
                          {imageUrl && (
                            <img
                              src={imageUrl}
                              alt=""
                              className="w-9 h-9 rounded-md object-cover border border-gray-200 shrink-0"
                            />
                          )}
                          <div className="min-w-0">
                            <span className="truncate block font-semibold hover:underline cursor-pointer" onClick={() => handleOpenEdit(item)}>
                              {primaryVal}
                            </span>
                            {item.values.slug && (
                              <span className="text-[11px] font-mono text-gray-400 truncate block">
                                /{item.values.slug}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {collection.categoryField && (
                        <td className="py-3.5 px-4 text-gray-600">
                          {categoryVal ? (
                            <span className="px-2 py-0.5 rounded bg-gray-100 text-[11px] font-medium text-gray-700">
                              {categoryVal}
                            </span>
                          ) : (
                            '—'
                          )}
                        </td>
                      )}

                      {collection.supportsDrafts && (
                        <td className="py-3.5 px-4">
                          <button
                            type="button"
                            onClick={() => handleToggleStatus(item)}
                            title="Click to toggle status"
                            className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-medium transition-colors ${
                              item.status === 'published'
                                ? 'bg-green-50 text-green-700 border border-green-200'
                                : 'bg-gray-100 text-gray-600'
                            }`}
                          >
                            {item.status === 'published' ? 'Published' : 'Draft'}
                          </button>
                        </td>
                      )}

                      <td className="py-3.5 px-4 text-gray-400 text-[11px] whitespace-nowrap">
                        {new Date(item.updatedAt).toLocaleDateString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                        })}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(item)}
                            className="p-1.5 text-gray-400 hover:text-black rounded hover:bg-gray-100 transition-colors"
                            title="Edit record"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteItem(item.id)}
                            className="p-1.5 text-gray-400 hover:text-red-600 rounded hover:bg-red-50 transition-colors"
                            title="Delete record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Dynamic Item Form Modal (Add / Edit) */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-gray-200 shadow-xl p-6 relative">
            <div className="flex items-center justify-between border-b border-gray-100 pb-4 mb-6">
              <div>
                <h3 className="text-lg font-bold text-gray-900">
                  {editingItem ? `Edit ${collection.singularTitle}` : `New ${collection.singularTitle}`}
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  Dynamic schema record with automatic Next.js ISR revalidation.
                </p>
              </div>

              <div className="flex items-center gap-3">
                {collection.supportsDrafts && (
                  <div className="flex items-center gap-1 bg-gray-100 p-0.5 rounded-md text-xs">
                    <button
                      type="button"
                      onClick={() => setModalStatus('published')}
                      className={`px-2.5 py-1 rounded font-medium transition-all ${
                        modalStatus === 'published'
                          ? 'bg-black text-white shadow-xs'
                          : 'text-gray-500 hover:text-black'
                      }`}
                    >
                      Published
                    </button>
                    <button
                      type="button"
                      onClick={() => setModalStatus('draft')}
                      className={`px-2.5 py-1 rounded font-medium transition-all ${
                        modalStatus === 'draft'
                          ? 'bg-white text-amber-700 shadow-xs'
                          : 'text-gray-500 hover:text-black'
                      }`}
                    >
                      Draft
                    </button>
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 text-gray-400 hover:text-black rounded"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Dynamic Field Form Inputs */}
            <div className="space-y-5">
              {collection.fields.map((field) => {
                const val = modalValues[field.name];
                const err = formErrors[field.name];

                return (
                  <div key={field.name} className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        {field.label} {field.required && <span className="text-red-500">*</span>}
                      </label>
                      <span className="text-[10px] font-mono text-gray-400">
                        {field.name}
                      </span>
                    </div>

                    {field.type === 'text' && (
                      <input
                        type="text"
                        value={val ?? ''}
                        placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}...`}
                        onChange={(e) => {
                          setModalValues((prev) => ({ ...prev, [field.name]: e.target.value }));
                          if (formErrors[field.name]) {
                            setFormErrors((prev) => {
                              const n = { ...prev };
                              delete n[field.name];
                              return n;
                            });
                          }
                        }}
                        className={`w-full px-4 py-2.5 bg-gray-50 border rounded-lg text-sm focus:ring-1 focus:ring-black outline-hidden transition-all ${
                          err ? 'border-red-400 bg-red-50/20' : 'border-gray-200'
                        }`}
                      />
                    )}

                    {field.type === 'textarea' && (
                      <textarea
                        rows={3}
                        value={val ?? ''}
                        placeholder={field.placeholder}
                        onChange={(e) => {
                          setModalValues((prev) => ({ ...prev, [field.name]: e.target.value }));
                          if (formErrors[field.name]) {
                            setFormErrors((prev) => {
                              const n = { ...prev };
                              delete n[field.name];
                              return n;
                            });
                          }
                        }}
                        className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-1 focus:ring-black outline-hidden resize-none leading-relaxed"
                      />
                    )}

                    {field.type === 'richText' && (
                      <RichTextEditor
                        value={val ?? ''}
                        onChange={(text) => setModalValues((prev) => ({ ...prev, [field.name]: text }))}
                        onOpenMediaPicker={() => {
                          setActiveMediaField(field.name);
                          setIsMediaPickerOpen(true);
                        }}
                      />
                    )}

                    {field.type === 'boolean' && (
                      <div className="flex items-center h-[42px]">
                        <button
                          type="button"
                          role="switch"
                          aria-checked={!!val}
                          onClick={() => setModalValues((prev) => ({ ...prev, [field.name]: !val }))}
                          className={`w-10 h-5 rounded-full relative transition-colors ${
                            val ? 'bg-black' : 'bg-gray-200'
                          }`}
                        >
                          <span
                            className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-transform ${
                              val ? 'right-1' : 'left-1'
                            }`}
                          />
                        </button>
                        <span className="text-xs text-gray-500 ml-3">
                          {val ? 'Enabled' : 'Disabled'}
                        </span>
                      </div>
                    )}

                    {field.type === 'number' && (
                      <input
                        type="number"
                        value={val ?? 0}
                        onChange={(e) => setModalValues((prev) => ({ ...prev, [field.name]: parseFloat(e.target.value) || 0 }))}
                        className="w-full max-w-xs px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-1 focus:ring-black outline-hidden"
                      />
                    )}

                    {field.type === 'select' && (
                      <select
                        value={val ?? ''}
                        onChange={(e) => setModalValues((prev) => ({ ...prev, [field.name]: e.target.value }))}
                        className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-1 focus:ring-black outline-hidden"
                      >
                        {field.options?.map((opt) => (
                          <option key={opt.value} value={opt.value}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    )}

                    {field.type === 'image' && (
                      <div className="flex gap-3 items-center">
                        {val && (
                          <img
                            src={val}
                            alt=""
                            className="w-14 h-14 rounded-lg object-cover border border-gray-200 shrink-0"
                          />
                        )}
                        <input
                          type="text"
                          value={val ?? ''}
                          placeholder="https://..."
                          onChange={(e) => setModalValues((prev) => ({ ...prev, [field.name]: e.target.value }))}
                          className="flex-1 px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs font-mono focus:ring-1 focus:ring-black outline-hidden"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            setActiveMediaField(field.name);
                            setIsMediaPickerOpen(true);
                          }}
                          className="px-3.5 py-2 text-xs bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-md flex items-center gap-1.5"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                          Browse
                        </button>
                      </div>
                    )}

                    {field.type === 'url' && (
                      <input
                        type="url"
                        value={val ?? ''}
                        placeholder={field.placeholder || 'https://...'}
                        onChange={(e) => setModalValues((prev) => ({ ...prev, [field.name]: e.target.value }))}
                        className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-1 focus:ring-black outline-hidden font-mono text-xs"
                      />
                    )}

                    {field.description && (
                      <p className="text-[11px] text-gray-400">{field.description}</p>
                    )}
                    {err && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" /> {err}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Modal Actions */}
            <div className="mt-8 pt-4 border-t border-gray-100 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 text-sm font-medium border border-gray-200 rounded-md hover:bg-gray-50 bg-white text-gray-700 transition-colors"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleSaveModal}
                disabled={submitting}
                className="px-5 py-2 text-sm font-medium bg-black text-white rounded-md hover:bg-gray-900 shadow-xs flex items-center gap-2 transition-colors disabled:opacity-50"
              >
                {submitting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Purging Next.js ISR...
                  </>
                ) : (
                  <>
                    <Save className="w-3.5 h-3.5" />
                    Save &amp; Revalidate
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Media Picker Modal */}
      {isMediaPickerOpen && (
        <MediaManager
          storageService={storageService}
          isPickerModal
          onSelectAsset={(asset) => {
            if (activeMediaField) {
              setModalValues((prev) => ({ ...prev, [activeMediaField]: asset.url }));
            }
            setIsMediaPickerOpen(false);
            setActiveMediaField(null);
            success('Asset Selected', `${asset.name} inserted into form.`);
          }}
          onClose={() => setIsMediaPickerOpen(false)}
        />
      )}
    </div>
  );
}
