import React, { useState, createContext, useContext } from 'react';
import { ShieldCheck, ShieldAlert, LogOut, UserCheck, Key, Lock, ArrowRight, Sparkles } from 'lucide-react';
import { ClerkUser } from '../../types/cms';

interface ClerkAuthContextType {
  user: ClerkUser | null;
  isAdmin: boolean;
  signInAs: (email: string, name?: string) => void;
  signOut: () => void;
  allowedEmails: string[];
}

const ClerkAuthContext = createContext<ClerkAuthContextType | undefined>(undefined);

export function ClerkAuthProvider({
  children,
  allowedAdminEmails = ['buildbyquill@gmail.com', 'admin@client.com'],
}: {
  children: React.ReactNode;
  allowedAdminEmails?: string[];
}) {
  // Default logged in as the verified user email from metadata/request
  const [user, setUser] = useState<ClerkUser | null>({
    id: 'user_clerk_982bca1',
    firstName: 'Quill',
    lastName: 'Admin',
    email: 'buildbyquill@gmail.com',
    imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=120&q=80',
    role: 'admin',
    lastSignIn: new Date().toISOString(),
  });

  const signInAs = (email: string, name: string = 'User') => {
    const isAuthorized = allowedAdminEmails.some((e) => e.toLowerCase() === email.toLowerCase());
    setUser({
      id: `user_clerk_${Math.random().toString(36).substr(2, 7)}`,
      firstName: name.split(' ')[0] || 'Client',
      lastName: name.split(' ')[1] || 'User',
      email,
      imageUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80',
      role: isAuthorized ? 'admin' : 'unauthorized',
      lastSignIn: new Date().toISOString(),
    });
  };

  const signOut = () => {
    setUser(null);
  };

  const isAdmin = !!user && allowedAdminEmails.some((e) => e.toLowerCase() === user.email.toLowerCase());

  return (
    <ClerkAuthContext.Provider value={{ user, isAdmin, signInAs, signOut, allowedEmails: allowedAdminEmails }}>
      {children}
    </ClerkAuthContext.Provider>
  );
}

export function useClerkAuth() {
  const ctx = useContext(ClerkAuthContext);
  if (!ctx) {
    throw new Error('useClerkAuth must be used within ClerkAuthProvider');
  }
  return ctx;
}

export function ClerkAuthGuard({
  children,
  tenantSiteName,
}: {
  children: React.ReactNode;
  tenantSiteName: string;
}) {
  const { user, isAdmin, signInAs, signOut, allowedEmails } = useClerkAuth();
  const [customEmail, setCustomEmail] = useState('');

  // 1. Unauthenticated State (Clerk Sign In Modal)
  if (!user) {
    return (
      <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center p-4 selection:bg-zinc-800">
        <div className="max-w-md w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-8 shadow-2xl relative overflow-hidden">
          {/* Subtle brand glow */}
          <div className="absolute -top-24 -left-24 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Clerk Header */}
          <div className="flex items-center gap-2.5 mb-6">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow-md shadow-indigo-600/30">
              C
            </div>
            <div>
              <span className="text-xs font-semibold tracking-wider text-zinc-400 uppercase">Clerk Security Guard</span>
              <h2 className="text-lg font-bold text-white leading-none mt-0.5">Admin Authentication</h2>
            </div>
          </div>

          <p className="text-sm text-zinc-400 mb-6 leading-relaxed">
            Sign in to access the CMS management dashboard for <span className="text-zinc-200 font-medium">{tenantSiteName}</span>.
          </p>

          <div className="space-y-4">
            <button
              type="button"
              onClick={() => signInAs(allowedEmails[0], 'Quill Admin')}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-white text-zinc-950 font-semibold text-sm hover:bg-zinc-100 transition-colors shadow-xs"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Sign In as Authorized Admin ({allowedEmails[0]})
            </button>

            <div className="relative flex items-center justify-center my-4">
              <div className="border-t border-zinc-800 w-full" />
              <span className="bg-zinc-900 px-3 text-[11px] text-zinc-500 uppercase tracking-wider absolute">or test email gate</span>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (customEmail) signInAs(customEmail, 'Custom Tester');
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1">Enter Email Address</label>
                <input
                  type="email"
                  required
                  value={customEmail}
                  onChange={(e) => setCustomEmail(e.target.value)}
                  placeholder="e.g. external-guest@client.com"
                  className="w-full px-3.5 py-2 text-sm bg-zinc-950 border border-zinc-800 rounded-xl text-white placeholder:text-zinc-600 focus:outline-hidden focus:border-indigo-500"
                />
              </div>
              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-sm font-medium transition-colors"
              >
                Sign In with Clerk <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            <div className="mt-4 p-3 rounded-xl bg-zinc-950/70 border border-zinc-800 text-[11px] text-zinc-400">
              <span className="font-semibold text-zinc-300">Authorized Admin Whitelist:</span>
              <div className="mt-1 font-mono text-zinc-400 space-y-0.5">
                {allowedEmails.map((e) => (
                  <div key={e} className="truncate">• {e}</div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 2. Unauthorized Access Denied State (User is logged in via Clerk, but email is NOT in ADMIN_EMAILS)
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full bg-zinc-900 border border-rose-900/40 rounded-2xl p-8 shadow-2xl relative">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/10 text-rose-400 flex items-center justify-center mb-4 border border-rose-500/20">
            <ShieldAlert className="w-6 h-6" />
          </div>

          <h2 className="text-xl font-bold text-white mb-2">Access Restricted (403 Forbidden)</h2>
          <p className="text-sm text-zinc-400 mb-4 leading-relaxed">
            You are signed in as <span className="text-zinc-200 font-mono font-medium">{user.email}</span>, which is not registered as an authorized administrator for this tenant.
          </p>

          <div className="p-3.5 rounded-xl bg-rose-950/20 border border-rose-800/40 text-xs text-rose-300 mb-6 leading-relaxed">
            Client CMS access is restricted by Clerk middleware to specific administrator emails declared in <code className="bg-rose-950 px-1 py-0.5 rounded font-mono text-rose-200">ADMIN_EMAILS</code> environment variable.
          </div>

          <div className="space-y-3">
            <button
              type="button"
              onClick={() => signInAs(allowedEmails[0], 'Quill Admin')}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-white text-zinc-950 font-semibold text-sm hover:bg-zinc-100 transition-colors"
            >
              <UserCheck className="w-4 h-4 text-emerald-600" />
              Switch to Authorized Admin ({allowedEmails[0]})
            </button>

            <button
              type="button"
              onClick={signOut}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-xl border border-zinc-800 hover:bg-zinc-800 text-zinc-400 hover:text-white text-sm transition-colors"
            >
              <LogOut className="w-4 h-4" /> Sign Out
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 3. Authorized State - Render the Protected Admin Dashboard
  return <>{children}</>;
}
