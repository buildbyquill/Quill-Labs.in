import React, { useState, useEffect, useCallback } from 'react';
import {
  Settings,
  Database,
  Send,
  Trash2,
  Copy,
  Check,
  Globe,
  ExternalLink,
  Code,
  Download,
  Plus,
  RefreshCw,
  Sparkles,
  ShieldCheck,
  Layers,
  Key,
  Eye,
  Mail,
  Search,
  CheckCircle2,
  ChevronRight,
  Terminal,
  FileText,
} from 'lucide-react';
import {
  supabaseDropinService,
  SiteContentItem,
  SiteLeadItem,
  SupabaseConfig,
} from '../../services/supabaseDropin';
import { useToast } from '../ui/Toast';

const BRAND_COLOR_PRESETS = [
  { name: 'Royal Blue', hex: '#2563EB' },
  { name: 'Emerald', hex: '#059669' },
  { name: 'Violet', hex: '#7C3AED' },
  { name: 'Rose Red', hex: '#E11D48' },
  { name: 'Amber Gold', hex: '#D97706' },
  { name: 'Slate Charcoal', hex: '#0F172A' },
];

const SAMPLE_LOGOS = [
  { name: 'Abstract Gradient', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=120&q=80' },
  { name: 'Modern Tech', url: 'https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=120&q=80' },
  { name: 'Health & Clinic', url: 'https://images.unsplash.com/photo-1507652313519-d4e9174996dd?auto=format&fit=crop&w=120&q=80' },
  { name: 'Creative Studio', url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=120&q=80' },
];

export function SimpleDropinDashboard() {
  const { success, error: toastError } = useToast();

  // State for branding
  const [brandName, setBrandName] = useState('Apex Creative Studio');
  const [brandLogo, setBrandLogo] = useState('https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=120&q=80');
  const [brandColor, setBrandColor] = useState('#2563EB');

  // State for content fields
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [image, setImage] = useState('');
  const [customFields, setCustomFields] = useState<{ id: string; value: string }[]>([]);
  const [newKeyName, setNewKeyName] = useState('');
  const [newKeyValue, setNewKeyValue] = useState('');
  const [showAddCustom, setShowAddCustom] = useState(false);

  // State for leads
  const [leads, setLeads] = useState<SiteLeadItem[]>([]);
  const [leadSearch, setLeadSearch] = useState('');

  // Status & loading states
  const [loading, setLoading] = useState(false);
  const [savedAlert, setSavedAlert] = useState(false);
  const [lastSavedTime, setLastSavedTime] = useState<string | null>(null);

  // View modes: 'dashboard', 'split', 'website_preview', 'developer_hub'
  const [viewMode, setViewMode] = useState<'dashboard' | 'split' | 'website_preview' | 'developer_hub'>('dashboard');
  const [themeMode, setThemeMode] = useState<'dark' | 'light'>('dark');

  // Simulator contact form state
  const [simName, setSimName] = useState('Alex Morgan');
  const [simEmail, setSimEmail] = useState('alex.morgan@acme-corp.com');
  const [simMessage, setSimMessage] = useState('Hi! We would love to discuss a website overhaul. Could you send over a quote?');
  const [simSubmitting, setSimSubmitting] = useState(false);
  const [simSuccess, setSimSuccess] = useState(false);

  // Developer Hub tab
  const [activeCodeTab, setActiveCodeTab] = useState<'ai_prompt' | 'sql' | 'admin_page' | 'client_page' | 'contact_form' | 'env' | 'security' | 'supabase_creds'>('ai_prompt');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Live Supabase connection settings
  const [supabaseConfig, setSupabaseConfig] = useState<SupabaseConfig>(() =>
    supabaseDropinService.getConfig()
  );
  const [isTestingConnection, setIsTestingConnection] = useState(false);

  // Download Guide TXT
  const downloadGuideTxt = () => {
    const element = document.createElement('a');
    element.setAttribute('href', '/CLIENT_CMS_GUIDE.txt');
    element.setAttribute('download', 'CLIENT_CMS_GUIDE.txt');
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    success('Guide Downloaded', 'CLIENT_CMS_GUIDE.txt downloaded to your computer.');
  };

  // Load content and leads
  const loadData = useCallback(async () => {
    try {
      const content = await supabaseDropinService.fetchSiteContent();
      const contentMap: Record<string, string> = {};
      const custom: { id: string; value: string }[] = [];

      content.forEach((item) => {
        if (item.id === 'brand_name') setBrandName(item.value);
        else if (item.id === 'brand_logo') setBrandLogo(item.value);
        else if (item.id === 'brand_color') setBrandColor(item.value);
        else if (item.id === 'hero_title') setTitle(item.value);
        else if (item.id === 'hero_desc') setDesc(item.value);
        else if (item.id === 'hero_image') setImage(item.value);
        else custom.push({ id: item.id, value: item.value });
      });

      setCustomFields(custom);

      const leadsData = await supabaseDropinService.fetchSiteLeads();
      setLeads(leadsData);
    } catch (err) {
      console.error('Failed to load dropin data:', err);
    }
  }, []);

  useEffect(() => {
    loadData();
    const unsubscribe = supabaseDropinService.subscribe(() => {
      loadData();
    });
    return unsubscribe;
  }, [loadData]);

  // Save content handler
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const itemsToSave: { id: string; value: string }[] = [
        { id: 'brand_name', value: brandName },
        { id: 'brand_logo', value: brandLogo },
        { id: 'brand_color', value: brandColor },
        { id: 'hero_title', value: title },
        { id: 'hero_desc', value: desc },
        { id: 'hero_image', value: image },
        ...customFields,
      ];

      await supabaseDropinService.saveSiteContent(itemsToSave);

      setLoading(false);
      setSavedAlert(true);
      setLastSavedTime(new Date().toLocaleTimeString());
      success('Changes Saved', 'Website content updated and synced to Supabase.');
      setTimeout(() => setSavedAlert(false), 3500);
    } catch (err) {
      setLoading(false);
      toastError('Save Failed', 'Unable to save to database.');
    }
  };

  // Add custom key
  const handleAddCustomKey = () => {
    if (!newKeyName.trim()) return;
    const cleanId = newKeyName.trim().toLowerCase().replace(/\s+/g, '_');
    if (customFields.some((f) => f.id === cleanId) || ['hero_title', 'hero_desc', 'hero_image'].includes(cleanId)) {
      toastError('Key Exists', `Field "${cleanId}" already exists.`);
      return;
    }
    setCustomFields([...customFields, { id: cleanId, value: newKeyValue.trim() }]);
    setNewKeyName('');
    setNewKeyValue('');
    setShowAddCustom(false);
    success('Field Added', `Added editable key "${cleanId}". Remember to click Save Changes.`);
  };

  // Delete custom key
  const handleDeleteCustomKey = async (id: string) => {
    if (!confirm(`Delete editable field "${id}"?`)) return;
    await supabaseDropinService.deleteContentKey(id);
    setCustomFields(customFields.filter((f) => f.id !== id));
    success('Deleted', `Field "${id}" removed.`);
  };

  // Delete lead
  const handleDeleteLead = async (id: string) => {
    if (!confirm('Are you sure you want to delete this lead?')) return;
    await supabaseDropinService.deleteLead(id);
    setLeads((prev) => prev.filter((l) => l.id !== id));
    success('Lead Deleted', 'Removed from database.');
  };

  // Submit test lead from simulated website contact form
  const handleSimulateSubmitLead = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!simName.trim() || !simEmail.trim()) return;
    setSimSubmitting(true);

    try {
      const newLead = await supabaseDropinService.insertLead({
        name: simName,
        email: simEmail,
        message: simMessage,
      });

      setLeads((prev) => [newLead, ...prev]);
      setSimSubmitting(false);
      setSimSuccess(true);
      success('Lead Dispatched', `Simulated form submission recorded for ${simName}.`);
      setTimeout(() => setSimSuccess(false), 4000);
    } catch (err) {
      setSimSubmitting(false);
      toastError('Error', 'Failed to submit simulated lead.');
    }
  };

  // Export leads to CSV
  const handleExportLeadsCsv = () => {
    if (leads.length === 0) {
      toastError('No Leads', 'There are no leads to export.');
      return;
    }
    const headers = ['ID', 'Name', 'Email', 'Message', 'CreatedAt'];
    const rows = leads.map((l) => [
      `"${l.id}"`,
      `"${l.name.replace(/"/g, '""')}"`,
      `"${l.email.replace(/"/g, '""')}"`,
      `"${l.message.replace(/"/g, '""')}"`,
      `"${l.created_at}"`,
    ]);
    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `leads-export-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    success('Export Complete', `Exported ${leads.length} leads to CSV.`);
  };

  // Copy helper
  const copyToClipboard = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    success('Copied to Clipboard');
    setTimeout(() => setCopiedKey(null), 2500);
  };

  // Save live Supabase credentials
  const handleSaveSupabaseConfig = (e: React.FormEvent) => {
    e.preventDefault();
    supabaseDropinService.saveConfig(supabaseConfig);
    success('Configuration Saved', 'Supabase credentials updated.');
    loadData();
  };

  // Test live Supabase connection
  const handleTestConnection = async () => {
    setIsTestingConnection(true);
    try {
      if (!supabaseConfig.supabaseUrl || !supabaseConfig.supabaseAnonKey) {
        toastError('Missing Info', 'Please provide both Supabase URL and Anon Key.');
        setIsTestingConnection(false);
        return;
      }
      const testContent = await supabaseDropinService.fetchSiteContent();
      if (testContent) {
        success('Connection Successful', 'Connected to Supabase site_content table!');
      }
    } catch (err: any) {
      toastError('Connection Error', err.message || 'Could not query Supabase.');
    } finally {
      setIsTestingConnection(false);
    }
  };

  // Filtered leads
  const filteredLeads = leads.filter((l) => {
    if (!leadSearch.trim()) return true;
    const q = leadSearch.toLowerCase();
    return (
      l.name.toLowerCase().includes(q) ||
      l.email.toLowerCase().includes(q) ||
      l.message.toLowerCase().includes(q)
    );
  });

  const isDark = themeMode === 'dark';

  return (
    <div className={`w-full min-h-screen ${isDark ? 'bg-gray-950 text-gray-100' : 'bg-gray-50 text-gray-900'} transition-colors font-sans pb-20`}>
      {/* Top Banner & Control Bar */}
      <div className={`border-b ${isDark ? 'border-gray-800 bg-gray-900/80' : 'border-gray-200 bg-white'} sticky top-0 z-30 px-6 py-3.5 backdrop-blur-md`}>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-black text-white flex items-center justify-center font-bold text-sm shadow-xs">
              ⚡
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-base tracking-tight text-white dark:text-white">
                  Drop-In Client Admin Dashboard
                </span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-semibold">
                  app/admin/page.tsx
                </span>
              </div>
              <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'} mt-0.5`}>
                Single-user, zero-config admin page. Copy &amp; drop into any individual client Next.js repository.
              </p>
            </div>
          </div>

          {/* Right Action Switchers */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* View Mode Buttons */}
            <div className={`p-1 rounded-lg border flex items-center gap-1 ${isDark ? 'border-gray-800 bg-gray-900' : 'border-gray-200 bg-gray-100'}`}>
              <button
                type="button"
                onClick={() => setViewMode('dashboard')}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 ${
                  viewMode === 'dashboard'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : isDark
                    ? 'text-gray-400 hover:text-white'
                    : 'text-gray-600 hover:text-black'
                }`}
              >
                <Settings className="w-3.5 h-3.5" />
                Admin View
              </button>

              <button
                type="button"
                onClick={() => setViewMode('split')}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 ${
                  viewMode === 'split'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : isDark
                    ? 'text-gray-400 hover:text-white'
                    : 'text-gray-600 hover:text-black'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                Split Live Preview
              </button>

              <button
                type="button"
                onClick={() => setViewMode('website_preview')}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 ${
                  viewMode === 'website_preview'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : isDark
                    ? 'text-gray-400 hover:text-white'
                    : 'text-gray-600 hover:text-black'
                }`}
              >
                <Globe className="w-3.5 h-3.5" />
                Client Website
              </button>

              <button
                type="button"
                onClick={() => setViewMode('developer_hub')}
                className={`px-3 py-1 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 ${
                  viewMode === 'developer_hub'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : isDark
                    ? 'text-gray-400 hover:text-white'
                    : 'text-gray-600 hover:text-black'
                }`}
              >
                <Code className="w-3.5 h-3.5" />
                Copy Drop-in Code
              </button>

              <button
                type="button"
                onClick={downloadGuideTxt}
                className={`px-3 py-1 text-xs font-semibold rounded-md border transition-all flex items-center gap-1.5 ${
                  isDark
                    ? 'border-blue-500/40 bg-blue-500/10 text-blue-300 hover:bg-blue-500/20'
                    : 'border-blue-300 bg-blue-50 text-blue-700 hover:bg-blue-100'
                }`}
                title="Download complete CLIENT_CMS_GUIDE.txt for AI agents"
              >
                <Download className="w-3.5 h-3.5 text-blue-400" />
                Guide (.txt)
              </button>
            </div>

            {/* Dark / Light toggle for admin style preview */}
            <button
              type="button"
              onClick={() => setThemeMode(isDark ? 'light' : 'dark')}
              className={`p-1.5 text-xs rounded-lg border transition-colors ${
                isDark
                  ? 'border-gray-800 text-gray-300 hover:bg-gray-800'
                  : 'border-gray-200 text-gray-700 hover:bg-gray-100'
              }`}
              title="Toggle Admin Theme"
            >
              {isDark ? '☀️ Light' : '🌙 Dark'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* DEVELOPER CODE HUB VIEW */}
        {viewMode === 'developer_hub' && (
          <div className="space-y-6">
            <div className={`p-6 rounded-2xl border ${isDark ? 'border-gray-800 bg-gray-900' : 'border-gray-200 bg-white'} shadow-sm`}>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-gray-800">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <Terminal className="w-5 h-5 text-blue-400" />
                    Drop-in Code &amp; Client Setup Hub
                  </h2>
                  <p className="text-xs text-gray-400 mt-1">
                    Everything you need to copy, paste, and deploy this exact dashboard to your next client's repository in under 2 minutes.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => copyToClipboard('all_code', supabaseDropinService.getAdminDashboardCode())}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold flex items-center gap-2 transition cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  Copy Next.js Admin Page (app/admin/page.tsx)
                </button>
              </div>

              {/* Code Tab Switcher */}
              <div className="flex items-center gap-2 overflow-x-auto pt-4 pb-2 border-b border-gray-800 text-xs">
                <button
                  type="button"
                  onClick={() => setActiveCodeTab('ai_prompt')}
                  className={`px-3.5 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                    activeCodeTab === 'ai_prompt'
                      ? 'bg-blue-600 text-white font-bold shadow-xs'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5 text-yellow-300" /> 0. Master AI Prompt &amp; Guide (.txt)
                </button>

                <button
                  type="button"
                  onClick={() => setActiveCodeTab('admin_page')}
                  className={`px-3.5 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                    activeCodeTab === 'admin_page'
                      ? 'bg-white text-gray-900 font-bold'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Code className="w-3.5 h-3.5" /> 1. app/admin/page.tsx
                </button>

                <button
                  type="button"
                  onClick={() => setActiveCodeTab('sql')}
                  className={`px-3.5 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                    activeCodeTab === 'sql'
                      ? 'bg-white text-gray-900 font-bold'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Database className="w-3.5 h-3.5" /> 2. Supabase SQL Migration
                </button>

                <button
                  type="button"
                  onClick={() => setActiveCodeTab('client_page')}
                  className={`px-3.5 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                    activeCodeTab === 'client_page'
                      ? 'bg-white text-gray-900 font-bold'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Globe className="w-3.5 h-3.5" /> 3. Website Frontend (app/page.tsx)
                </button>

                <button
                  type="button"
                  onClick={() => setActiveCodeTab('contact_form')}
                  className={`px-3.5 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                    activeCodeTab === 'contact_form'
                      ? 'bg-white text-gray-900 font-bold'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Mail className="w-3.5 h-3.5" /> 4. ContactForm.tsx
                </button>

                <button
                  type="button"
                  onClick={() => setActiveCodeTab('env')}
                  className={`px-3.5 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                    activeCodeTab === 'env'
                      ? 'bg-white text-gray-900 font-bold'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Key className="w-3.5 h-3.5" /> 5. .env.local
                </button>

                <button
                  type="button"
                  onClick={() => setActiveCodeTab('security')}
                  className={`px-3.5 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                    activeCodeTab === 'security'
                      ? 'bg-white text-gray-900 font-bold'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" /> 6. Zero-Config Security
                </button>

                <button
                  type="button"
                  onClick={() => setActiveCodeTab('supabase_creds')}
                  className={`px-3.5 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                    activeCodeTab === 'supabase_creds'
                      ? 'bg-white text-gray-900 font-bold'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Key className="w-3.5 h-3.5" /> 7. Connect Live Supabase
                </button>
              </div>

              {/* Tab Contents */}
              <div className="pt-4">
                {activeCodeTab === 'ai_prompt' && (
                  <div className="space-y-4">
                    <div className="p-4 rounded-xl bg-blue-950/40 border border-blue-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div>
                        <h3 className="text-sm font-bold text-white flex items-center gap-2">
                          <FileText className="w-4 h-4 text-blue-400" />
                          Complete AI Prompt &amp; CMS Implementation Guide
                        </h3>
                        <p className="text-xs text-blue-200/80 mt-0.5">
                          Upload your client repo to any AI (Claude, Cursor, ChatGPT, Gemini), paste this prompt, and it will implement the branding and admin dashboard automatically.
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={downloadGuideTxt}
                          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-xs whitespace-nowrap"
                        >
                          <Download className="w-3.5 h-3.5" />
                          Download Guide (.txt)
                        </button>
                        <button
                          type="button"
                          onClick={() => copyToClipboard('ai_prompt_copy', supabaseDropinService.getAiPromptGuide())}
                          className="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-200 border border-gray-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap"
                        >
                          {copiedKey === 'ai_prompt_copy' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                          {copiedKey === 'ai_prompt_copy' ? 'Copied' : 'Copy AI Prompt'}
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span>Saved in repository root as: <code className="text-blue-400 font-mono">/CLIENT_CMS_GUIDE.txt</code></span>
                      <span className="text-gray-500 font-mono text-[11px]">Ready for Cursor / Claude 3.7 / ChatGPT / Gemini</span>
                    </div>

                    <pre className="p-4 bg-gray-950 text-gray-200 font-mono text-xs rounded-xl overflow-x-auto border border-gray-800 leading-relaxed max-h-128 whitespace-pre-wrap">
                      {supabaseDropinService.getAiPromptGuide()}
                    </pre>
                  </div>
                )}

                {activeCodeTab === 'admin_page' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span>Create file: <code className="text-blue-400 font-mono">app/admin/page.tsx</code> in your client's Next.js project</span>
                      <button
                        type="button"
                        onClick={() => copyToClipboard('admin_code', supabaseDropinService.getAdminDashboardCode())}
                        className="text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium transition cursor-pointer"
                      >
                        {copiedKey === 'admin_code' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                        {copiedKey === 'admin_code' ? 'Copied' : 'Copy Code'}
                      </button>
                    </div>
                    <pre className="p-4 bg-gray-950 text-gray-200 font-mono text-xs rounded-xl overflow-x-auto border border-gray-800 leading-relaxed max-h-128">
                      {supabaseDropinService.getAdminDashboardCode()}
                    </pre>
                  </div>
                )}

                {activeCodeTab === 'sql' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span>Paste into your client's Supabase SQL Editor: creates <code className="text-green-400 font-mono">site_content</code> and <code className="text-green-400 font-mono">site_leads</code></span>
                      <button
                        type="button"
                        onClick={() => copyToClipboard('sql_code', supabaseDropinService.getSupabaseSqlCode())}
                        className="text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium transition cursor-pointer"
                      >
                        {copiedKey === 'sql_code' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                        {copiedKey === 'sql_code' ? 'Copied' : 'Copy SQL'}
                      </button>
                    </div>
                    <pre className="p-4 bg-gray-950 text-gray-200 font-mono text-xs rounded-xl overflow-x-auto border border-gray-800 leading-relaxed max-h-128">
                      {supabaseDropinService.getSupabaseSqlCode()}
                    </pre>
                  </div>
                )}

                {activeCodeTab === 'client_page' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span>Example public website entry point: <code className="text-purple-400 font-mono">app/page.tsx</code></span>
                      <button
                        type="button"
                        onClick={() => copyToClipboard('client_page_code', supabaseDropinService.getClientFrontendCode())}
                        className="text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium transition cursor-pointer"
                      >
                        {copiedKey === 'client_page_code' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                        {copiedKey === 'client_page_code' ? 'Copied' : 'Copy Code'}
                      </button>
                    </div>
                    <pre className="p-4 bg-gray-950 text-gray-200 font-mono text-xs rounded-xl overflow-x-auto border border-gray-800 leading-relaxed max-h-128">
                      {supabaseDropinService.getClientFrontendCode()}
                    </pre>
                  </div>
                )}

                {activeCodeTab === 'contact_form' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span>Client website contact form component: <code className="text-yellow-400 font-mono">app/ContactForm.tsx</code></span>
                      <button
                        type="button"
                        onClick={() => copyToClipboard('contact_form_code', supabaseDropinService.getContactFormComponentCode())}
                        className="text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium transition cursor-pointer"
                      >
                        {copiedKey === 'contact_form_code' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                        {copiedKey === 'contact_form_code' ? 'Copied' : 'Copy Code'}
                      </button>
                    </div>
                    <pre className="p-4 bg-gray-950 text-gray-200 font-mono text-xs rounded-xl overflow-x-auto border border-gray-800 leading-relaxed max-h-128">
                      {supabaseDropinService.getContactFormComponentCode()}
                    </pre>
                  </div>
                )}

                {activeCodeTab === 'env' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span>Add to <code className="text-blue-400 font-mono">.env.local</code> in the client repo</span>
                      <button
                        type="button"
                        onClick={() => copyToClipboard('env_code', supabaseDropinService.getEnvSnippet())}
                        className="text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium transition cursor-pointer"
                      >
                        {copiedKey === 'env_code' ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                        {copiedKey === 'env_code' ? 'Copied' : 'Copy .env'}
                      </button>
                    </div>
                    <pre className="p-4 bg-gray-950 text-gray-200 font-mono text-xs rounded-xl overflow-x-auto border border-gray-800 leading-relaxed">
                      {supabaseDropinService.getEnvSnippet()}
                    </pre>
                  </div>
                )}

                {activeCodeTab === 'security' && (
                  <div className="space-y-4 text-xs leading-relaxed text-gray-300">
                    <div className="p-4 bg-blue-950/40 border border-blue-800/60 rounded-xl space-y-2">
                      <h4 className="font-bold text-sm text-blue-300 flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4 text-blue-400" />
                        Zero-Config Security (No Auth Code to Maintain)
                      </h4>
                      <p>
                        Instead of setting up full Clerk middleware, complex role mappings, or custom auth routing, simply use hosting-layer password protection:
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 bg-gray-950 border border-gray-800 rounded-xl space-y-2">
                        <span className="font-bold text-white block text-sm">Option A: Vercel Password Protection</span>
                        <ol className="list-decimal list-inside space-y-1 text-gray-400 text-xs">
                          <li>Open your client project on <strong>Vercel Dashboard</strong>.</li>
                          <li>Go to <strong>Settings</strong> &gt; <strong>Deployment Protection</strong>.</li>
                          <li>Enable <strong>Password Protection</strong> for the <code className="text-gray-200">/admin</code> path or staging domain.</li>
                          <li>Share the single password with your client. Done!</li>
                        </ol>
                      </div>

                      <div className="p-4 bg-gray-950 border border-gray-800 rounded-xl space-y-2">
                        <span className="font-bold text-white block text-sm">Option B: Netlify Visitor Access</span>
                        <ol className="list-decimal list-inside space-y-1 text-gray-400 text-xs">
                          <li>Open your site on <strong>Netlify Dashboard</strong>.</li>
                          <li>Go to <strong>Site configuration</strong> &gt; <strong>Access control</strong>.</li>
                          <li>Turn on <strong>Basic Password Protection</strong>.</li>
                          <li>Zero user database to manage, zero token expiration bugs.</li>
                        </ol>
                      </div>
                    </div>

                    <div className="p-4 bg-gray-950 border border-gray-800 rounded-xl">
                      <span className="font-bold text-white block mb-1">🛠️ Workflow for Every Next Client:</span>
                      <p className="text-gray-400">
                        1. Spin up a new Supabase project for the client.<br />
                        2. Run the SQL script from Tab 2 in their SQL Editor.<br />
                        3. Drop <code className="text-gray-200">app/admin/page.tsx</code> into their repo.<br />
                        4. Add their Supabase keys to <code className="text-gray-200">.env.local</code>.<br />
                        5. Hand your client their password. They can manage their website forever.
                      </p>
                    </div>
                  </div>
                )}

                {activeCodeTab === 'supabase_creds' && (
                  <form onSubmit={handleSaveSupabaseConfig} className="space-y-4 max-w-xl">
                    <div className="p-4 bg-gray-950 border border-gray-800 rounded-xl space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-white">Live Supabase Project Connection</span>
                        <label className="flex items-center gap-2 text-xs text-gray-400 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={supabaseConfig.useLiveSupabase}
                            onChange={(e) =>
                              setSupabaseConfig({
                                ...supabaseConfig,
                                useLiveSupabase: e.target.checked,
                              })
                            }
                            className="rounded border-gray-700 bg-gray-900 text-blue-600 focus:ring-blue-500"
                          />
                          <span>Enable Live Supabase Sync</span>
                        </label>
                      </div>
                      <p className="text-xs text-gray-400">
                        By default, this preview operates with a simulated, reactive in-browser database so it works out-of-the-box. Check the box above to query a real Supabase instance.
                      </p>

                      <div>
                        <label className="block text-xs text-gray-400 font-mono mb-1">NEXT_PUBLIC_SUPABASE_URL</label>
                        <input
                          type="text"
                          value={supabaseConfig.supabaseUrl}
                          onChange={(e) =>
                            setSupabaseConfig({ ...supabaseConfig, supabaseUrl: e.target.value })
                          }
                          placeholder="https://your-project.supabase.co"
                          className="w-full px-3 py-2 bg-gray-900 border border-gray-800 rounded-lg text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                        />
                      </div>

                      <div>
                        <label className="block text-xs text-gray-400 font-mono mb-1">NEXT_PUBLIC_SUPABASE_ANON_KEY</label>
                        <input
                          type="password"
                          value={supabaseConfig.supabaseAnonKey}
                          onChange={(e) =>
                            setSupabaseConfig({ ...supabaseConfig, supabaseAnonKey: e.target.value })
                          }
                          placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                          className="w-full px-3 py-2 bg-gray-900 border border-gray-800 rounded-lg text-xs font-mono text-white focus:outline-none focus:border-blue-500"
                        />
                      </div>

                      <div className="flex items-center gap-2 pt-2">
                        <button
                          type="submit"
                          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold transition cursor-pointer"
                        >
                          Save Credentials
                        </button>
                        <button
                          type="button"
                          onClick={handleTestConnection}
                          disabled={isTestingConnection}
                          className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-200 rounded-lg text-xs font-medium transition cursor-pointer flex items-center gap-1.5"
                        >
                          {isTestingConnection ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                          Test Connection
                        </button>
                      </div>
                    </div>
                  </form>
                )}
              </div>
            </div>
          </div>
        )}

        {/* DASHBOARD OR SPLIT VIEW */}
        {(viewMode === 'dashboard' || viewMode === 'split') && (
          <div className={viewMode === 'split' ? 'grid grid-cols-1 lg:grid-cols-2 gap-8 items-start' : 'max-w-4xl mx-auto space-y-8'}>
            
            {/* LEFT COLUMN: THE ADMIN DASHBOARD */}
            <div className="space-y-8">
              <header className={`border-b ${isDark ? 'border-gray-800' : 'border-gray-200'} pb-4 flex items-center justify-between`}>
                <div className="flex items-center gap-3">
                  {brandLogo ? (
                    <img src={brandLogo} alt="Logo" className="w-10 h-10 rounded-lg object-cover border border-gray-700 shrink-0" />
                  ) : (
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center font-bold text-white text-xs shadow-xs shrink-0" style={{ backgroundColor: brandColor }}>
                      {brandName ? brandName.slice(0, 2).toUpperCase() : 'CO'}
                    </div>
                  )}
                  <div>
                    <h1 className={`text-xl font-bold tracking-tight ${isDark ? 'text-white' : 'text-gray-900'}`}>
                      {brandName || 'Client'} Admin Dashboard
                    </h1>
                    <p className={`text-xs mt-0.5 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                      Customize business branding, website copy, hero media, and incoming leads.
                    </p>
                  </div>
                </div>
                {savedAlert && (
                  <div className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold rounded-lg animate-pulse flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Saved &amp; Synced {lastSavedTime && `(${lastSavedTime})`}
                  </div>
                )}
              </header>

              {/* --- SECTION 0: CLIENT BRANDING & IDENTITY --- */}
              <section className={`${isDark ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200'} p-6 rounded-xl border shadow-xs space-y-4`}>
                <div className="flex items-center justify-between border-b border-gray-800 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-md flex items-center justify-center text-white text-xs font-bold" style={{ backgroundColor: brandColor }}>
                      🎨
                    </div>
                    <h2 className={`text-base font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
                      Client Branding &amp; Styling
                    </h2>
                  </div>
                  <span className="text-[11px] font-mono text-gray-400">Plug &amp; Play Setup</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className={`block text-xs font-medium uppercase tracking-wider ${isDark ? 'text-gray-400' : 'text-gray-600'} mb-1`}>
                      Business Name <span className="font-mono text-[10px] text-gray-500">(id: brand_name)</span>
                    </label>
                    <input
                      type="text"
                      value={brandName}
                      onChange={(e) => setBrandName(e.target.value)}
                      placeholder="e.g. Apex Studio, Lumina Dental"
                      className={`w-full ${
                        isDark ? 'bg-gray-950 border-gray-800 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                      } border rounded-lg p-2.5 text-sm font-semibold focus:outline-none focus:border-blue-500`}
                    />
                  </div>

                  <div>
                    <label className={`block text-xs font-medium uppercase tracking-wider ${isDark ? 'text-gray-400' : 'text-gray-600'} mb-1`}>
                      Logo Image URL <span className="font-mono text-[10px] text-gray-500">(id: brand_logo)</span>
                    </label>
                    <input
                      type="url"
                      value={brandLogo}
                      onChange={(e) => setBrandLogo(e.target.value)}
                      placeholder="https://.../logo.png"
                      className={`w-full ${
                        isDark ? 'bg-gray-950 border-gray-800 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                      } border rounded-lg p-2.5 text-xs font-mono focus:outline-none focus:border-blue-500`}
                    />
                  </div>
                </div>

                {/* Quick Logo presets */}
                <div>
                  <span className="text-[11px] text-gray-400 block mb-1.5 font-medium">Quick Sample Logos for Clients:</span>
                  <div className="flex flex-wrap gap-2">
                    {SAMPLE_LOGOS.map((item) => (
                      <button
                        key={item.name}
                        type="button"
                        onClick={() => setBrandLogo(item.url)}
                        className={`text-xs px-2.5 py-1 rounded-md border flex items-center gap-1.5 transition cursor-pointer ${
                          brandLogo === item.url
                            ? 'border-blue-500 bg-blue-500/10 text-blue-400'
                            : isDark ? 'border-gray-800 bg-gray-950 text-gray-400 hover:text-gray-200' : 'border-gray-200 bg-gray-50 text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        <img src={item.url} alt="" className="w-3.5 h-3.5 rounded-full object-cover" />
                        {item.name}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Color palette picker */}
                <div className="pt-2 border-t border-gray-800/60">
                  <label className={`block text-xs font-medium uppercase tracking-wider ${isDark ? 'text-gray-400' : 'text-gray-600'} mb-2`}>
                    Theme Accent Color: <span className="font-mono text-white font-bold ml-1">{brandColor}</span>
                  </label>
                  <div className="flex items-center gap-2.5 flex-wrap">
                    {BRAND_COLOR_PRESETS.map((p) => (
                      <button
                        key={p.hex}
                        type="button"
                        onClick={() => setBrandColor(p.hex)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition flex items-center gap-2 cursor-pointer ${
                          brandColor.toLowerCase() === p.hex.toLowerCase()
                            ? 'border-white text-white shadow-xs'
                            : isDark ? 'border-gray-800 text-gray-400 hover:border-gray-700' : 'border-gray-200 text-gray-700 hover:border-gray-400'
                        }`}
                      >
                        <span className="w-3.5 h-3.5 rounded-full shrink-0" style={{ backgroundColor: p.hex }}></span>
                        {p.name}
                      </button>
                    ))}

                    <div className={`flex items-center gap-2 ${isDark ? 'bg-gray-950 border-gray-800' : 'bg-gray-50 border-gray-200'} px-2.5 py-1 rounded-lg border`}>
                      <input
                        type="color"
                        value={brandColor}
                        onChange={(e) => setBrandColor(e.target.value)}
                        className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                      />
                      <span className="text-xs text-gray-400 font-mono">Custom Hex</span>
                    </div>
                  </div>
                </div>
              </section>

              {/* --- SECTION 1: EDIT TEXT CONTENT --- */}
              <section className={`${isDark ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200'} p-6 rounded-xl border shadow-xs space-y-5`}>
                <div className="flex items-center justify-between border-b border-gray-800 pb-3">
                  <h2 className="text-base font-bold text-blue-400 flex items-center gap-2">
                    <span>1.</span> Edit Website Text &amp; Media
                  </h2>
                  <span className="text-[11px] font-mono text-gray-400">table: public.site_content</span>
                </div>

                <form onSubmit={handleSave} className="space-y-4">
                  <div>
                    <label className={`block text-xs font-medium uppercase tracking-wider ${isDark ? 'text-gray-400' : 'text-gray-600'} mb-1`}>
                      Hero Title <span className="font-mono text-[10px] text-gray-500">(id: hero_title)</span>
                    </label>
                    <input
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Welcome to Our Website"
                      className={`w-full ${
                        isDark ? 'bg-gray-950 border-gray-800 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                      } border rounded-lg p-2.5 text-sm font-medium focus:outline-none focus:border-blue-500`}
                    />
                  </div>

                  <div>
                    <label className={`block text-xs font-medium uppercase tracking-wider ${isDark ? 'text-gray-400' : 'text-gray-600'} mb-1`}>
                      Hero Description <span className="font-mono text-[10px] text-gray-500">(id: hero_desc)</span>
                    </label>
                    <textarea
                      rows={3}
                      value={desc}
                      onChange={(e) => setDesc(e.target.value)}
                      placeholder="This is a simple subtitle editable from your dashboard."
                      className={`w-full ${
                        isDark ? 'bg-gray-950 border-gray-800 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                      } border rounded-lg p-2.5 text-sm focus:outline-none focus:border-blue-500 leading-relaxed`}
                    />
                  </div>

                  <div>
                    <label className={`block text-xs font-medium uppercase tracking-wider ${isDark ? 'text-gray-400' : 'text-gray-600'} mb-1`}>
                      Hero Image URL <span className="font-mono text-[10px] text-gray-500">(id: hero_image)</span>
                    </label>
                    <input
                      type="url"
                      value={image}
                      onChange={(e) => setImage(e.target.value)}
                      placeholder="https://images.unsplash.com/..."
                      className={`w-full ${
                        isDark ? 'bg-gray-950 border-gray-800 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                      } border rounded-lg p-2.5 text-xs font-mono focus:outline-none focus:border-blue-500`}
                    />
                    {image && (
                      <div className="mt-2.5 flex items-center gap-3">
                        <div className="w-24 h-16 rounded-lg overflow-hidden border border-gray-700 shrink-0 bg-gray-950">
                          <img src={image} alt="Hero Preview" className="w-full h-full object-cover" />
                        </div>
                        <span className="text-[11px] text-gray-400">Live image connected to client hero banner.</span>
                      </div>
                    )}
                  </div>

                  {/* Custom Extra Fields */}
                  {customFields.map((field, idx) => (
                    <div key={field.id} className="pt-2 border-t border-gray-800/80">
                      <div className="flex items-center justify-between mb-1">
                        <label className={`block text-xs font-medium uppercase tracking-wider ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                          {field.id.replace(/_/g, ' ')} <span className="font-mono text-[10px] text-gray-500">({field.id})</span>
                        </label>
                        <button
                          type="button"
                          onClick={() => handleDeleteCustomKey(field.id)}
                          className="text-gray-500 hover:text-red-400 text-xs transition"
                          title="Delete Field"
                        >
                          ✕ Remove
                        </button>
                      </div>
                      <input
                        type="text"
                        value={field.value}
                        onChange={(e) => {
                          const updated = [...customFields];
                          updated[idx].value = e.target.value;
                          setCustomFields(updated);
                        }}
                        className={`w-full ${
                          isDark ? 'bg-gray-950 border-gray-800 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                        } border rounded-lg p-2.5 text-xs focus:outline-none focus:border-blue-500`}
                      />
                    </div>
                  ))}

                  {/* Add Custom Field Toggle */}
                  {showAddCustom ? (
                    <div className="p-3.5 rounded-lg border border-gray-800 bg-gray-950 space-y-2 text-xs">
                      <span className="font-semibold text-white block">Add New Dynamic Content Key</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <input
                          type="text"
                          value={newKeyName}
                          onChange={(e) => setNewKeyName(e.target.value)}
                          placeholder="e.g. about_text, announcement, phone"
                          className="px-2.5 py-1.5 bg-gray-900 border border-gray-700 rounded text-xs text-white"
                        />
                        <input
                          type="text"
                          value={newKeyValue}
                          onChange={(e) => setNewKeyValue(e.target.value)}
                          placeholder="Initial value..."
                          className="px-2.5 py-1.5 bg-gray-900 border border-gray-700 rounded text-xs text-white"
                        />
                      </div>
                      <div className="flex gap-2 pt-1">
                        <button
                          type="button"
                          onClick={handleAddCustomKey}
                          className="px-3 py-1 bg-blue-600 hover:bg-blue-500 text-white rounded font-medium text-xs cursor-pointer"
                        >
                          Add Field
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowAddCustom(false)}
                          className="px-3 py-1 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded text-xs cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setShowAddCustom(true)}
                      className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium transition cursor-pointer pt-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add Extra Website Field (e.g. About text, Phone, CTA)
                    </button>
                  )}

                  <div className="pt-3 flex items-center justify-between">
                    <button
                      type="submit"
                      disabled={loading}
                      style={{ backgroundColor: brandColor }}
                      className="text-white font-semibold text-sm py-2.5 px-6 rounded-lg transition-opacity hover:opacity-90 disabled:opacity-50 flex items-center gap-2 cursor-pointer shadow-sm"
                    >
                      {loading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        'Save All Changes'
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => setViewMode('split')}
                      className="text-xs text-gray-400 hover:text-white flex items-center gap-1 transition"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      Check Public Preview
                    </button>
                  </div>
                </form>
              </section>

              {/* --- SECTION 2: VIEW CLIENT LEADS --- */}
              <section className={`${isDark ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200'} p-6 rounded-xl border shadow-xs space-y-4`}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-800 pb-3">
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-green-400 flex items-center gap-2">
                      <span>2.</span> Received Leads ({leads.length})
                    </h2>
                    <span className="text-[11px] font-mono text-gray-400">table: public.site_leads</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleExportLeadsCsv}
                      className="px-2.5 py-1 rounded bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs flex items-center gap-1 font-medium transition cursor-pointer"
                      title="Download Leads CSV"
                    >
                      <Download className="w-3 h-3" />
                      CSV Export
                    </button>
                  </div>
                </div>

                {/* Search Bar */}
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-gray-500 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={leadSearch}
                    onChange={(e) => setLeadSearch(e.target.value)}
                    placeholder="Search leads by name, email, or message..."
                    className={`w-full pl-9 pr-3 py-2 text-xs rounded-lg border ${
                      isDark ? 'bg-gray-950 border-gray-800 text-white' : 'bg-gray-50 border-gray-200 text-gray-900'
                    } focus:outline-none focus:border-green-500`}
                  />
                </div>

                {/* Leads List */}
                {filteredLeads.length === 0 ? (
                  <div className="p-8 text-center text-gray-500 text-sm border border-dashed border-gray-800 rounded-lg space-y-2">
                    <p>No form submissions found.</p>
                    <button
                      type="button"
                      onClick={() => {
                        supabaseDropinService.insertLead({
                          name: 'Demo Visitor',
                          email: 'demo.visitor@example.com',
                          message: 'Testing the drop-in contact submission flow!',
                        });
                        success('Sample Lead Inserted');
                      }}
                      className="text-xs text-blue-400 hover:underline cursor-pointer"
                    >
                      + Insert a test lead to see how it looks
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                    {filteredLeads.map((lead) => (
                      <div
                        key={lead.id}
                        className={`${isDark ? 'bg-gray-950 border-gray-800' : 'bg-gray-50 border-gray-200'} p-4 rounded-lg border text-sm space-y-2 relative group`}
                      >
                        <div className="flex justify-between items-start text-xs">
                          <div>
                            <span className={`font-bold ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                              {lead.name}
                            </span>
                            <span className="text-gray-400 ml-1.5 font-mono">({lead.email})</span>
                          </div>
                          <div className="flex items-center gap-3 text-gray-400">
                            <span>{new Date(lead.created_at).toLocaleDateString()}</span>
                            <button
                              type="button"
                              onClick={() => handleDeleteLead(lead.id)}
                              className="text-gray-500 hover:text-red-400 transition cursor-pointer p-1"
                              title="Delete Lead"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <p className={`text-xs leading-relaxed ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                          {lead.message}
                        </p>

                        <div className="flex items-center justify-between pt-1 text-[11px] text-gray-500">
                          <span className="font-mono text-[10px]">ID: {lead.id.slice(0, 8)}...</span>
                          <a
                            href={`mailto:${lead.email}?subject=Regarding your inquiry`}
                            className="text-blue-400 hover:underline flex items-center gap-1"
                          >
                            <Mail className="w-3 h-3" /> Reply by Email
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>
            </div>

            {/* RIGHT COLUMN (SPLIT VIEW): LIVE SIMULATED CLIENT WEBSITE */}
            {viewMode === 'split' && (
              <div className="space-y-4 sticky top-24">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">
                    <Globe className="w-3.5 h-3.5 text-blue-400" />
                    <span>Live Public Website Simulation</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full bg-green-500/10 text-green-400 text-[10px] font-mono font-medium">
                    Auto-Refreshing
                  </span>
                </div>

                <div className="rounded-2xl border border-gray-700 bg-white text-gray-900 overflow-hidden shadow-2xl flex flex-col">
                  {/* Browser Bar */}
                  <div className="bg-gray-100 px-4 py-2 border-b border-gray-200 flex items-center justify-between text-xs text-gray-500">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-400"></span>
                      <span className="w-2.5 h-2.5 rounded-full bg-yellow-400"></span>
                      <span className="w-2.5 h-2.5 rounded-full bg-green-400"></span>
                    </div>
                    <div className="font-mono text-[11px] bg-white px-3 py-0.5 rounded border border-gray-200 text-gray-600 flex items-center gap-1">
                      <span>https://clientwebsite.com/</span>
                    </div>
                    <div className="text-[10px] text-gray-400">Preview</div>
                  </div>

                  {/* Public Site Viewport */}
                  <div className="p-6 max-h-[70vh] overflow-y-auto space-y-8 bg-white">
                    {/* Site Navigation */}
                    <div className="flex items-center justify-between border-b border-gray-100 pb-3">
                      <div className="flex items-center gap-2">
                        {brandLogo ? (
                          <img src={brandLogo} alt="" className="h-6 w-auto max-w-[100px] object-contain rounded" />
                        ) : (
                          <div className="w-6 h-6 rounded flex items-center justify-center font-bold text-white text-[10px]" style={{ backgroundColor: brandColor }}>
                            {brandName ? brandName.slice(0, 2).toUpperCase() : 'CO'}
                          </div>
                        )}
                        <span className="font-extrabold text-sm tracking-tight text-gray-900">{brandName}</span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-gray-600">
                        <span>Home</span>
                        <span>About</span>
                        <a
                          href="#sim-contact"
                          style={{ backgroundColor: brandColor }}
                          className="px-2.5 py-1 rounded text-white font-medium text-[11px] shadow-xs hover:opacity-90 transition"
                        >
                          Contact
                        </a>
                      </div>
                    </div>

                    {/* Site Hero Banner */}
                    <div className="space-y-4">
                      {image && (
                        <div className="w-full h-40 rounded-xl overflow-hidden border border-gray-200 shadow-sm">
                          <img src={image} alt="Hero" className="w-full h-full object-cover" />
                        </div>
                      )}
                      <div
                        className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-semibold"
                        style={{ backgroundColor: brandColor + '18', color: brandColor }}
                      >
                        <span>●</span> Live Client Template
                      </div>
                      <h1 className="text-2xl font-black text-gray-950 tracking-tight leading-snug">
                        {title || 'Welcome to Our Website'}
                      </h1>
                      <p className="text-xs text-gray-600 leading-relaxed">
                        {desc || 'This is a simple subtitle editable from your dashboard.'}
                      </p>
                    </div>

                    {/* Interactive Contact Form */}
                    <div id="sim-contact" className="bg-gray-50 p-5 rounded-xl border border-gray-200 space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold text-xs uppercase tracking-wider text-gray-900">
                          Send Us a Message (Contact Form)
                        </h3>
                        <span className="text-[10px] text-gray-400">Writes to site_leads</span>
                      </div>

                      {simSuccess && (
                        <div className="p-2.5 bg-green-100 border border-green-300 text-green-800 text-xs rounded-lg font-medium">
                          ✓ Lead received! Check the Received Leads section on the left.
                        </div>
                      )}

                      <form onSubmit={handleSimulateSubmitLead} className="space-y-2.5 text-xs">
                        <div>
                          <label className="block text-[11px] font-medium text-gray-700 mb-0.5">Name</label>
                          <input
                            type="text"
                            required
                            value={simName}
                            onChange={(e) => setSimName(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-gray-300 rounded text-xs text-gray-900 focus:outline-none focus:border-black"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-medium text-gray-700 mb-0.5">Email</label>
                          <input
                            type="email"
                            required
                            value={simEmail}
                            onChange={(e) => setSimEmail(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-gray-300 rounded text-xs text-gray-900 focus:outline-none focus:border-black"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-medium text-gray-700 mb-0.5">Message</label>
                          <textarea
                            rows={2}
                            required
                            value={simMessage}
                            onChange={(e) => setSimMessage(e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-white border border-gray-300 rounded text-xs text-gray-900 focus:outline-none focus:border-black"
                          />
                        </div>
                        <button
                          type="submit"
                          disabled={simSubmitting}
                          style={{ backgroundColor: brandColor }}
                          className="w-full py-2 text-white rounded text-xs font-semibold transition hover:opacity-90 cursor-pointer disabled:opacity-50 shadow-xs"
                        >
                          {simSubmitting ? 'Sending...' : 'Send Message'}
                        </button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* FULL WEBSITE PREVIEW VIEW */}
        {viewMode === 'website_preview' && (
          <div className="max-w-4xl mx-auto rounded-2xl border border-gray-700 bg-white text-gray-900 overflow-hidden shadow-2xl">
            <div className="bg-gray-100 px-6 py-3 border-b border-gray-200 flex items-center justify-between text-xs text-gray-600">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-red-400"></span>
                <span className="w-3 h-3 rounded-full bg-yellow-400"></span>
                <span className="w-3 h-3 rounded-full bg-green-400"></span>
                <span className="font-mono text-gray-700 font-semibold ml-2">https://client-site.com</span>
              </div>
              <button
                type="button"
                onClick={() => setViewMode('dashboard')}
                className="px-3 py-1 bg-black text-white rounded text-xs font-medium cursor-pointer"
              >
                Back to Admin
              </button>
            </div>

            {/* Public Header */}
            <nav className="px-8 py-4 border-b border-gray-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {brandLogo ? (
                  <img src={brandLogo} alt="" className="h-7 w-auto max-w-[120px] object-contain rounded" />
                ) : (
                  <div className="w-7 h-7 rounded flex items-center justify-center font-bold text-white text-xs" style={{ backgroundColor: brandColor }}>
                    {brandName ? brandName.slice(0, 2).toUpperCase() : 'CO'}
                  </div>
                )}
                <span className="font-bold text-base text-gray-900">{brandName}</span>
              </div>
              <div className="flex items-center gap-5 text-sm text-gray-600">
                <span>About</span>
                <span>Services</span>
                <a
                  href="#contact"
                  style={{ backgroundColor: brandColor }}
                  className="px-3.5 py-1.5 rounded-lg text-white font-medium text-xs shadow-xs"
                >
                  Contact
                </a>
              </div>
            </nav>

            <div className="p-10 space-y-12">
              <div className="max-w-2xl mx-auto space-y-6 text-center">
                {image && (
                  <div className="w-full h-64 rounded-2xl overflow-hidden border border-gray-200 shadow-lg">
                    <img src={image} alt="Hero" className="w-full h-full object-cover" />
                  </div>
                )}
                <div
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold"
                  style={{ backgroundColor: brandColor + '18', color: brandColor }}
                >
                  <span>●</span> Live Client Template
                </div>
                <h1 className="text-4xl sm:text-5xl font-extrabold text-gray-950 tracking-tight leading-tight">
                  {title || 'Welcome to Our Website'}
                </h1>
                <p className="text-base text-gray-600 leading-relaxed max-w-xl mx-auto">
                  {desc || 'This is a simple subtitle editable from your dashboard.'}
                </p>
                <div className="pt-2">
                  <a
                    href="#contact"
                    style={{ backgroundColor: brandColor }}
                    className="inline-block px-6 py-3 text-white font-medium rounded-lg shadow-sm hover:opacity-90 transition"
                  >
                    Get In Touch With {brandName}
                  </a>
                </div>
              </div>

              {/* Contact section */}
              <div id="contact" className="max-w-lg mx-auto bg-gray-50 p-8 rounded-2xl border border-gray-200 shadow-sm space-y-4">
                <div className="text-center">
                  <h3 className="text-lg font-bold text-gray-900">Get in Touch</h3>
                  <p className="text-xs text-gray-500 mt-1">Submissions directly deliver to {brandName}&apos;s /admin leads inbox.</p>
                </div>

                {simSuccess && (
                  <div className="p-3 bg-green-100 border border-green-300 text-green-800 text-xs rounded-lg font-medium">
                    ✓ Message received! Your lead is now waiting in the admin dashboard.
                  </div>
                )}

                <form onSubmit={handleSimulateSubmitLead} className="space-y-3 text-xs">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Your Name</label>
                    <input
                      type="text"
                      required
                      value={simName}
                      onChange={(e) => setSimName(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-black"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Email Address</label>
                    <input
                      type="email"
                      required
                      value={simEmail}
                      onChange={(e) => setSimEmail(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-black"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Message</label>
                    <textarea
                      rows={3}
                      required
                      value={simMessage}
                      onChange={(e) => setSimMessage(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-gray-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-black"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={simSubmitting}
                    style={{ backgroundColor: brandColor }}
                    className="w-full py-2.5 text-white rounded-lg text-xs font-semibold transition hover:opacity-90 cursor-pointer shadow-xs"
                  >
                    {simSubmitting ? 'Sending...' : 'Send Message'}
                  </button>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
